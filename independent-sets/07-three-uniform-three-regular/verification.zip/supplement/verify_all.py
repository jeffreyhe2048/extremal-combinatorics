#!/usr/bin/env python3
"""Regenerate and independently check every finite certificate in this package."""
from pathlib import Path
import json
import os
import platform
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
if sys.version_info < (3, 10):
    raise SystemExit('Python 3.10 or later is required.')
if not __debug__:
    raise SystemExit('Assertions must be enabled: do not use python -O or -OO.')

# The general independent audit invokes the independent twin-free enumerator.
# That shared enumeration is therefore run once, rather than twice.
STEPS = [
    'twinfree/verify_twinfree_cubic.py',
    'general/generate_views.py',
    'general/verify.py',
    'general/independent_audit.py',
    'general/interval_extension.py',
    'general/independent_interval_audit.py',
    'linear/verify_linear_cubic.py',
    'linear/independent_linear_audit.py',
    'transversal/verify.py',
    'transversal/independent_audit.py',
]

environment = os.environ.copy()
environment.pop('PYTHONOPTIMIZE', None)
environment['PYTHONDONTWRITEBYTECODE'] = '1'
start = time.monotonic()
records = []
for relative in STEPS:
    print('\nChecking ' + relative, flush=True)
    before = time.monotonic()
    subprocess.run([sys.executable, '-B', str(ROOT / relative)],
                   cwd=ROOT, env=environment, check=True)
    records.append({'script': relative, 'status': 'PASS',
                    'seconds': round(time.monotonic() - before, 3)})

report = {'status': 'PASS', 'python': platform.python_version(),
          'steps': records,
          'seconds': round(time.monotonic() - start, 3),
          'arithmetic': 'Integer and rational arithmetic in every certified inequality; '
                        'floating point is used only for timing and a displayed diagnostic.'}
(ROOT / 'verification_summary.json').write_text(
    json.dumps(report, indent=2) + '\n', encoding='utf-8')
print('\nPASS: all finite certificates regenerated and independently verified.', flush=True)
