import itertools,json,time
from pathlib import Path
from fractions import Fraction as F
OUT=Path(__file__).with_name('twinfree_cubic_certificate.json')
LINKS=[((0,1),(2,3),(4,5)),((0,1),(1,2),(3,4)),((0,1),(1,2),(2,3)),((0,1),(1,2),(0,2))]
views=set();stats=[]
for L in LINKS:
 n=1+max(max(e) for e in L);deg=[sum(i in e for e in L) for i in range(n)];cap=[3-d for d in deg]
 items=[(sum(1<<i for i in e),e) for r in (2,3) for e in itertools.combinations(range(n),r)]
 linkbits=[sum(1<<i for i in e) for e in L];families=[0]
 def process(E):
  families[0]+=1
  Q=[[[0]*7 for _ in range(3)] for S in range(1<<n)]
  for S in range(1<<n):
   if any(S&e==e for e in E):continue
   k=S.bit_count();p=sum(S&e==e for e in linkbits);w=sum(deg[i] for i in range(n) if S>>i&1)
   Q[S][0][k]=1;Q[S][2][k]=w+2*p
   if not p:Q[S][1][k]=1
  for i in range(n):
   for S in range(1<<n):
    if S>>i&1:
     for j in range(3):
      for k in range(7):Q[S][j][k]+=Q[S^(1<<i)][j][k]
  for S in range(1<<n):views.add(tuple(x for a in Q[S] for x in a))
 def recurse(start,used,E):
  process(E)
  for j in range(start,len(items)):
   mask,e=items[j]
   if any(used[v]>=cap[v] for v in e):continue
   dd=list(used)
   for v in e:dd[v]+=1
   recurse(j+1,dd,E+(mask,))
 recurse(0,[0]*n,());stats.append({'link':L,'n':n,'families':families[0],'marks':families[0]*(1<<n)})

def trim(a):
 a=list(a)
 while len(a)>1 and a[-1]==0:a.pop()
 return a
def add(a,b):
 c=[0]*max(len(a),len(b))
 for i,x in enumerate(a):c[i]+=x
 for i,x in enumerate(b):c[i]+=x
 return trim(c)
def sc(a,c):return trim([x*c for x in a])
def mul(a,b):
 c=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):c[i+j]+=x*y
 return trim(c)
def deriv(a):return trim([i*a[i] for i in range(1,len(a))])
A=[0,1,4,2];B=[1,5,9,3];D=[0,3,7,2];l=[0,1]
records=[]
for v in sorted(views):
 q0,q1,R=[trim(v[7*i:7*(i+1)]) for i in range(3)];Z=add(q0,mul(l,q1))
 slack=add(add(sc(mul(A,Z),12),sc(mul(add(sc(B,12),sc(D,-6)),mul(l,q1)),-1)),sc(mul(D,R),-1))
 assert all(c>=0 for c in slack),(v,slack)
 records.append({'view':v,'slack':slack})
# The derivative of A/(lambda B) has non-positive numerator, proving monotonicity.
a=A[1:];monotone=add(mul(deriv(a),B),sc(mul(a,deriv(B)),-1));assert all(x<=0 for x in monotone)
R=lambda t:sum(F(a[k])*t**k for k in range(len(a)))/sum(F(B[k])*t**k for k in range(len(B)))
N=1024;upper=sum((R(F(k,N)) for k in range(N)),F(0))/N;assert upper<F(307,500)
assert 2*(F(1,3)+F(1,81)+F(1,1215))>F(693,1000)
gap1=(8*F(693,1000)-F(3,253))/9-F(307,500);assert gap1==F(259,379500)>0
# Occupancy comparison for lambda>=1; coefficients after lambda=1+x.
P=[1,9,36,75,81,42,9];gap=add(mul(mul(l,deriv(P)),B),sc(mul(P,A),-9));shift=[0]*len(gap)
from math import comb
for j,c in enumerate(gap):
 for k in range(j+1):shift[k]+=c*comb(j,k)
assert all(c>=0 for c in shift) and shift[0]>0
result={'status':'PASS','family_stats':stats,'views':len(records),'zero_slacks':sum(not any(r['slack']) for r in records),'A':A,'B':B,'D':D,'monotone_numerator':monotone,'riemann_subdivisions':N,'riemann_upper_less_than':[307,500],'log_gap_at_1':[259,379500],'reference_gap':gap,'reference_gap_at_1_plus_x':shift,'certificate':records}
OUT.write_text(json.dumps(result,indent=2));print({k:v for k,v in result.items() if k!='certificate'})
