#!/usr/bin/env python3
"""Direct independent audit of twin-free cubic triple-system local certificates."""
from itertools import combinations
from fractions import Fraction
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent
links = [(3, 12, 48), (3, 6, 24), (3, 6, 12), (3, 5, 6)]
views = set()
stats = []
for link in links:
    n = max(link).bit_length()
    degree = [sum((e >> v) & 1 for e in link) for v in range(n)]
    cap = [3 - d for d in degree]
    items = [e for e in range(1 << n) if e.bit_count() in (2, 3)]
    encodings = [sum(1 << (3 * v) for v in range(n) if e >> v & 1) for e in items]
    submasks = []
    for u in range(1 << n):
        submasks.append([s for s in range(1 << n) if s & u == s])
    weights = [sum(degree[v] for v in range(n) if s >> v & 1) for s in range(1 << n)]
    full_pairs = [sum(s & e == e for e in link) for s in range(1 << n)]
    counts = 0
    local = set()
    # At most sum(cap)//2 constraints; enumerate by cardinality, not recursive extension.
    for k in range(sum(cap) // 2 + 1):
        for indices in combinations(range(len(items)), k):
            total = sum(encodings[j] for j in indices)
            if any(((total >> (3 * v)) & 7) > cap[v] for v in range(n)):
                continue
            counts += 1
            forbidden = [items[j] for j in indices]
            legal = [not any(s & e == e for e in forbidden) for s in range(1 << n)]
            for u in range(1 << n):
                pols = [[0] * 7 for _ in range(5)]
                for s in submasks[u]:
                    if not legal[s]:
                        continue
                    size = s.bit_count()
                    pols[0][size] += 1
                    pols[2][size] += weights[s]
                    pols[4][size] += full_pairs[s]
                    if full_pairs[s] == 0:
                        pols[1][size] += 1
                        pols[3][size] += weights[s]
                local.add(tuple(c for p in pols for c in p))
    stats.append({'link': link, 'families': counts, 'views': len(local)})
    views.update(local)
    print(stats[-1], flush=True)
assert [s['families'] for s in stats] == [15453, 507, 31, 5]
assert len(views) == 585

def convolution(a, b):
    ans = [0] * 16
    for i in range(len(a)):
        for j in range(len(b)):
            if a[i] and b[j]:
                assert i + j < 16
                ans[i + j] += a[i] * b[j]
    return ans

A = [0, 1, 4, 2]
B = [1, 5, 9, 3]
D = [0, 3, 7, 2]
P = [1, 9, 36, 75, 81, 42, 9]
zero = []
for v in sorted(views):
    q0, q1, w0, w1, t0 = [v[7 * j:7 * j + 7] for j in range(5)]
    z = list(q0) + [0]
    for j in range(7):
        z[j + 1] += q1[j]
    term0 = convolution(A, z)
    term1 = convolution([12 * b - 6 * d for b, d in zip(B, D)], [0] + list(q1))
    term2 = convolution(D, [w + 2 * t for w, t in zip(w0, t0)])
    slack = [12 * a - b - c for a, b, c in zip(term0, term1, term2)]
    assert all(c >= 0 for c in slack), (v, slack)
    if not any(slack):
        zero.append(v)

# Rational upper Riemann sum: R=(1+4t+2t^2)/(1+5t+9t^2+3t^3) is decreasing.
Rnum = [1, 4, 2]
deriv_num = [a - b for a, b in zip(
    convolution([4, 4], B), convolution(Rnum, [5, 18, 9]))]
assert deriv_num[:5] == [-1, -14, -35, -24, -6] and not any(deriv_num[5:])
N = 1024
upper = sum((Fraction(N * N + 4 * j * N + 2 * j * j,
                     N ** 3 + 5 * j * N * N + 9 * j * j * N + 3 * j ** 3)
             for j in range(N)), Fraction(0))
assert upper < Fraction(307, 500)
# log(2)=2 sum_{j>=0}(1/3)^(2j+1)/(2j+1), four positive terms suffice.
log2_lower = sum((Fraction(2, (2 * j + 1) * 3 ** (2 * j + 1)) for j in range(4)), Fraction(0))
assert log2_lower > Fraction(693, 1000)
gap_constant = (8 * Fraction(693, 1000) - Fraction(3, 253)) / 9 - Fraction(307, 500)
assert gap_constant == Fraction(259, 379500)

q = [a - 9 * b for a, b in zip(convolution([j * p for j, p in enumerate(P)], B), convolution(P, A))]
# Translate q(lambda) to q(1+x); no floating point root finding.
from math import comb
shifted = [sum(q[j] * comb(j, k) for j in range(k, len(q))) for k in range(len(q))]
assert shifted[0] > 0 and all(c >= 0 for c in shifted)

source_path = HERE / 'twinfree_cubic_certificate.json'
source_compared = False
reduced_views = {tuple(v[:14]) + tuple(v[14 + j] + 2 * v[28 + j] for j in range(7)) for v in views}
assert len(reduced_views) == 571
assert source_path.is_file(), 'Run verify_twinfree_cubic.py first.'
if source_path.exists():
    source = json.loads(source_path.read_text())
    if 'certificate' in source:
        assert {tuple(row['view']) for row in source['certificate']} == reduced_views
        source_compared = True

assert source_compared, 'The independently generated local table must match the primary table.'

result = {
    'status': 'PASS', 'families_by_link': stats, 'views': len(views),
    'reduced_polynomial_triples': len(reduced_views),
    'zero_slack_views': len(zero),
    'riemann_intervals': N, 'upper_sum_less_than': '307/500',
    'log2_series_terms': 4, 'uniform_log_gap': str(gap_constant),
    'reference_gap_at_1_plus_x': shifted,
    'source_view_set_compared': source_compared,
    'method': 'Cardinality-stratified family enumeration; direct subset sums; integer convolution; exact rational Riemann bound'
}
(HERE / 'independent_twinfree_audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
