"""Exact outward-rounded dyadic interval certificate; standard library only."""
from itertools import product
from collections import Counter
from math import isqrt
from time import monotonic
import json
from pathlib import Path
OUT = Path(__file__).resolve().parent
S=1<<60
class I:
 __slots__=('lo','hi')
 def __init__(self,lo,hi=None):self.lo,self.hi=lo,lo if hi is None else hi
 @staticmethod
 def rat(n,d=1):return I(n*S//d,(n*S+d-1)//d)
 def __add__(a,b):return I(a.lo+b.lo,a.hi+b.hi)
 def __sub__(a,b):return I(a.lo-b.hi,a.hi-b.lo)
 def __mul__(a,b):
  assert min(a.lo,b.lo)>=0
  return I(a.lo*b.lo//S,(a.hi*b.hi+S-1)//S)
 def __truediv__(a,b):
  assert a.lo>=0 and b.lo>0
  return I(a.lo*S//b.hi,(a.hi*S+b.lo-1)//b.lo)
 def __pow__(a,n):
  if n<0:return I.rat(1)/(a**(-n))
  r=I.rat(1)
  while n:
   if n&1:r=r*a
   a=a*a;n//=2
  return r
 def sqrt(a):
  assert a.lo>=0
  l=isqrt(a.lo*S);r=isqrt(a.hi*S)
  return I(l,r+(r*r<a.hi*S))
ONE=I.rat(1);ZERO=I.rat(0)
LINKS={'P4':[(0,1),(1,2),(2,3)],'C3':[(0,1),(1,2),(0,2)],'P3K2':[(0,1),(1,2),(3,4)],'3K2':[(0,1),(2,3),(4,5)],'star':[(0,1),(0,2),(0,3)]}
DATA=[];identities=[]
for name,es in LINKS.items():
 n=max(max(e) for e in es)+1;deg=[sum(v in e for e in es) for v in range(n)];star=name=='star'
 vs=[v for v in range(n) if not(star and deg[v]==3)]
 ds=[v for v in vs if deg[v]==2];ls=[v for v in vs if deg[v]==1]
 for mark in product([0,1],repeat=len(ls)):
  U=ds+[v for v,z in zip(ls,mark) if z];W=[v for v in vs if v not in U];u,w=len(U),len(W);q=len(ds)-sum(mark)
  if not U and name in ('3K2','star'):
   identities.append((name,q,u,w));continue
  rows=[]
  for yy in product([0,1],repeat=w):
   state=dict(zip(W,yy));terms=[]
   for xx in product([0,1],repeat=u):
    state.update(zip(U,xx));ind=not any(state.values()) if star else all(not(state[v] and state[r]) for v,r in es)
    k=sum(xx);g=sum((1 if v in ds else -1)*state[v] for v in U)
    v=6*(u-k)-2*g-12*(1+star)+(0 if ind else 12)
    terms.append((v,k,4 if star and ind else 2 if ind else 0,2 if star and not ind else 0))
   vmin=min(t[0] for t in terms)
   e=6*(w-sum(yy))+3*vmin//2+3*q+18*star
   assert vmin%2==0 and e>=0
   count=Counter((v-vmin,k,b,d) for v,k,b,d in terms)
   rows.append((e,sum(yy),tuple(sorted((cnt,*t) for t,cnt in count.items()))))
  # equal rows can be grouped, and equal full expressions can share a certificate
  rows=tuple(sorted((cnt,*r) for r,cnt in Counter(rows).items()))
  DATA.append((name,mark,q,6-w-3*star,u,rows))
GROUPS={}
for d in DATA:GROUPS.setdefault(d[2:],[]).append((d[0],d[1]))
CASES=list(GROUPS)
P=(1,9,36,75,81,42,9)
def context(z):
 z6=z**6;a=I.rat(2)-I.rat(3)*z6;b=I.rat(2)-I.rat(2)*z6;d=I.rat(4)-I.rat(5)*z6
 assert min(a.lo,b.lo,d.lo)>0
 def powers(t,n):
  out=[ONE]
  for k in range(n):out.append(out[-1]*t)
  return out
 Z=powers(z,72);A=powers(a,6);B=powers(b,12);D=powers(d,2)
 T=ZERO
 for k,c in enumerate(P):T=T+I.rat(c)*Z[36-6*k]*A[k]
 return Z,A,B,D,b,T,{}
def bound(case,ctx):
 q,bpow,u,rows=case;Z,A,B,D,b,T,cache=ctx;total=ZERO
 for cnt,e,j,terms in rows:
  if terms not in cache:
   poly=ZERO
   for c,v,k,bb,dd in terms:poly=poly+I.rat(c)*Z[v]*A[k]*B[bb]*D[dd]
   cache[terms]=poly*poly.sqrt()
  total=total+I.rat(cnt)*Z[e]*A[j]*cache[terms]
 factor=(b**(2*bpow-3*u)).sqrt()
 return total*factor/T/(I.rat(41,50)**q)

def run():
 assert 2*891**6>1000**6 # 891/1000 > 2^{-1/6}; covers every lambda >= 1
 threshold=I.rat(199,200).lo
 root=I(0,I.rat(891,1000).hi)
 todo=[(root,tuple(range(len(CASES))),0)];cert=[];nodes=0;worst=0;maxdepth=0;t=monotonic()
 while todo:
  z,ids,depth=todo.pop();ctx=context(z);failed=[];nodes+=1;maxdepth=max(depth,maxdepth)
  for idx in ids:
   try:v=bound(CASES[idx],ctx)
   except (AssertionError,ZeroDivisionError):failed.append(idx);continue
   if v.hi<=threshold:
    cert.append((idx,z.lo,z.hi,v.hi));worst=max(worst,v.hi)
   else:failed.append(idx)
  if failed:
   assert depth<30,(depth,z.lo/S,z.hi/S,failed)
   mid=(z.lo+z.hi)//2;todo.append((I(mid,z.hi),tuple(failed),depth+1));todo.append((I(z.lo,mid),tuple(failed),depth+1))
  if nodes%5000==0:print('progress',nodes,len(todo),len(cert),monotonic()-t,flush=True)
 result={'status':'PASS','interval_arithmetic':'outward rounded integers, scale 2^60','domain':['0','891/1000'],'threshold':'199/200','labelled_nonidentity_cases':len(DATA),'expression_classes':len(CASES),'identity_cases':identities,'nodes':nodes,'leaf_bounds':len(cert),'max_depth':maxdepth,'largest_certified_upper_ratio':worst/S,'seconds':monotonic()-t}
 print(json.dumps(result,indent=2),flush=True)
 with open(OUT / 'certificate.json','w') as f:json.dump(result,f,indent=2)
 if __name__=='__main__':
  with open(OUT / 'interval_leaves.json','w') as f:json.dump(cert,f)
if __name__=='__main__':run()
