"""Independent formula generation, leaf coverage, and exact interval re-evaluation.
Uses the submitted leaves only as a suggested interval subdivision; all values
are rebuilt at 90-bit scale using endpoint powers and direct three-half powers.
"""
from fractions import Fraction as Q
from itertools import product
from collections import Counter
from math import isqrt
from pathlib import Path
import json,runpy,time
ROOT=Path(__file__).resolve().parent
submitted=runpy.run_path(str(ROOT/'verify.py'))
root_cases=submitted['CASES']
leaves=json.loads((ROOT/'interval_leaves.json').read_text())
S=1<<90;RS=1<<60

def ceildiv(a,b):return -(-a//b)
def rat(a,b=1):return (a*S//b,ceildiv(a*S,b))
def add(x,y):return x[0]+y[0],x[1]+y[1]
def sub(x,y):return x[0]-y[1],x[1]-y[0]
def mul(x,y):
 assert min(x[0],y[0])>=0
 return x[0]*y[0]//S,ceildiv(x[1]*y[1],S)
def div(x,y):
 assert x[0]>=0 and y[0]>0
 return x[0]*S//y[1],ceildiv(x[1]*S,y[0])
def power(x,n):
 if n==0:return rat(1)
 if n<0:return div(rat(1),power(x,-n))
 return x[0]**n//S**(n-1),ceildiv(x[1]**n,S**(n-1))
def square_root(x):
 assert x[0]>=0
 a=isqrt(x[0]*S);b=isqrt(x[1]*S)
 return a,b+(b*b<x[1]*S)
def three_half(x):
 assert x[0]>=0
 a=isqrt(x[0]**3//S);b=isqrt(x[1]**3//S)
 return a,b+(b*b*S<x[1]**3)

# Build local truth tables, with no access to the submitted DATA or CASES.
link_types=[('P4',[(0,1),(1,2),(2,3)]),('C3',[(0,1),(1,2),(0,2)]),
 ('P3K2',[(0,1),(1,2),(3,4)]),('3K2',[(0,1),(2,3),(4,5)]),
 ('star',[(0,1),(0,2),(0,3)])]
ours={};count=0
for name,edges in link_types:
 degrees={v:sum(v in e for e in edges) for v in set(sum((list(e) for e in edges),[]))}
 core={v for v,d in degrees.items() if d==3}
 verts=set(degrees)-core;twice={v for v in verts if degrees[v]==2};once=sorted(v for v in verts if degrees[v]==1)
 star=bool(core)
 for selected in product((0,1),repeat=len(once)):
  U=twice|{v for v,k in zip(once,selected) if k};W=verts-U
  if not U and (star or not twice):continue
  u,w=len(U),len(W);q=len(twice)-len(U-twice);rows=[]
  for active_w in product((0,1),repeat=w):
   vals=dict(zip(sorted(W),active_w));terms=Counter()
   for active_u in product((0,1),repeat=u):
    vals.update(zip(sorted(U),active_u));j=sum(active_u)
    good=not any(vals.values()) if star else not any(vals[a]*vals[b] for a,b in edges)
    gauge=sum(vals[v] for v in twice)-sum(vals[v] for v in U-twice)
    # Start with Bernoulli powers, then multiply the exact local factor square.
    zp=6*(u-j)-2*gauge
    bp=dp=0
    if star:
     if good:zp-=24;bp=4
     else:zp-=12;dp=2
    elif good:zp-=12;bp=2
    terms[(zp,j,bp,dp)]+=1
   low=min(k[0] for k in terms)
   assert low%2==0
   global_z=6*(w-sum(active_w))+3*low//2+3*q+18*star
   assert global_z>=0
   polynomial=tuple(sorted((c,z-low,j,bp,dp) for (z,j,bp,dp),c in terms.items()))
   rows.append((global_z,sum(active_w),polynomial))
  compressed=tuple(sorted((c,*r) for r,c in Counter(rows).items()))
  expr=(q,6-w-3*star,u,compressed)
  ours.setdefault(expr,[]).append((name,selected));count+=1
assert count==91 and len(ours)==25
assert set(root_cases)==set(ours),'independent symbolic expressions disagree'

# Every listed case has complete interval coverage.
end=ceildiv(891*RS,1000)
for i in range(25):
 ints=sorted((lo,hi) for k,lo,hi,_ in leaves if k==i)
 assert ints and ints[0][0]==0
 reach=0
 for lo,hi in ints:
  assert 0<=lo<=reach and lo<=hi<=end
  reach=max(reach,hi)
 assert reach==end
assert 2*891**6>1000**6
P=[1,9,36,75,81,42,9]
cache={}
def evaluate(expr,lo,hi):
 z=(lo*(S//RS),hi*(S//RS))
 if (lo,hi) not in cache:
  z6=power(z,6);A=sub(rat(2),mul(rat(3),z6));B=sub(rat(2),mul(rat(2),z6));D=sub(rat(4),mul(rat(5),z6))
  assert min(A[0],B[0],D[0])>0
  Z=[power(z,k) for k in range(73)];AA=[power(A,k) for k in range(7)];BB=[power(B,k) for k in range(5)];DD=[power(D,k) for k in range(3)]
  T=rat(0)
  for k,c in enumerate(P):T=add(T,mul(rat(c),mul(Z[36-6*k],AA[k])))
  cache[(lo,hi)]=Z,AA,BB,DD,B,T
 Z,AA,BB,DD,B,T=cache[(lo,hi)]
 q,bpow,u,rows=expr;total=rat(0)
 for cnt,e,j,terms in rows:
  pol=rat(0)
  for c,k,t,b,d in terms:
   pol=add(pol,mul(rat(c),mul(mul(Z[k],AA[t]),mul(BB[b],DD[d]))))
  total=add(total,mul(rat(cnt),mul(mul(Z[e],AA[j]),three_half(pol))))
 return div(mul(total,square_root(power(B,2*bpow-3*u))),mul(T,power(rat(41,50),q)))
start=time.monotonic();mx=0
for idx,lo,hi,_ in leaves:
 bound=evaluate(root_cases[idx],lo,hi)
 assert bound[1]<=rat(199,200)[0],(idx,lo,hi,bound)
 mx=max(mx,bound[1])
out={'status':'PASS','independently_derived_nonidentity_cases':count,'symbolic_classes':25,
 'leaf_coverage':'all 25 cover [0,891/1000] exactly without gaps','interval_leaves_rechecked':len(leaves),
 'scale':'2^90','method':'independent endpoint powers and direct 3/2 powers; integer outward rounding',
 'strict_factor':'199/200','max_upper_rational':str(Q(mx,S)),'seconds':time.monotonic()-start}
(ROOT/'independent_audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
