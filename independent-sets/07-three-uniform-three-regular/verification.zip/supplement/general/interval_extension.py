#!/usr/bin/env python3
"""Exact verification of the extended activity interval; standard library only."""
from pathlib import Path
from fractions import Fraction as F
from math import comb
import json

ROOT=Path(__file__).resolve().parent
slacks=json.loads((ROOT/'certificate.json').read_text())['slacks']
assert len(slacks)==800
for index,a in enumerate(slacks):
    d=len(a)-1
    coefficients=[sum(a[j]*5**j*3**(d-j)*comb(d-j,k-j)
                      for j in range(k+1)) for k in range(d+1)]
    assert all(x>=0 for x in coefficients), index
f=lambda x:(1+4*x+2*x*x)/(1+5*x+9*x*x+3*x**3)
N=2048
upper=F(2,3*N)*sum((f(F(2*j,3*N)) for j in range(N)),F(0))
T=lambda z:2*sum((z**(2*j+1)/F(2*j+1) for j in range(20)),F(0))
lower=(6*T(F(1,3))+T(F(287,10655)))/9-upper
assert lower>F(1,10000)
quartic=[-9,-6,51,81,36]
shift=[sum(F(quartic[j])*comb(j,k)*F(2,3)**(j-k)
           for j in range(k,5)) for k in range(5)]
assert all(x>0 for x in shift)
report={'status':'PASS','local_interval':['0','5/3'],'slacks':800,
        'riemann_subdivisions':N,'log_series_terms':20,
        'endpoint_gap_greater_than':'1/10000',
        'derivative_quartic_at_2_3':[str(x) for x in shift],
        'partition_function_interval':['2/3','5/3'],
        'arithmetic':'integer and exact rational arithmetic only'}
(ROOT/'interval_extension.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
