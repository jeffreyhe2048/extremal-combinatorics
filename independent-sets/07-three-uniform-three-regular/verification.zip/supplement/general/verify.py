import json
from math import comb
from fractions import Fraction

def trim(a):
 a=list(a)
 while len(a)>1 and a[-1]==0:a.pop()
 return a

def add(*terms):
 c=[0]*max(map(len,terms))
 for a in terms:
  for i,x in enumerate(a):c[i]+=x
 return trim(c)
def sc(a,s):return trim([x*s for x in a])
def mul(*terms):
 c=[1]
 for b in terms:
  a=c;c=[0]*(len(a)+len(b)-1)
  for i,x in enumerate(a):
   for j,y in enumerate(b):c[i+j]+=x*y
 return trim(c)
def deriv(a):return trim([i*a[i] for i in range(1,len(a))])
def shift01(a):
 d=len(a)-1;c=[0]*(d+1)
 for j,x in enumerate(a):
  for k in range(d-j+1):c[j+k]+=x*comb(d-j,k)
 return trim(c)
A=[0,1,4,2];B=[1,5,9,3];P=[1,9,36,75,81,42,9];l=[0,1];l2=[0,0,1];L=[1,1];b=[1,2]
C=[0,0,3,1];H3=[0,-3,-4,-1]
T=add(mul(l,deriv(P),B),sc(mul(P,A),-3))
N8=add(sc(mul(P,B,l,L),6),sc(mul(T,L,L),-1),sc(mul(P,C,l,L),-3),sc(mul(P,H3,l2),3))
Zstar=add(mul(L,L,L,b),l2)
N9=add(sc(mul(P,B,l,add(mul(L,L,L),l)),6),sc(mul(T,Zstar),-1),sc(mul(P,add(C,sc(H3,-1)),l2,add(mul(L,L),[-1])),3))
Q=sc(mul(l2,P,B),18);U=sc(mul(l2,P,A),18);V=sc(mul(l2,add(mul(l,deriv(P),B),sc(mul(P,A),-9))),3);CQ=sc(mul(l2,P,C),18);HQ=sc(mul(l2,P,H3),6)
print('N8',N8,'N9',N9)
vs=json.load(open(__import__('pathlib').Path(__file__).with_name('local_views.json')))['views'];bad=[];zeros=[];records=[]
for ii,v in enumerate(vs):
 st,mm=v[:2];v=v[2:];q0,q1,w0,w1,t0=[trim(v[7*j:7*j+7]) for j in range(5)];r8=v[35+8*8:35+8*9];r9=v[35+8*9:35+8*10];z=add(q0,mul(l,q1))
 S=add(sc(mul(add(U,sc(V,st)),z),6),sc(mul(Q,l,q1),-6),mul(CQ,add(sc(mul(l,q1),6),sc(w0,-1),sc(mul(l,w1),-1))),mul(HQ,add(sc(t0,6),sc(mul(l,w1),-3))),sc(mul(N8,r8),6),sc(mul(N9,r9),6))
 trans=shift01(S)
 if any(x<0 for x in trans):bad.append((ii,S,trans))
 if not any(S):zeros.append(ii)
 records.append(S)
assert len(vs)==800
assert not bad
print('PASS: all 800 transformed slacks have nonnegative integer coefficients; zero slacks',len(zeros))
for i,s,t in bad[:5]:print('bad',i,s,t,'at1',sum(s))
json.dump({'N8':N8,'N9':N9,'Q':Q,'U':U,'V':V,'CQ':CQ,'HQ':HQ,'slacks':records,'zeros':zeros,'bad':[i for i,*_ in bad]},open(__import__('pathlib').Path(__file__).with_name('certificate.json'),'w'))

# Exact rational integration and comparison, independent of numerical LPs.
F=Fraction
N=1024
f=lambda t:(1+4*t+2*t*t)/(1+5*t+9*t*t+3*t*t*t)
upper=sum((f(F(k,N)) for k in range(N)),F(0))/N
assert upper<F(307,500)
assert all(c<=0 for c in add(mul(deriv(A[1:]),B),sc(mul(A[1:],deriv(B)),-1)))
assert 2*(F(1,3)+F(1,81)+F(1,1215))>F(693,1000)
kappa=(8*F(693,1000)-F(3,253))/9-F(307,500)
assert kappa==F(259,379500)>0
print('PASS: exact integral and log comparison; kappa=',kappa)
