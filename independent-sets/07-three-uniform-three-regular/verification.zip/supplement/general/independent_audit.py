#!/usr/bin/env python3
"""Independent local-view and integer-polynomial audit of the general cubic bound."""
from pathlib import Path
from itertools import combinations
from math import comb
import contextlib
import io
import json
import runpy

HERE = Path(__file__).resolve().parent
# Reuse the independently written cardinality-stratified enumerator, not generate_views.py.
with contextlib.redirect_stdout(io.StringIO()):
    old = runpy.run_path(str(HERE.parent / 'twinfree' / 'independent_twinfree_audit.py'))
views = {(0, 0) + v + (0,) * 96 for v in old['views']}
links = [(3, 12, 48), (3, 6, 24), (3, 6, 12), (3, 5, 6), (3, 5, 9)]
jobs = []
# All seven nonempty markings of the matching, rather than one symmetry representative.
for k in (1, 2, 3):
    for marked in combinations(links[0], k):
        jobs.append((0, marked))
jobs += [(1, (24,)), (4, ())]
stats = []
for typ, marked in jobs:
    link = links[typ]
    n = max(link).bit_length()
    degree = [sum((e >> v) & 1 for e in link) for v in range(n)]
    cap = [3 - d for d in degree]
    must = sum(marked) if typ != 4 else 1
    items = [s for s in range(1 << n) if s.bit_count() in (2, 3)
             and all(not (s >> v & 1) or cap[v] > 0 for v in range(n))
             and all(not s & p or s & p == p for p in marked)]
    enc = [sum(1 << (3 * v) for v in range(n) if s >> v & 1) for s in items]
    local = set()
    family_count = 0
    for k in range(sum(cap) // 2 + 1):
        for jj in combinations(range(len(items)), k):
            dcode = sum(enc[j] for j in jj)
            if any(((dcode >> (3 * v)) & 7) > cap[v] for v in range(n)):
                continue
            family_count += 1
            F = [items[j] for j in jj]
            for U in range(1 << n):
                if U & must != must:
                    continue
                pols = [[0] * 7 for _ in range(5)]
                rows = [[0] * 8 for _ in range(12)]
                # Directly enumerate the entire local configuration, including the root.
                for state in range(1 << (n + 1)):
                    root = state >> n
                    S = state & ((1 << n) - 1)
                    if S & U != S or any(S & e == e for e in F):
                        continue
                    pairs = sum(S & e == e for e in link)
                    if root and pairs:
                        continue
                    size = S.bit_count()
                    weight = sum(degree[v] for v in range(n) if S >> v & 1)
                    if root:
                        pols[1][size] += 1
                        pols[3][size] += weight
                    else:
                        pols[0][size] += 1
                        pols[2][size] += weight
                        pols[4][size] += pairs
                    if typ == 4:
                        occupied_pair = root + (S & 1)
                        for leaf in (1, 2, 3):
                            occupied_leaf = (S >> leaf) & 1
                            available = ((U >> leaf) & 1) and not any(
                                e >> leaf & 1 and (S | (1 << leaf)) & e == e for e in F)
                            index = 4 * occupied_pair + 2 * occupied_leaf + int(available)
                            rows[index][size + root] += 1
                    else:
                        for pair in marked:
                            occupied_pair = (S & pair).bit_count()
                            available = not any(S & e == e for e in link if e != pair)
                            index = 4 * occupied_pair + 2 * root + int(available)
                            rows[index][size + root] -= 2
                local.add((int(typ == 4), len(marked)) + tuple(c for p in pols for c in p)
                          + tuple(c for p in rows for c in p))
    views.update(local)
    stats.append({'type': typ, 'marked_masks': marked, 'families': family_count, 'views': len(local)})

source_views = json.loads((HERE / 'local_views.json').read_text())['views']
assert len(views) == 800
assert set(map(tuple, source_views)) == views

# Sparse integer polynomial arithmetic; coefficients of N8/N9 are an independent input.
def poly(coeff):
    return {k: c for k, c in enumerate(coeff) if c}
def plus(*terms):
    ans = {}
    for term in terms:
        for k, c in term.items():
            ans[k] = ans.get(k, 0) + c
    return {k: c for k, c in ans.items() if c}
def times(*terms):
    ans = {0: 1}
    for term in terms:
        nxt = {}
        for i, a in ans.items():
            for j, b in term.items():
                nxt[i + j] = nxt.get(i + j, 0) + a * b
        ans = {k: c for k, c in nxt.items() if c}
    return ans
def scale(term, c):
    return {k: a * c for k, a in term.items() if a * c}
def derivative(term):
    return {k - 1: k * a for k, a in term.items() if k}

A, B, P = map(poly, ([0, 1, 4, 2], [1, 5, 9, 3], [1, 9, 36, 75, 81, 42, 9]))
x = {1: 1}
x2 = {2: 1}
C = poly([0, 0, 3, 1])
H3 = poly([0, -3, -4, -1])
Q = scale(times(x2, P, B), 18)
U = scale(times(x2, P, A), 18)
V = scale(times(x2, plus(times(x, derivative(P), B), scale(times(P, A), -9))), 3)
CQ = scale(times(x2, P, C), 18)
HQ = scale(times(x2, P, H3), 6)
N8 = poly([0, 0, 0, 0, 9, 24, -30, -177, -249, -153, -36])
N9 = poly([0, 0, 0, 0, 15, 120, 429, 858, 1044, 807, 384, 99, 9])
source = json.loads((HERE / 'certificate.json').read_text())
for name, term in [('Q', Q), ('U', U), ('V', V), ('CQ', CQ), ('HQ', HQ), ('N8', N8), ('N9', N9)]:
    assert term == poly(source[name]), name

zeros = 0
max_degree = 0
for j, v in enumerate(sorted(views)):
    star = v[0]
    q0, q1, w0, w1, t0 = [poly(v[2 + 7 * k:2 + 7 * (k + 1)]) for k in range(5)]
    r8 = poly(v[37 + 64:37 + 72])
    r9 = poly(v[37 + 72:37 + 80])
    Z = plus(q0, times(x, q1))
    S = plus(
        scale(times(plus(U, scale(V, star)), Z), 6),
        scale(times(Q, x, q1), -6),
        times(CQ, plus(scale(times(x, q1), 6), scale(w0, -1), scale(times(x, w1), -1))),
        times(HQ, plus(scale(t0, 6), scale(times(x, w1), -3))),
        scale(times(N8, r8), 6), scale(times(N9, r9), 6))
    assert S == poly(source['slacks'][j]), j
    if not S:
        zeros += 1
        continue
    degree = max(S)
    max_degree = max(max_degree, degree)
    # Coefficient-by-coefficient formula for (1+y)^degree S(y/(1+y)).
    transformed = [sum(S.get(i, 0) * comb(degree - i, k - i) for i in range(k + 1))
                   for k in range(degree + 1)]
    assert min(transformed) >= 0, (j, transformed)
assert zeros == 62
result = {
    'status': 'PASS', 'views': len(views), 'zero_slacks': zeros,
    'max_slack_degree': max_degree, 'marked_enumeration': stats,
    'local_table_exact_match': True, 'all_slacks_exact_match': True,
    'interval': '0 <= lambda <= 1',
    'integral_audit': 'independent_twinfree_audit.py rerun; 1024 exact rational upper-sum terms',
    'method': 'All markings; cardinality-stratified constraint families; full root-state enumeration; sparse integer polynomial arithmetic'
}
(HERE / 'independent_audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
