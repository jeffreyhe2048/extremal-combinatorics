# Standard-library exhaustive local enumeration. All coefficients are integers.
# Entries: star indicator, marked book count, five degree-6 polynomials,
# twelve degree-7 book-incidence transport polynomials indexed 4*b+2*x+y.
import itertools,json,time
links=[((0,1),(2,3),(4,5)),((0,1),(1,2),(3,4)),((0,1),(1,2),(2,3)),((0,1),(1,2),(0,2)),((0,1),(0,2),(0,3))]
views=set();stats=[]
for li in range(4):
 L=links[li];n=1+max(max(e) for e in L);deg=[sum(v in e for e in L) for v in range(n)];cap=[3-d for d in deg]
 linkmasks=[sum(1<<v for v in e) for e in L]
 items=[(sum(1<<v for v in e),e) for k in (2,3) for e in itertools.combinations(range(n),k)]
 bc=[0];bt=time.time();bv=set()
 def process_base(es):
  bc[0]+=1
  arr=[[[0]*7 for j in range(5)] for s in range(1<<n)]
  for s in range(1<<n):
   if any(s&e==e for e in es):continue
   k=s.bit_count();w=sum(deg[v] for v in range(n) if s>>v&1);t=sum(s&e==e for e in linkmasks)
   arr[s][0][k]=1;arr[s][2][k]=w;arr[s][4][k]=t
   if not t:arr[s][1][k]=1;arr[s][3][k]=w
  for i in range(n):
   for s in range(1<<n):
    if s>>i&1:
     for j in range(5):
      for k in range(7):arr[s][j][k]+=arr[s^(1<<i)][j][k]
  for s in range(1<<n):bv.add((0,0)+tuple(x for aa in arr[s] for x in aa)+(0,)*96)
 def rec_base(start,degs,es):
  process_base(es)
  for j in range(start,len(items)):
   mask,vs=items[j]
   if any(degs[v]>=cap[v] for v in vs):continue
   dd=list(degs)
   for v in vs:dd[v]+=1
   rec_base(j+1,dd,es+(mask,))
 rec_base(0,[0]*n,())
 views.update(bv);stats.append((li,0,bc[0],len(bv)));print('base',stats[-1],time.time()-bt,flush=True)
for li,mm in ((0,1),(0,2),(0,3),(1,1),(4,0)):
 L=links[li];n=max(max(e) for e in L)+1;d=[sum(v in e for e in L) for v in range(n)];cap=[3-x for x in d]
 marked=L[:mm] if li==0 else (L[-1:] if mm else ())
 markmasks=[sum(1<<v for v in e) for e in marked];linkmasks=[sum(1<<v for v in e) for e in L];must=sum(markmasks)|(1 if li==4 else 0)
 items=[]
 for k in (2,3):
  for e in itertools.combinations(range(n),k):
   em=sum(1<<v for v in e)
   if any(cap[v]==0 for v in e):continue
   if any(em&q and em&q!=q for q in markmasks):continue
   items.append((em,e))
 subs=[]
 for s in range(1<<n):
  subs.append((s,s.bit_count(),sum(d[v] for v in range(n) if s>>v&1),all(s&e!=e for e in linkmasks),sum(s&e==e for e in linkmasks)))
 count=[0];t=time.time();local=set()
 def process(es):
  count[0]+=1
  for U in range(1<<n):
   if U&must!=must:continue
   out=[[0]*7 for j in range(5)];rows=[[0]*8 for j in range(12)]
   for s,k,w,lf,tt in subs:
    if s&U!=s or any(s&e==e for e in es):continue
    out[0][k]+=1;out[2][k]+=w;out[4][k]+=tt
    if lf:out[1][k]+=1;out[3][k]+=w
    for r in (0,1):
     if r and not lf:continue
     if li==4:
      b=r+bool(s&1)
      for a in (1,2,3):
       x=int(bool(s&(1<<a)))
       y=int(bool(U&(1<<a)) and all((s&(e^(1<<a)))!=e^(1<<a) for e in es if e&(1<<a)))
       rows[b*4+x*2+y][k+r]+=1
     else:
      for q in markmasks:
       b=(s&q).bit_count();y=int(all(s&e!=e for e in linkmasks if e!=q))
       rows[b*4+r*2+y][k+r]-=2
   local.add((int(li==4),mm)+tuple(x for aa in out for x in aa)+tuple(x for aa in rows for x in aa))
 def rec(start,degs,es):
  process(es)
  for j in range(start,len(items)):
   mask,vs=items[j]
   if any(degs[v]>=cap[v] for v in vs):continue
   dd=list(degs)
   for v in vs:dd[v]+=1
   rec(j+1,dd,es+(mask,))
 rec(0,[0]*n,())
 views.update(local);stats.append((li,mm,count[0],len(local)));print(stats[-1],time.time()-t,flush=True)
json.dump({'stats':stats,'views':sorted(views)},open(__import__('pathlib').Path(__file__).with_name('local_views.json'),'w'))
print('total',len(views),flush=True)
