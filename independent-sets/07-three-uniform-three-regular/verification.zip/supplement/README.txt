Supplement to "Independent Sets in 3-Uniform 3-Regular Hypergraphs"

Requirements and reproduction
----------------------------
Python 3.10 or later, standard library only. No network access, optimization
solver, numerical library, or external research directory is needed.
Keep the four subdirectories together and run, from this directory:

    python3 verify_all.py

The command regenerates the local tables and certificate JSON files before
checking them with independent implementations. It does not trust saved PASS
flags. Assertions must remain enabled; do not use Python's -O or -OO options.
The full check took about 29 seconds with Python 3.14.3 in the preparation
environment; slower machines may take several minutes. The runner records
its elapsed time and the interpreter version in verification_summary.json. All mathematical
comparisons use integer or exact rational arithmetic. Floating-point values
appear only in elapsed times and a displayed interval diagnostic.

What is certified
-----------------
1. general/: the local inequality used in the main total-count theorem.
   generate_views.py exhaustively enumerates the five root-link types, the
   admissible residual constraints and available-neighbor sets, and the twin
   markings. It writes 800 distinct local polynomial vectors to local_views.json.
   verify.py constructs the integer slack for each vector and verifies that
   every coefficient of (1+x)^D S(x/(1+x)) is nonnegative, where D is the actual
   degree of that slack. There are 62 identically zero slacks; the largest
   nonzero degree is 16. certificate.json records the multipliers and slacks.
   interval_extension.py additionally checks every integer coefficient of
   3^D(1+x)^D S(5x/(3(1+x))). This proves the same local inequality
   throughout 0 <= lambda <= 5/3, without a grid check.
   verify.py also verifies the exact 1024-term rational integral bound and
   the logarithmic comparison giving the constant 259/379500.
   interval_extension.py verifies the 2048-term rational upper sum and
   logarithm-series comparison giving a deficit greater than 1/10000 at
   lambda=2/3, and the derivative comparison on the rest of the interval.

   independent_audit.py reconstructs the local table using a different family
   enumeration, all twin markings rather than symmetry representatives, and
   direct enumeration of the state including the root. Sparse integer
   arithmetic rechecks every slack and its interval transform. For the four
   unmarked nonstar links it invokes ../twinfree/independent_twinfree_audit.py;
   that file is part of this package. independent_interval_audit.py separately
   verifies the extended transform and the 2048-term rational integral bound
   giving a deficit greater than 1/10000 at lambda=2/3. It uses a shorter
   logarithm series than interval_extension.py. The original independent
   audit also rechecks the total-count integration bound. No source files
   outside this package are read.

2. linear/: the all-activity local inequality for linear hypergraphs.
   verify_linear_cubic.py enumerates the 2038 residual-constraint families
   among 20 possible constraints, all 130432 available-set-marked views, and
   their 112 distinct polynomial pairs. All 112 slack polynomials have
   nonnegative integer coefficients; exactly two are zero. It also checks
   the strict comparison with the reference occupancy fraction for lambda>0.
   independent_linear_audit.py uses all 2^20 family masks and direct subset
   sums, and independently reproduces the table and every polynomial slack.

3. twinfree/: the occupancy bound for hypergraphs with no twin pair.
   verify_twinfree_cubic.py covers the four nonstar links, with respectively
   15453, 507, 31 and 5 constraint families. The reduced table consists of
   571 polynomial triples. Its integer slacks have nonnegative coefficients.
   The verifier also checks the decreasing rational integrand, the 1024-term
   rational upper sum, and the reference comparison after lambda=1+x.
   independent_twinfree_audit.py generates 585 five-polynomial vectors before
   reducing to the same 571 triples, and independently checks all inequalities.
   It is invoked by the general independent audit in the full runner.

4. transversal/: the local estimate for an exact transversal and lambda>=1.
   verify.py derives all 93 marked link types. Two are identities; the other
   91 give 25 distinct normalized expressions. It certifies each expression
   at most 199/200 on 0 <= z <= 891/1000 using outward-rounded integer interval
   arithmetic at scale 2^60. This interval covers z=(2/(lambda+3))^(1/6) for
   lambda>=1. The adaptive subdivision has 963 nodes, 3510 expression/interval
   leaf bounds and maximum depth 15. certificate.json summarizes the result;
   interval_leaves.json gives the subdivision and all certified upper bounds.
   independent_audit.py regenerates the 91 expressions, checks that all 25
   domains are covered without gaps, and recomputes every leaf bound using
   a separate implementation at scale 2^90 with direct three-half powers.

Data conventions for general/local_views.json
---------------------------------------------
Polynomial coefficient arrays are in increasing powers of lambda. Each view
is an integer array of length 133, with these fields in order:
  star indicator; number of marked twin pairs;
  five length-7 arrays q0, q1, w0, w1, t0;
  twelve length-8 signed incidence arrays indexed by 4*b + 2*x + y.
Here b is the number of occupied vertices in a twin pair (0, 1, or 2), x is
the occupation indicator of its leaf, and y is that leaf's availability when
the incident book edge is ignored. The main certificate uses arrays 8 and 9,
corresponding to b=2, x=0, and y=0 or 1. They represent unnormalized local
generating functions, not probabilities. The local partition function is
q0 + lambda*q1. The integer slack in certificate.json is 6*Q times this
partition function times the normalized local inequality in the paper.

Logical scope
-------------
The scripts establish exhaustive finite local inequalities. The paper proves
that every hypergraph under the stated hypotheses is represented among these
local views, proves the averaging identities, and carries out the global
integration and equality arguments. No sampling of original hypergraphs is
used as a substitute for those mathematical reductions. The general total-
count theorem is independent of the transversal interval certificate; the
latter is used only for the additional exact-transversal conclusion. The
general component stability on [2/3,5/3] uses a separate analytic full-book
argument and an edge-to-book expansion, requiring no new finite certificate.

Individual checks
-----------------
The following order reproduces the full runner manually:
  python3 twinfree/verify_twinfree_cubic.py
  python3 general/generate_views.py
  python3 general/verify.py
  python3 general/independent_audit.py
  python3 general/interval_extension.py
  python3 general/independent_interval_audit.py
  python3 linear/verify_linear_cubic.py
  python3 linear/independent_linear_audit.py
  python3 transversal/verify.py
  python3 transversal/independent_audit.py
