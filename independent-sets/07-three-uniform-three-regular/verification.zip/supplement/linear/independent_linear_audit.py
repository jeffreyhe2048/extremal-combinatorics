#!/usr/bin/env python3
"""Independent exhaustive audit: flat family masks, direct subset sums, integer polynomials."""
from itertools import combinations
from pathlib import Path
import json
import hashlib

HERE = Path(__file__).resolve().parent
root_pairs = (0b000011, 0b001100, 0b110000)
# Independent numeric-mask generation, rather than recursive constraint generation.
constraints = [s for s in range(64) if s.bit_count() in (2, 3)
               and all(s & p != p for p in root_pairs)]
assert len(constraints) == 20
vertices = [[v for v in range(6) if s >> v & 1] for s in constraints]
pair_sets = [set(combinations(vs, 2)) for vs in vertices]
root_free = [all(s & p != p for p in root_pairs) for s in range(64)]
views = set()
families = 0
for mask in range(1 << 20):
    degrees = [0] * 6
    used_pairs = set()
    active = []
    rem = mask
    while rem:
        bit = rem & -rem
        j = bit.bit_length() - 1
        rem -= bit
        if used_pairs.intersection(pair_sets[j]):
            break
        used_pairs.update(pair_sets[j])
        for v in vertices[j]:
            degrees[v] += 1
        if max(degrees) > 2:
            break
        active.append(constraints[j])
    else:
        families += 1
        legal = [s for s in range(64) if not any(s & e == e for e in active)]
        for available in range(64):
            q0 = [0] * 7
            q1 = [0] * 7
            for s in legal:
                if s & available == s:
                    q0[s.bit_count()] += 1
                    if root_free[s]:
                        q1[s.bit_count()] += 1
            views.add(tuple(q0 + q1))

# Fixed-length convolution deliberately differs from the source verifier.
def product(a, b):
    c = [0] * 20
    for i in range(len(a)):
        for j in range(len(b)):
            if a[i] and b[j]:
                assert i + j < 20
                c[i + j] += a[i] * b[j]
    return c

A = [0, 1, 6, 16, 20, 10, 2]
B = [1, 7, 25, 48, 45, 18, 3]
C = [0, 0, 6, 24, 30, 12, 2]
P = [1, 9, 36, 75, 81, 42, 9]
slacks = []
for view in sorted(views):
    q0, q1 = list(view[:7]), list(view[7:])
    z = q0 + [0]
    for k in range(7):
        z[k + 1] += q1[k]
    D = [k * q0[k] for k in range(7)] + [0]
    for k in range(7):
        D[k + 1] += k * q1[k]
    az = product(A, z)
    bq = product([b - c for b, c in zip(B, C)], [0] + q1)
    cd = product(C, D)
    slack = [6 * u - 6 * v - w for u, v, w in zip(az, bq, cd)]
    assert all(s >= 0 for s in slack), (view, slack)
    slacks.append(slack)
gap_left = product([k * p for k, p in enumerate(P)], B)
gap_right = product(P, A)
gap = [u - 9 * v for u, v in zip(gap_left, gap_right)]
assert gap[:12] == [0, 0, 0, 0, 36, 291, 966, 1713, 1764, 1053, 324, 36]
assert not any(gap[12:])
assert families == 2038 and len(views) == 112
zero_views = [v for v, s in zip(sorted(views), slacks) if not any(s)]
assert len(zero_views) == 2

source = json.loads((HERE / 'linear_cubic_certificate.json').read_text())
assert {tuple(v) for v in source['views']} == views
for v, s in zip(source['views'], source['slacks']):
    j = sorted(views).index(tuple(v))
    assert s + [0] * (20 - len(s)) == slacks[j]
result = {
    'status': 'PASS',
    'method': 'All 2^20 family masks; direct subset enumeration; independent fixed-length integer convolution',
    'families': families,
    'marked_views': families * 64,
    'polynomial_pairs': len(views),
    'zero_slack_views': zero_views,
    'reference_gap': gap[:12],
    'source_certificate_sha256': hashlib.sha256((HERE / 'linear_cubic_certificate.json').read_bytes()).hexdigest(),
    'scope': 'Exact finite local inequality; global proof requires the separately audited conditional-neighborhood argument.'
}
(HERE / 'independent_linear_audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
