#!/usr/bin/env python3
"""Exact local-view certificate; no third-party packages or floating point arithmetic in inequalities."""
import itertools,json,math,time
from pathlib import Path
OUT=Path(__file__).with_name('linear_cubic_certificate.json')
from collections import Counter
pairs=[(0,1),(2,3),(4,5)]
items=[c for k in (2,3) for c in itertools.combinations(range(6),k) if all(not set(p)<=set(c) for p in pairs)]
items=[(sum(1<<x for x in c),tuple(c),sum(1<<(u*6+v) for u,v in itertools.combinations(c,2))) for c in items]
subsets=[(s,s.bit_count(),all(s&((1<<a)|(1<<b))!=((1<<a)|(1<<b)) for a,b in pairs)) for s in range(64)]
views=set(); family_count=0

def process(es):
 global family_count
 family_count+=1
 # zeta with generating coefficients: allowed subsets grouped by available-set
 pol0=[[0]*7 for _ in range(64)];pol1=[[0]*7 for _ in range(64)]
 for s,k,linkfree in subsets:
  if all(s&e!=e for e in es):
   pol0[s][k]=1
   if linkfree:pol1[s][k]=1
 for i in range(6):
  for s in range(64):
   if s>>i&1:
    for k in range(7):
     pol0[s][k]+=pol0[s^(1<<i)][k];pol1[s][k]+=pol1[s^(1<<i)][k]
 for s in range(64):views.add(tuple(pol0[s]+pol1[s]))

def rec(start,deg,used,es):
 process(es)
 for j in range(start,len(items)):
  mask,vs,ps=items[j]
  if ps&used or any(deg[v]==2 for v in vs):continue
  dd=list(deg)
  for v in vs:dd[v]+=1
  rec(j+1,dd,used|ps,es+(mask,))
t=time.time();rec(0,[0]*6,0,())
print('families',family_count,'views',len(views),'seconds',time.time()-t)
views=sorted(views)

def add(a,b):
 c=[0]*max(len(a),len(b))
 for i,x in enumerate(a):c[i]+=x
 for i,x in enumerate(b):c[i]+=x
 return trim(c)
def trim(a):
 a=list(a)
 while len(a)>1 and a[-1]==0:a.pop()
 return a
def scale(a,c):return trim([c*x for x in a])
def mul(a,b):
 c=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):c[i+j]+=x*y
 return trim(c)
def pow(a,k):
 c=[1]
 for _ in range(k):c=mul(c,a)
 return c
u=[1,1];v=[1,2];l=[0,1]
A=mul(l,add(pow(v,3),scale(mul(pow(l,2),mul(u,add(pow(u,2),v))),2)))
B=add(add(pow(u,6),mul(l,pow(v,3))),scale(mul(pow(l,2),mul(pow(u,2),add(pow(u,2),v))),2))
C=scale(add(pow(u,6),scale(pow(v,3),-1)),2)
print('A',A,'B',B,'C',C)
vs=views;pols=[]
for i,p in enumerate(vs):
 z0=trim(p[:7]);z1=trim(p[7:]);z=add(z0,mul(l,z1));D=add([k*x for k,x in enumerate(z0)],mul(l,[k*x for k,x in enumerate(z1)]))
 q=add(add(scale(mul(A,z),6),scale(mul(add(B,scale(C,-1)),mul(l,z1)),-6)),scale(mul(C,D),-1))
 assert min(q)>=0, (i,q)
 pols.append(q)
print('zero',sum(not any(p) for p in pols),'total',len(pols))

P=add(pow(u,6),mul(add(pow(u,3),[-1]),pow(v,3)))
gap=add(mul([k*x for k,x in enumerate(P)],B),scale(mul(P,A),-9))
assert all(x>=0 for x in gap) and gap[4]>0
assert family_count==2038 and len(views)==112
assert sum(not any(p) for p in pols)==2
json.dump({'status':'PASS','families':family_count,'marked_views':64*family_count,'polynomial_pairs':len(views),'A':A,'B':B,'C':C,'P':P,'reference_gap':gap,'views':views,'slacks':pols},OUT.open('w'),indent=2)
print('PASS: all activity values lambda>=0; output',OUT)
