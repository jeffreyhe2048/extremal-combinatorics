#include <array>
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <set>
#include <vector>
using namespace std;
int main(){
 long long den,pn,pd;cin>>den>>pn>>pd;long long Q[2][128][128];for(auto &a:Q)for(auto &b:a)for(auto &x:b)cin>>x;
 int nc;cin>>nc;vector<array<int,3>>contexts(nc);vector<vector<long long>> filt(nc,vector<long long>(2*128*128));for(int c=0;c<nc;c++){cin>>contexts[c][0]>>contexts[c][1]>>contexts[c][2];for(auto &x:filt[c])cin>>x;}
 int ab[3][3],bb[3][3],rb[3][3],z=0;for(int i=0;i<3;i++)for(int j=0;j<3;j++){ab[i][j]=bb[i][j]=-1;if(i!=j){ab[i][j]=z;bb[i][j]=z+6;z++;}rb[i][j]=12+3*i+j;}
 int hb[6][6];for(int u=0;u<6;u++)for(int v=0;v<6;v++){if(u==v)hb[u][v]=-1;else if(u<3&&v<3)hb[u][v]=bb[u][v];else if(u>=3&&v>=3)hb[u][v]=ab[u-3][v-3];else if(u<3)hb[u][v]=rb[u][v-3];else hb[u][v]=rb[v][u-3];}
 set<int> reqs;int perm[6]={0,1,2,3,4,5};do{int m=0;for(int i=0;i<5;i++)for(int j=i+1;j<5;j++)m|=1<<hb[perm[i]][perm[j]];reqs.insert(m);}while(next_permutation(perm,perm+6)); vector<int>req(reqs.begin(),reqs.end());
 int perms[6][3]={{0,1,2},{0,2,1},{1,0,2},{1,2,0},{2,0,1},{2,1,0}};long long legal=0,hist[7]={},minslack=INT64_MAX;int worstmask=-1;const long long common=288*den; if(common%pd){cerr<<"bad denominator";return 2;}const long long bound=pn*(common/pd);
 for(int mask=0;mask<(1<<21);mask++){
  bool bad=false;for(int r:req)if((mask&r)==r){bad=true;break;}if(bad)continue;legal++;
  auto bit=[&](int b){return (mask>>b)&1;};int H[6][6];for(int u=0;u<6;u++)for(int v=0;v<6;v++)H[u][v]=(u==v?0:bit(hb[u][v]));
  int pc=0;for(auto &p:perms)pc+=bit(ab[p[0]][p[1]])*bit(bb[p[1]][p[2]])*bit(rb[p[0]][p[2]]);hist[pc]++;
  auto flag=[&](int i,int j){return bit(ab[i][j])+2*bit(ab[j][i])+4*bit(bb[i][j])+8*bit(bb[j][i])+16*bit(rb[i][j])+32*bit(rb[j][i])+64*bit(rb[j][j]);};
  long long val=48*den*pc;for(int i=0;i<3;i++){int j=(i+1)%3,k=(i+2)%3;val+=96*Q[bit(rb[i][i])][flag(i,j)][flag(i,k)];}
  for(int ctx=0;ctx<nc;ctx++){
   int t=contexts[ctx][0],side=contexts[ctx][1],orientation=contexts[ctx][2],w[2]={t,4-t};
   for(int i=0;i<3;i++){
    int j=(i+1)%3,k=(i+2)%3;long long coef=filt[ctx][bit(rb[i][i])*128*128+128*flag(i,j)+flag(i,k)];if(!coef)continue;long long g=0;
    for(int sj=0;sj<2;sj++)for(int sk=0;sk<2;sk++){
     int root=3*side+i,uj=3*sj+j,vk=3*sk+k;int n1=orientation?H[uj][root]:H[root][uj];int n2=orientation?H[vk][root]:H[root][vk];g+=w[sj]*w[sk]*n1*n2*(4-3*H[uj][vk]-3*H[vk][uj]);
    }
    val+=coef*g;
   }
  }
  long long slack=bound-val;if(slack<minslack){minslack=slack;worstmask=mask;}
  if(slack<0){cerr<<"FAIL mask "<<mask<<" slack "<<slack<<" denominator "<<common<<"\n";return 1;}
 }
 cout<<"{\"result\":\"PASS\",\"legal_patterns\":"<<legal<<",\"forbidden_masks\":"<<req.size()<<",\"minimum_slack_numerator\":"<<minslack<<",\"common_denominator\":"<<common<<",\"worst_mask\":"<<worstmask<<",\"objective_histogram\":[";for(int i=0;i<7;i++){if(i)cout<<",";cout<<hist[i];}cout<<"]}\n";
}
