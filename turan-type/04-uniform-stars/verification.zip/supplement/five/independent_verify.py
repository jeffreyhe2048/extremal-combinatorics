"""Independent exact verification. Does not use search or compressed rows."""
from pathlib import Path
from fractions import Fraction
import json,itertools,subprocess,tempfile,sys,hashlib

cert_path=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('certificate.json')
c=json.loads(cert_path.read_text())
D=c['denominator']; target=Fraction(*c['target'])
assert D==10**8 and target==Fraction(12,25)
terms=[list(x) for k in range(3) for x in itertools.combinations(range(7),k)]
assert terms==c['feature_terms'] and c['matrix_dimension']==len(terms)==29
inputs=c['inputs']; assert len(inputs)==32
contexts=sorted({(x['h'],x['side'],x['orientation']) for x in inputs})
for x in inputs:
    assert isinstance(x['multiplier'],int) and x['multiplier']>=0
    assert x['h'] in range(5) and x['side'] in (0,1) and x['orientation'] in (0,1)
    assert x['root_type'] in (-1,0,1) and x['selector'] in range(15)
qlook=[];pivots=[]
for Q in c['Q']:
    assert len(Q)==29 and all(len(row)==29 for row in Q)
    assert all(isinstance(x,int) for row in Q for x in row)
    assert all(Q[i][j]==Q[j][i] for i in range(29) for j in range(29))
    # Exact Schur complements, not floating eigenvalues.
    M=[[Fraction(x) for x in row] for row in Q]
    block=[]
    for i in range(29):
        p=M[i][i]; assert p>0
        block.append(str(p/D))
        for j in range(i+1,29):
            for k in range(j,29):
                M[j][k]-=M[j][i]*M[i][k]/p
                M[k][j]=M[j][k]
    pivots.append(block)
    feats=[[j for j,t in enumerate(terms) if all(f>>b&1 for b in t)] for f in range(128)]
    qlook.extend(sum(Q[i][j] for i in feats[f] for j in feats[g]) for f in range(128) for g in range(128))
src=r'''
#include <iostream>
#include <array>
#include <cstdint>
#include <limits>
using namespace std;
int main(){
 long long bound,D,gram[2][128][128];cin>>bound>>D;
 for(auto &block:gram)for(auto &row:block)for(auto &x:row)cin>>x;
 int nc,ni;cin>>nc;int ctx[30][3];for(int q=0;q<nc;q++)for(int j=0;j<3;j++)cin>>ctx[q][j];
 cin>>ni;long long inputs[300][4];for(int q=0;q<ni;q++)for(int j=0;j<4;j++)cin>>inputs[q][j];
 int pick[15][128];for(int s=0;s<15;s++)for(int f=0;f<128;f++)pick[s][f]=s==0?1:((f>>((s-1)/2)&1)==(s%2));
 long long legal=0,bad=0,minslack=LLONG_MAX,maxscore=LLONG_MIN; unsigned worst=0;
 int pairs[6][2]={{0,1},{0,2},{1,0},{1,2},{2,0},{2,1}};
 int perms[6][3]={{0,1,2},{0,2,1},{1,0,2},{1,2,0},{2,0,1},{2,1,0}};

 for(unsigned mask=0;mask<(1u<<21);mask++){
  int A[3][3]={},B[3][3]={},R[3][3]={};
  for(int k=0;k<6;k++){A[pairs[k][0]][pairs[k][1]]=(mask>>k)&1;B[pairs[k][0]][pairs[k][1]]=(mask>>(6+k))&1;}
  for(int i=0;i<3;i++)for(int j=0;j<3;j++)R[i][j]=(mask>>(12+3*i+j))&1;
  int h[6][6]={};unsigned out[6]={};
  for(int i=0;i<3;i++)for(int j=0;j<3;j++){
   h[i][j]=B[i][j];h[3+i][3+j]=A[i][j];h[i][3+j]=h[3+j][i]=R[i][j];
  }
  for(int i=0;i<6;i++)for(int j=0;j<6;j++)if(h[i][j])out[i]|=1u<<j;
  bool forbidden=false;
  // TT5: a prefix arc a->b and a TT3 in the common out-neighbourhood.
  for(int a=0;a<6&&!forbidden;a++)for(int b=0;b<6&&!forbidden;b++)if(h[a][b]){
   unsigned common=out[a]&out[b];
   for(int c=0;c<6&&!forbidden;c++)if(common>>c&1){unsigned rest=common&out[c];for(int v=0;v<6;v++)if((rest>>v&1)&&(out[v]&rest)){forbidden=true;break;}}
  }
  if(forbidden){bad++;continue;} legal++;
  long long p=0,z=0,g[30][3]={};int flags[3][2];
  for(auto &v:perms)p+=A[v[0]][v[1]]*B[v[1]][v[2]]*R[v[0]][v[2]];
  for(int root=0;root<3;root++){
   int codes[2],at=0;
   for(int j=0;j<3;j++)if(j!=root){
    int b[7]={A[root][j],A[j][root],B[root][j],B[j][root],R[root][j],R[j][root],R[j][j]};
    codes[at]=0;for(int k=0;k<7;k++)codes[at]|=b[k]<<k;flags[root][at]=codes[at];at++;
   }
   z+=gram[R[root][root]][codes[0]][codes[1]];
  }
  for(int q=0;q<nc;q++)for(auto &v:perms)for(int s=0;s<2;s++)for(int t=0;t<2;t++){
   int root=3*ctx[q][1]+v[0],j=3*s+v[1],k=3*t+v[2];
   int hitj=ctx[q][2]?h[j][root]:h[root][j],hitk=ctx[q][2]?h[k][root]:h[root][k];
   int ws=s==0?ctx[q][0]:4-ctx[q][0],wt=t==0?ctx[q][0]:4-ctx[q][0];
   g[q][v[0]]+=hitj*hitk*ws*wt*(2-3*h[j][k]);
  }
  long long score=48*D*p+96*z;
  for(int q=0;q<ni;q++)for(int i=0;i<3;i++){
   int context=inputs[q][0],type=inputs[q][1],sel=inputs[q][2];
   if((type<0||type==R[i][i])&&pick[sel][flags[i][0]]&&pick[sel][flags[i][1]])score+=inputs[q][3]*g[context][i];
  }
  if(score>maxscore){maxscore=score;worst=mask;}
  if(bound-score<minslack)minslack=bound-score;
  if(score>bound){cerr<<"negative slack "<<mask<<" "<<bound-score<<endl;return 1;}
 }
 cout<<"{\"legal_patterns\":"<<legal<<",\"forbidden_patterns\":"<<bad
     <<",\"minimum_integer_slack\":"<<minslack<<",\"common_denominator\":"<<288*D
     <<",\"worst_pattern\":"<<worst<<"}"<<endl;
}
'''.replace('#include <limits>','#include <limits>\n#include <climits>')
with tempfile.TemporaryDirectory(prefix='s4-independent-') as td:
    f=Path(td)/'verify.cpp';exe=Path(td)/'verify'
    f.write_text(src)
    subprocess.run(['clang++','-O2','-std=c++17',str(f),'-o',str(exe)],check=True)
    b=target*288*D; assert b.denominator==1
    data_list=[int(b),D]+qlook+[len(contexts)]+[v for x in contexts for v in x]+[len(inputs)]
    for x in inputs:data_list.extend([contexts.index((x['h'],x['side'],x['orientation'])),x['root_type'],x['selector'],x['multiplier']])
    data=' '.join(map(str,data_list))
    result=json.loads(subprocess.run([str(exe)],input=data,text=True,capture_output=True,check=True).stdout)
assert result['legal_patterns']==2049852 and result['legal_patterns']+result['forbidden_patterns']==2**21
result.update(status='PASS',certificate_sha256=hashlib.sha256(cert_path.read_bytes()).hexdigest(),
              positive_definite_blocks=2,rational_schur_pivots=pivots,
              independence='Direct common-out-neighbour TT5 test; individual selector evaluation and ordered-permutation neighbourhood sums; no selector lookup tables or search code.')
output=Path(__file__).with_name('independent_verification.json')
output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='rational_schur_pivots'}))
