import json,itertools,subprocess,tempfile,time
from fractions import Fraction as F
from pathlib import Path
ROOT=Path(__file__).resolve().parent
j=json.load(open(ROOT/'certificate.json'));D=j['denominator'];terms=[list(t) for d in range(3) for t in itertools.combinations(range(7),d)];assert terms==j['feature_terms'];assert j['target']==[37,100];assert D>0
for z in j['inputs']:
 assert 0<=z['h']<=4 and z['side'] in (0,1) and z['orientation'] in (0,1) and z['root_type'] in (-1,0,1) and 0<=z['selector']<=14 and z['multiplier']>=0
mins=[]
for z in j['Q']:
 assert len(z)==29 and all(len(row)==29 for row in z);assert all(z[i][k]==z[k][i] for i in range(29) for k in range(29));a=[[F(x) for x in row] for row in z];piv=[]
 for k in range(29):
  d=a[k][k];assert d>0,(k,d);piv.append(d/D)
  for i in range(k+1,29):
   for h in range(i,29):
    a[h][i]-=a[h][k]*a[i][k]/d;a[i][h]=a[h][i]
 mins.append(str(min(piv)))
phi=[[i for i,t in enumerate(terms) if all((f>>b)&1 for b in t)] for f in range(128)]
data=[str(D),'37','100']
for z in j['Q']:
 for f in range(128):
  for g in range(128):data.append(str(sum(z[i][k] for i in phi[f] for k in phi[g])))
def selector(f,sel):
 if sel==0:return 1
 b=(sel-1)//2;x=(f>>b)&1;return x if sel%2 else 1-x
contexts=sorted(set((z['h'],z['side'],z['orientation']) for z in j['inputs']));data.append(str(len(contexts)))
for ctx in contexts:
 data.extend(map(str,ctx));inps=[z for z in j['inputs'] if (z['h'],z['side'],z['orientation'])==ctx]
 for b in range(2):
  zz=[z for z in inps if z['root_type'] in (-1,b)]
  for f in range(128):
   for g in range(128):data.append(str(sum(z['multiplier']*selector(f,z['selector'])*selector(g,z['selector']) for z in zz)))
t=time.time()
with tempfile.TemporaryDirectory() as tmp:
 exe=Path(tmp)/'verify';subprocess.run(['clang++','-O3','-std=c++17',str(ROOT/'scan.cpp'),'-o',str(exe)],check=True)
 out=subprocess.run([str(exe)],input=' '.join(data),text=True,capture_output=True,check=True);print(out.stdout);v=json.loads(out.stdout)
v['positive_definite_LDL_pivots']=mins;v['number_of_nonzero_inputs']=len(j['inputs']);v['elapsed_seconds']=time.time()-t;json.dump(v,open(ROOT/'verification.json','w'),indent=2)
