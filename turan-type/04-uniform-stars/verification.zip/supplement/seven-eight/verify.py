#!/usr/bin/env python3
"""Exact verification of the S7/S8 six-variable majorants (standard library)."""
from fractions import Fraction as F
from itertools import product
from math import prod, comb
from pathlib import Path
import hashlib
import json
import time

ROOT = Path(__file__).resolve().parent

def unpack(v, sector):
    x, z, y, w, e, f = v
    a, b, c, d = x, x*z, y, y*w
    if sector & 1:
        a, b = b, a
    if sector & 2:
        c, d = d, c
    return a, b, c, d, e, f

def numerator(v, r, sector):
    x, z, y, w, e, f = v
    a, b, c, d, e, f = unpack(v, sector)
    factors = [1-x, 1-y, 2-y-e, 2-x-f]
    D = prod(factors)
    local = a*e+b*c+d*f-(a+b+c+d+e+f)/2
    return ((r-2)*sum((1 if j < 2 else 4)*prod(factors[t] for t in range(4) if t != j)
                      for j in range(4))
            -6*r*(2*r-3)*D-2*r**3*local*D)

def verify_tensor_identity(data):
    """No use of discovery's polynomial-expansion code.

    Both sides have coordinate degrees at most (3,1,3,1,2,2).
    Equality on the full unisolvent tensor grid proves polynomial identity.
    """
    r, sector = data['r'], data['sector']
    deg = data['degrees']
    assert deg == [3, 1, 3, 1, 2, 2]
    indices = list(product(*[range(d+1) for d in deg]))
    coeff = data['coefficients']
    assert len(coeff) == len(indices) == 576
    assert all(type(c) is int for c in coeff)
    den = prod(d**d for d in deg)
    scale = data['scale']
    assert type(scale) is int and scale > 0
    for grid in indices:
        point = [F(i, d) for i, d in zip(grid, deg)]
        basis = [[comb(d, j)*i**j*(d-i)**(d-j) for j in range(d+1)]
                 for i, d in zip(grid, deg)]
        lhs = sum(c*prod(basis[t][index[t]] for t in range(6))
                  for c, index in zip(coeff, indices))
        rhs = numerator(point, r, sector)*scale*den
        assert lhs == rhs, ('tensor identity', r, sector, grid)
    return len(indices)

def verify_case(data):
    start = time.perf_counter()
    r, sector = data['r'], data['sector']
    assert r in (6, 7) and sector in range(4)
    tensor_points = verify_tensor_identity(data)
    deg = data['degrees']
    size = prod(d+1 for d in deg)
    strides = [prod(d+1 for d in deg[i+1:]) for i in range(6)]
    groups = [[list(range(i, i+(deg[a]+1)*strides[a], strides[a]))
               for i in range(size) if (i//strides[a]) % (deg[a]+1) == 0]
              for a in range(6)]
    tree = {}
    for kind, path in data['leaves']:
        assert kind in ('P', 'A', 'B') and path
        node = tree
        for ch in path:
            assert 'leaf' not in node and 'A' <= ch <= 'L'
            node = node.setdefault(ch, {})
        assert not node, 'duplicate leaf or prefix conflict'
        node['leaf'] = kind
    p = 1-F(3,r)+F(3,r*r)
    q = F(r-1,r)
    h = F(1,2)+F(1,r)
    counts = {'P': 0, 'A': 0, 'B': 0}
    nodes = 0
    max_depth = 0

    def split(coeff, axis):
        """Integer de Casteljau; children share a positive factor 2^degree."""
        left, right = [0]*size, [0]*size
        d = deg[axis]
        for group in groups[axis]:
            work = [coeff[i] for i in group]
            left[group[0]] = work[0] << d
            right[group[d]] = work[d] << d
            for step in range(1,d+1):
                for j in range(d-step+1):
                    work[j] += work[j+1]
                left[group[step]] = work[0] << (d-step)
                right[group[d-step]] = work[d-step] << (d-step)
        return left, right

    def visit(node, coeff, lower, upper, depth):
        nonlocal nodes, max_depth
        nodes += 1
        max_depth = max(max_depth, depth)
        if 'leaf' in node:
            assert len(node) == 1
            kind = node['leaf']
            counts[kind] += 1
            if kind == 'B':
                assert min(coeff) >= 0, ('negative Bernstein coefficient', r, sector, depth)
            elif kind == 'P':
                a,b,c,d,e,f = unpack(upper,sector)
                assert min(q,a*e)+b*c+min(q,d*f) < 3*p, ('invalid domain pruning',r,sector)
            else:
                assert min(unpack(lower,sector)) >= F(1,2)
                assert lower[0] >= h and lower[2] >= h
                assert lower[0]+lower[5] >= 2*h and lower[2]+lower[4] >= 2*h
            return
        assert len(node) == 2, 'partition must be binary'
        keys = sorted(node)
        axis = (ord(keys[0])-ord('A'))//2
        assert keys == [chr(ord('A')+2*axis),chr(ord('A')+2*axis+1)], 'two halves must split same axis'
        left,right = split(coeff,axis)
        midpoint = (lower[axis]+upper[axis])/2
        left_upper = upper.copy(); left_upper[axis] = midpoint
        right_lower = lower.copy(); right_lower[axis] = midpoint
        visit(node[keys[0]],left,lower,left_upper,depth+1)
        visit(node[keys[1]],right,right_lower,upper,depth+1)

    visit(tree,data['coefficients'],[F(0)]*6,[F(1)]*6,0)
    assert sum(counts.values()) == len(data['leaves'])
    return {'r':r,'star':r+1,'sector':sector,'PASS':True,
            'tensor_identity_points':tensor_points,'nodes':nodes,
            'leaves':sum(counts.values()),'leaf_types':counts,'max_depth':max_depth,
            'seconds':round(time.perf_counter()-start,4)}

def check_scalar_identity():
    # Both sides become degree-three polynomials on multiplication by 2(1-t).
    for r in (6,7):
        q = F(r-1,r)
        alpha = F(r-2,2*r**3)
        gamma = F(3*(2*r-3),r*r)
        for t in (F(0),F(1,4),F(1,2),F(3,4)):
            lhs = 2*alpha-(t*t-t)*(1-t)-gamma*(1-t)/3
            rhs = (t-q)**2*(t-F(2,r))
            assert lhs == rhs
        assert 1+6*alpha*r-gamma == 1-F(3,r)+F(3,r*r)
        assert F(r*((r-1)+(r-2)**2),r**3) == 1-F(3,r)+F(3,r*r)

def main():
    path = ROOT/'certificates.json'
    raw = path.read_bytes()
    cert = json.loads(raw)
    assert cert['version'] == 1
    assert {(d['r'],d['sector']) for d in cert['cases']} == {(r,s) for r in (6,7) for s in range(4)}
    assert len(cert['cases']) == 8
    check_scalar_identity()
    results = []
    for case in cert['cases']:
        result = verify_case(case)
        results.append(result)
        print(json.dumps(result),flush=True)
    summary = {'PASS':True,'certificate_sha256':hashlib.sha256(raw).hexdigest(),
               'proof_scope':'six-variable local majorants for r=6,7; global theorem uses main.tex, Section 3',
               'arithmetic':'integers and fractions.Fraction only',
               'tensor_identity_points':sum(v['tensor_identity_points'] for v in results),
               'total_nodes':sum(v['nodes'] for v in results),
               'total_leaves':sum(v['leaves'] for v in results),
               'cases':results}
    (ROOT/'verification.json').write_text(json.dumps(summary,indent=2)+'\n')
    print('PASS: complete exact certificate verification')

if __name__ == '__main__':
    main()
