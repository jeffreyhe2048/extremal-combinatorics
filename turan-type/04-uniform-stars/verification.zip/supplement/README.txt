Exact supplement to "Uniform Turan densities of small stars"
Jialin He. Local draft, 25 October 2026.

Run with Python 3.9 or later:
  python3 run_all.py
The four/five pattern verifiers also require clang++ with C++17 support.
No external Python packages, SDP solver, or network access is needed.
The complete run makes six verification calls. The S6--S8 part checks all
12 Bernstein branches with one implementation of the Bernstein procedure,
in the two verify.py programs below. It does not have a second independent
implementation. The S4 and S5 finite-pattern inequalities each have a
primary verifier and a second implementation that sums descriptors directly.

six/ contains the S6 certificate (r=5) and its verifier.
seven-eight/ contains the S7/S8 certificates (r=6,7) and their verifier.
four/ and five/ contain rational Gram matrices, nonnegative descriptor
multipliers, a C++17 enumerator, a Python coordinator, and an independent
verifier that directly sums the individual descriptors.

The argument relating these finite computations to every finite palette
and then to uniform Turan density is proved in main.tex, Sections 2--4.
For S6--S8, weight maximization puts every hypothetical palette counterexample
in the six-variable domain; the exact subdivision covers that continuous
domain, and averaging closes the upper bound. For S4/S5, conditional
independence and weighted neighbourhood bounds give nonnegative expectations
for the terms in each finite pattern inequality. Coincident sampled colours
are retained. These arguments cover all finite colour sets and all
nonnegative real colour weights, without a prescribed bound on colour count.

The entry point writes verification_summary.json and verifier logs.
Each component writes its own exact verification report. All certificate
SHA-256 digests are listed in verification_summary.json.
No program modifies certificate data. Numerical discovery programs and
optimization output are not required to verify any theorem in the paper.
