#!/usr/bin/env python3
"""Reproduce every finite certificate of Uniform Turan densities of small stars."""
from pathlib import Path
import hashlib,json,subprocess,sys,time
root=Path(__file__).resolve().parent
checks=[]
for directory in ('six','seven-eight','four','five'):
    scripts=('verify.py','independent_verify.py') if directory in ('four','five') else ('verify.py',)
    for name in scripts:
        start=time.perf_counter()
        out=subprocess.run([sys.executable,str(root/directory/name)],cwd=root/directory,text=True,capture_output=True)
        (root/directory/(name.removesuffix('.py')+'.log')).write_text(out.stdout+out.stderr)
        if out.returncode:
            print(out.stdout+out.stderr);raise SystemExit(out.returncode)
        checks.append({'directory':directory,'verifier':name,'PASS':True,'seconds':round(time.perf_counter()-start,3)})
        print(directory,name,'PASS',flush=True)
hashes={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(root.glob('*/certificate*.json'))}
(root/'verification_summary.json').write_text(json.dumps({'PASS':True,'checks':checks,'certificate_sha256':hashes},indent=2)+'\n')
print('PASS: all six exact verification runs')
