SUPPLEMENT TO: Extremal Degree Moments in Directed Graphs
Author: Jialin He

Run from any working directory:
  python3 /path/to/supplement/run_all.py
Requirements: Python 3.9 or later (standard library only), and clang++ with
C++17 support. No numerical solver or commercial package is used. Substitute
an available C++17 compiler in the invocation if clang++ is not installed.
The verification scripts create JSON reports beside their input files.

The tournaments directory contains the mathematical proof certificate.
verify.py --regenerate reconstructs all 9558 allowed isomorphism types,
recomputes the integer flag matrices, verifies exact positive definiteness
of reduced Gram matrices of orders 35,64,63, and checks every rational slack.
independent_flag_audit.py reconstructs the coefficients by a different
placement count. independent_coverage_audit.py checks all semicomplete
labeled patterns and the disjoint orbits covering 1043695 allowed hosts.
frozen_hashes.json identifies the original certificate, coefficient data,
and independent enumeration source. It deliberately omits the internal
research note, which is not part of this paper or a verification input.

Certificate SHA256:
c4f338d995d80447aca1b4bbf29e44f3c55ebe3454795eec29afe88ca51a7cd9
Flag data SHA256:
f8061ddc1fd77a0a3ec23cf3a61c67763fe2095c07f83e8ad0e14fba60693845

The joins directory provides independent finite checks supplementary to the
complete analytic proof in Section 4. It verifies the degree and prefix
formulas, forbidden-subgraph exclusion on stated finite instances, and the
extremal classification inside the necessary forward-arc/degree class.
These bounded computations are not offered as proof of the universal
statements. The general proof is contained in the manuscript.

All included checks were rerun successfully on 25 October 2026. Some reports
preserve the original audit date as metadata. Internal proof-note hash
fields were removed from the transferred join verifiers; the mathematical
checks are unchanged. No private path or original research directory is
needed to run this supplement.
