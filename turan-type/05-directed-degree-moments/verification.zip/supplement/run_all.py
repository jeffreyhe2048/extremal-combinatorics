#!/usr/bin/env python3
"""Recheck every certificate and supplementary finite check (Python 3, C++17)."""
from pathlib import Path
import subprocess, sys
root=Path(__file__).resolve().parent
for folder,script,args in [
 ('tournaments','verify.py',['--regenerate']),
 ('tournaments','independent_flag_audit.py',[]),
 ('tournaments','independent_coverage_audit.py',[]),
 ('joins','verify.py',[]),
 ('joins','independent_verify.py',[]),
 ('joins','verify_extremal_classification.py',[])]:
 print('Checking '+folder+'/'+script,flush=True)
 subprocess.run([sys.executable,str(root/folder/script),*args],check=True)
print('All checks passed.',flush=True)
