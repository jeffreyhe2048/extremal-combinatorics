#!/usr/bin/env python3
"""Exact, standard-library verification. Use --regenerate for complete enumeration."""
from pathlib import Path
from fractions import Fraction as F
import json,math,argparse,subprocess,tempfile,hashlib
P=Path(__file__).resolve().parent

def leading_minors(Z):
    A=[row[:]for row in Z];prev=1;out=[]
    for k in range(len(A)):
        pivot=A[k][k];out.append(pivot)
        assert pivot>0,(k,pivot)
        if k==len(A)-1:break
        for i in range(k+1,len(A)):
            for j in range(k+1,len(A)):
                value=pivot*A[i][j]-A[i][k]*A[k][j]
                assert value%prev==0
                A[i][j]=value//prev
            A[i][k]=0
        prev=pivot
    return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--regenerate',action='store_true');args=ap.parse_args()
    D=json.loads((P/'flags.json').read_text());C=json.loads((P/'certificate.json').read_text())
    if args.regenerate:
        with tempfile.TemporaryDirectory(prefix='full-five-flags-')as tmp:
            w=Path(tmp);subprocess.run(['clang++','-O3','-std=c++17',str(P/'flags.cpp'),'-o',str(w/'flags')],check=True)
            subprocess.run([str(w/'flags')],cwd=w,check=True)
            assert json.loads((w/'flags.json').read_text())==D
    assert D['labeled_types']==1043695 and len(D['graphs'])==9558
    assert len(set(g['mask']for g in D['graphs']))==9558
    assert C['enumeration']=={'types':9558,'labeled':1043695}
    assert C['flag_lists']==[D['f1']]+[b['flags']for b in D['f3']]
    assert len(D['f1'])==36 and D['f3']==[{'type':31,'flags':list(range(64))},{'type':63,'flags':list(range(64))}]
    assert C['flag_denominators']==[30,120,120] and C['target']=='9/16'
    Qs=[];commons=[]
    for bi,(K,rawR)in enumerate(zip(C['K'],C['reduced_gram_matrices'])):
        assert len(K)==[36,64,64][bi]
        R=[[F(x)for x in row]for row in rawR];n=len(R)
        assert n==[35,64,63][bi] and all(len(row)==n for row in K+R)
        assert all(R[i][j]==R[j][i]for i in range(n)for j in range(n))
        den=math.lcm(*(v.denominator for row in R for v in row));Z=[[int(v*den)for v in row]for row in R]
        minors=leading_minors(Z);record=C['positive_definiteness'][bi]
        assert record['dimension']==n and int(record['common_denominator'])==den
        assert list(map(int,record['positive_leading_minors']))==minors
        z=C['kernel_vectors'][bi]
        assert all(sum(z[i]*K[i][j]for i in range(len(K)))==0 for j in range(n))
        rows=[[(j,v)for j,v in enumerate(row)if v]for row in K]
        Q=[[sum(a*b*Z[ii][jj]for ii,a in ri for jj,b in rj)for rj in rows]for ri in rows]
        Qs.append([v for row in Q for v in row]);commons.append(den)
    slacks=[]
    for g,rec in zip(D['graphs'],C['slacks']):
        value=F(g['q60'],60)
        for bi,raw in enumerate([g['m1']]+g['m3']):
            n=[36,64,64][bi];entries=dict(raw)
            assert len(entries)==len(raw)and all(0<=k<n*n and isinstance(v,int)and v>0 for k,v in raw)
            assert all(entries.get((k%n)*n+k//n,0)==v for k,v in raw)
            if bi==0:assert sum(entries.values())==30
            value+=F(sum(v*Qs[bi][k]for k,v in raw),commons[bi]*C['flag_denominators'][bi])
        slack=F(9,16)-value
        assert slack>=0 and rec['mask']==g['mask']and F(rec['value'])==slack
        slacks.append(slack)
    assert len(slacks)==len(C['slacks'])==9558
    zero=[g['mask']for g,s in zip(D['graphs'],slacks)if s==0]
    assert zero==[0,255,16380,16383,261375,262143]
    smallest=min(s for s in slacks if s>0)
    assert smallest==F(52353,2500000)==F(C['min_positive_slack'])
    result={'status':'PASS','regenerated':args.regenerate,'all_digraphs_not_just_twins':True,'labeled_types':1043695,'isomorphism_types':9558,'flag_dimensions':[36,64,64],'reduced_positive_definite_dimensions':[35,64,63],'target':'9/16','minimum_positive_slack':str(smallest),'zero_masks':zero,'certificate_sha256':hashlib.sha256((P/'certificate.json').read_bytes()).hexdigest()}
    (P/'verified.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
