#!/usr/bin/env python3
"""Independent placement count; does not call flags.cpp or verify.py."""
from pathlib import Path
from itertools import combinations, permutations
from collections import Counter
import json, hashlib

P = Path(__file__).resolve().parent
PAIRS = list(combinations(range(5), 2))
ORDERS = list(permutations(range(5)))


def three_flag(a, root, u, v):
    x = a[5*root+u]+2*a[5*u+root]+4*a[5*root+v]+8*a[5*v+root]
    x += 16*a[5*u+v]+32*a[5*v+u]
    y = a[5*root+v]+2*a[5*v+root]+4*a[5*root+u]+8*a[5*u+root]
    y += 16*a[5*v+u]+32*a[5*u+v]
    return min(x, y)


def root_flag(a, roots, free):
    return sum((a[5*r+free]+2*a[5*free+r]) << (2*i)
               for i, r in enumerate(roots))


def main():
    raw_data = (P/'flags.json').read_bytes()
    data = json.loads(raw_data)
    f1 = set()
    for bits in range(64):
        a = [0]*25
        for i,(u,v) in enumerate(combinations(range(3),2)):
            a[5*u+v] = (bits>>(2*i))&1
            a[5*v+u] = (bits>>(2*i+1))&1
        f1.add(three_flag(a,0,1,2))
    f1 = sorted(f1)
    assert len(f1)==36 and f1==data['f1']
    root_types = [r['type'] for r in data['f3']]
    assert root_types in ([63], [31,63])
    assert all(r['flags']==list(range(64)) for r in data['f3'])
    root_ids = {t:i for i,t in enumerate(root_types)}
    ids = {h:i for i,h in enumerate(f1)}
    entries1=0
    entries3=[0]*len(root_types);placements3=[0]*len(root_types)
    for row in data['graphs']:
        h = row['mask']; a=[0]*25
        for k,(u,v) in enumerate(PAIRS):
            a[5*u+v]=(h>>(2*k))&1
            a[5*v+u]=(h>>(2*k+1))&1
        deg=[sum(a[5*u+v] for v in range(5)) for u in range(5)]
        assert sum(d*(d-1) for d in deg)==row['q60']
        m1=Counter();m3=[Counter() for _ in root_types]
        # All 120 ordered placements, rather than 5 * binom(4,2).
        # Each unordered pair of free vertices is represented in two orders,
        # hence each ordered pair of one-root flags occurs four times.
        for r,u,v,w,x in ORDERS:
            aa=ids[three_flag(a,r,u,v)];bb=ids[three_flag(a,r,w,x)]
            m1[36*aa+bb]+=1
            roots=(r,u,v)
            typ=a[5*r+u]+2*a[5*u+r]+4*a[5*r+v]+8*a[5*v+r]+16*a[5*u+v]+32*a[5*v+u]
            if typ in root_ids:
                aa=root_flag(a,roots,w);bb=root_flag(a,roots,x)
                m3[root_ids[typ]][64*aa+bb]+=1
        assert m1==Counter({i:4*c for i,c in row['m1']})
        assert all(mat==Counter(dict(raw)) for mat,raw in zip(m3,row['m3']))
        assert sum(m1.values())==120
        # Each unordered digon triangle contributes 3! root labels * 2 free orders.
        triangles=sum(all(a[5*i+j] for i in t for j in t if i!=j)
                      for t in combinations(range(5),3))
        assert sum(m3[root_ids[63]].values())==12*triangles
        entries1+=len(m1)
        for i,mat in enumerate(m3):
            entries3[i]+=len(mat);placements3[i]+=sum(mat.values())
    out={'date':'2026-10-24','status':'PASS',
         'scope':'Independent flag orbit lists, all sparse matrix entries, and q60; not a PSD recheck.',
         'hosts':len(data['graphs']), 'flag_dimensions':[36]+[64]*len(root_types),
         'three_root_types':root_types,
         'ordered_one_root_placements':len(data['graphs'])*120,
         'nonzero_one_root_coordinates_checked':entries1,
         'nonzero_three_root_coordinates_checked':entries3,
         'ordered_three_root_placements':placements3,
         'denominators':[30]+[120]*len(root_types),
         'flags_sha256':hashlib.sha256(raw_data).hexdigest(),
         'independent_one_root_count_is_four_times_stored_count':True}
    assert (P/'flags.json').read_bytes()==raw_data, 'Input changed while auditing'
    (P/'independent_flag_audit.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))


if __name__=='__main__':main()
