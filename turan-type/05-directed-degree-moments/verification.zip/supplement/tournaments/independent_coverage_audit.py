#!/usr/bin/env python3
"""Third enumeration route: orient the digons of every semicomplete host."""
from pathlib import Path
from itertools import combinations, permutations, product
import hashlib,json

P=Path(__file__).resolve().parent
PAIRS=list(combinations(range(5),2))
INDEX={}
for k,(a,b) in enumerate(PAIRS):INDEX[a,b]=2*k;INDEX[b,a]=2*k+1
MAPS=[]
for p in permutations(range(5)):
    MAPS.append([INDEX[p[a],p[b]] for a,b in
                 [z for a,b in PAIRS for z in ((a,b),(b,a))]])


def relabel(h,mp):
    return sum(((h>>old)&1)<<new for new,old in enumerate(mp))


def main():
    frozen=json.loads((P/'frozen_hashes.json').read_text())
    for name,digest in frozen.items():
        assert hashlib.sha256((P/name).read_bytes()).hexdigest()==digest
    data=json.loads((P/'flags.json').read_text())
    canonical=[]
    for z in range(1024):
        h=sum((1 if z>>k&1 else 2)<<(2*k) for k in range(10))
        canonical.append(min(relabel(h,mp) for mp in MAPS))
    representatives=sorted(set(canonical));assert len(representatives)==12
    ids={h:i for i,h in enumerate(representatives)}
    tournament_bits=[1<<ids[h] for h in canonical]

    def allowed(base,free):
        cover=0;subset=free
        while True:
            cover|=tournament_bits[base|subset]
            if cover==4095:return False
            if not subset:return True
            subset=(subset-1)&free

    # All hosts with a missing adjacency are automatically allowed.
    nonsemicomplete=4**10-3**10
    allowed_semi=0
    for states in product(range(3),repeat=10):
        base=sum(1<<k for k,s in enumerate(states) if s==0)
        free=sum(1<<k for k,s in enumerate(states) if s==2)
        allowed_semi+=allowed(base,free)
    total=nonsemicomplete+allowed_semi
    assert total==1043695==data['labeled_types']

    orbit_total=0;seen_representatives=set()
    for row in data['graphs']:
        h=row['mask'];states=[(h>>(2*k))&3 for k in range(10)]
        if 0 not in states:
            base=sum(1<<k for k,s in enumerate(states) if s==1)
            free=sum(1<<k for k,s in enumerate(states) if s==3)
            assert allowed(base,free)
        orbit={relabel(h,mp) for mp in MAPS}
        c=min(orbit)
        assert c==h and c not in seen_representatives
        seen_representatives.add(c);orbit_total+=len(orbit)
    assert orbit_total==total and len(seen_representatives)==9558
    # Invariant allowed rule + disjoint canonical orbits + total count proves coverage.
    result={'date':'2026-10-24','status':'PASS','tournament_types':12,
            'semicomplete_labeled_hosts':3**10,
            'allowed_semicomplete_labeled_hosts':allowed_semi,
            'allowed_nonsemicomplete_labeled_hosts':nonsemicomplete,
            'all_allowed_labeled_hosts':total,'canonical_host_orbits':len(seen_representatives),
            'sum_of_checked_orbit_sizes':orbit_total,'frozen_core_hashes':frozen}
    for name,digest in frozen.items():
        assert hashlib.sha256((P/name).read_bytes()).hexdigest()==digest
    (P/'independent_coverage_audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='frozen_core_hashes'},indent=2))


if __name__=='__main__':main()
