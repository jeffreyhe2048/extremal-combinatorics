#include <algorithm>
#include <cassert>
#include <array>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <vector>
using namespace std;
using M=unsigned;
int ix[6][6];
int arc(M h,int a,int b){if(a==b)return 0;int k=ix[min(a,b)][max(a,b)];return (h>>(2*k+(a>b)))&1;}
M from(const vector<int>&v,M h){M z=0;int k=0;for(int i=0;i<(int)v.size();i++)for(int j=i+1;j<(int)v.size();j++,k++){z|=arc(h,v[i],v[j])<<(2*k);z|=arc(h,v[j],v[i])<<(2*k+1);}return z;}
M encode(const vector<vector<int>>&a){M z=0;int k=0;for(int i=0;i<(int)a.size();i++)for(int j=i+1;j<(int)a.size();j++,k++)z|=(a[i][j]+2*a[j][i])<<(2*k);return z;}
bool twins(const vector<vector<int>>&a){int n=a.size();for(int i=0;i<n;i++)for(int j=i+1;j<n;j++)if(!a[i][j]&&!a[j][i])for(int k=0;k<n;k++)if(k!=i&&k!=j&&(a[i][k]!=a[j][k]||a[k][i]!=a[k][j]))return false;return true;}
vector<vector<int>> decode(M h,int n){vector<vector<int>>a(n,vector<int>(n));int k=0;for(int i=0;i<n;i++)for(int j=i+1;j<n;j++,k++){a[i][j]=(h>>(2*k))&1;a[j][i]=(h>>(2*k+1))&1;}return a;}
M can(M h,int n,int fixed){auto a=decode(h,n);vector<int>v;for(int i=0;i<n;i++)v.push_back(i);M best=~0u;do{vector<vector<int>>b(n,vector<int>(n));for(int i=0;i<n;i++)for(int j=0;j<n;j++)b[i][j]=a[v[i]][v[j]];best=min(best,encode(b));}while(next_permutation(v.begin()+fixed,v.end()));return best;}
int main(int argc,char**argv){int k=0;for(int i=0;i<5;i++)for(int j=i+1;j<5;j++)ix[i][j]=k++;
 vector<int>v={0,1,2,3,4};set<M>reps;for(unsigned z=0;z<1024;z++){M h=0;for(int j=0;j<10;j++)h|=((z>>j&1)?1u:2u)<<(2*j);auto a=decode(h,5);bool regular=true;for(int i=0;i<5;i++){int d=0;for(int j=0;j<5;j++)d+=a[i][j];if(d!=2)regular=false;}reps.insert(can(h,5,0));}assert(reps.size()==12);vector<vector<M>>families;for(M t:reps){vector<M>patterns;v={0,1,2,3,4};do{patterns.push_back(from(v,t));}while(next_permutation(v.begin(),v.end()));families.push_back(patterns);}
 vector<M>types;vector<char>seen(1<<20);long labeled=0;for(M h=0;h<(1u<<20);h++){auto a=decode(h,5);bool free=false;for(const auto&patterns:families){bool contains=false;for(M f:patterns)if((h&f)==f){contains=true;break;}if(!contains){free=true;break;}}if(!free)continue;labeled++;if(seen[h])continue;types.push_back(h);v={0,1,2,3,4};do{seen[from(v,h)]=true;}while(next_permutation(v.begin(),v.end()));}
 map<M,int>f1;for(M h=0;h<64;h++)f1.emplace(can(h,3,1),0);k=0;for(auto&[h,j]:f1)j=k++;
 map<M,vector<M>>f3{{31,vector<M>()},{63,vector<M>()}};for(auto&[t,fs]:f3){auto a=decode(t,3);for(M h=0;h<64;h++){auto b=a;for(auto&r:b)r.push_back(0);b.push_back(vector<int>(4));for(int i=0;i<3;i++){b[i][3]=(h>>(2*i))&1;b[3][i]=(h>>(2*i+1))&1;}fs.push_back(h);}}
 ofstream o("flags.json");o<<"{\"labeled_types\":"<<labeled<<",\"f1\":[";bool sep=0;for(auto[h,j]:f1){if(sep)o<<",";sep=1;o<<h;}o<<"],\"f3\":[";sep=0;for(auto&[t,fs]:f3){if(sep)o<<",";sep=1;o<<"{\"type\":"<<t<<",\"flags\":[";for(int i=0;i<(int)fs.size();i++){if(i)o<<",";o<<fs[i];}o<<"]}";}o<<"],\"graphs\":[";sep=0;
 for(M h:types){if(sep)o<<",";sep=1;int q=0;for(int i=0;i<5;i++)for(int j=0;j<5;j++)for(int l=0;l<5;l++)if(i!=j&&i!=l&&j!=l)q+=arc(h,i,j)*arc(h,i,l);o<<"{\"mask\":"<<h<<",\"q60\":"<<q<<",\"m1\":[";vector<vector<int>>a1(f1.size(),vector<int>(f1.size()));for(int r=0;r<5;r++){vector<int>rest;for(int i=0;i<5;i++)if(i!=r)rest.push_back(i);for(int i=0;i<4;i++)for(int j=i+1;j<4;j++){vector<int>A={r,rest[i],rest[j]},B={r};for(int l=0;l<4;l++)if(l!=i&&l!=j)B.push_back(rest[l]);int aa=f1.at(can(from(A,h),3,1)),bb=f1.at(can(from(B,h),3,1));a1[aa][bb]++;}}
 bool s=0;int idx1=0;for(auto&r:a1)for(int x:r){if(x){if(s)o<<",";s=1;o<<"["<<idx1<<","<<x<<"]";}idx1++;}o<<"],\"m3\":[";s=0;
 for(auto&[t,fs]:f3){if(s)o<<",";s=1;vector<vector<int>>a3(fs.size(),vector<int>(fs.size()));v={0,1,2,3,4};do{vector<int>root={v[0],v[1],v[2]};if(from(root,h)!=t)continue;M aa=0,bb=0;for(int i=0;i<3;i++){aa|=(arc(h,v[i],v[3])+2*arc(h,v[3],v[i]))<<(2*i);bb|=(arc(h,v[i],v[4])+2*arc(h,v[4],v[i]))<<(2*i);}int ai=lower_bound(fs.begin(),fs.end(),aa)-fs.begin(),bi=lower_bound(fs.begin(),fs.end(),bb)-fs.begin();a3[ai][bi]++;}while(next_permutation(v.begin(),v.end()));o<<"[";bool ss=0;int idx3=0;for(auto&r:a3)for(int x:r){if(x){if(ss)o<<",";ss=1;o<<"["<<idx3<<","<<x<<"]";}idx3++;}o<<"]";}
 o<<"]}";
 }o<<"]}\n";cerr<<"types "<<types.size()<<" labeled "<<labeled<<" f1 "<<f1.size()<<" f3 ";for(auto&[t,fs]:f3)cerr<<t<<":"<<fs.size()<<" ";cerr<<"\n";
}
