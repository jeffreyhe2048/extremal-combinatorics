#include <algorithm>
#include <array>
#include <fstream>
#include <iostream>
#include <map>
#include <vector>
using namespace std;
int I[5][5];
unsigned permute(unsigned h,const array<int,5>&p){unsigned g=0;for(int i=0;i<5;i++)for(int j=0;j<5;j++)if(i!=j){int a=p[i],b=p[j];unsigned bit=(h>>I[a][b])&1;g|=bit<<I[i][j];}return g;}
int main(){int k=0;for(int i=0;i<5;i++)for(int j=i+1;j<5;j++){I[i][j]=k++;I[j][i]=k++;}
 array<int,5>p={0,1,2,3,4};vector<array<int,5>>perms;do{perms.push_back(p);}while(next_permutation(p.begin(),p.end()));
 vector<unsigned>tourn(1024),canonical(1024);map<unsigned,int>ids;
 for(unsigned z=0;z<1024;z++){unsigned h=0;for(int j=0;j<10;j++)h|=(1u<<((2*j)+((z>>j)&1)));tourn[z]=h;bool reg=true;for(int i=0;i<5;i++){int d=0;for(int j=0;j<5;j++)if(i!=j)d+=(h>>I[i][j])&1;reg &= d==2;}
 unsigned best=h;for(auto&p:perms)best=min(best,permute(h,p));canonical[z]=best;ids.emplace(best,0);}
 int ci=0;for(auto&kv:ids)kv.second=ci++;if(ci!=12)return 1;vector<unsigned short>cover(1<<20);
 for(unsigned z=0;z<1024;z++){if(canonical[z]==~0u)continue;unsigned h=tourn[z],available=((1u<<20)-1)^h;unsigned subset=available;do{cover[h|subset]|=(1<<ids[canonical[z]]);if(!subset)break;subset=(subset-1)&available;}while(1);}
 vector<char>seen(1<<20);vector<unsigned>reps;long labeled=0;
 for(unsigned h=0;h<(1u<<20);h++){if(cover[h]==4095)continue;labeled++;if(seen[h])continue;reps.push_back(h);for(auto&p:perms)seen[permute(h,p)]=true;}
 ofstream out("independent_masks.txt");out<<labeled<<"\n";for(auto h:reps)out<<h<<"\n";cerr<<"independent coverage enumeration "<<labeled<<" labeled / "<<reps.size()<<" classes\n";
}
