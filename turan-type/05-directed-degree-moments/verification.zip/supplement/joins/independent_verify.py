"""Independent finite checks; the general theorem is proved in proof.txt."""
from fractions import Fraction
from itertools import permutations, product
from pathlib import Path
import json

F = {(0, 1), (1, 2), (2, 0), (3, 4)}
F |= {(i, j) for i in range(3) for j in (3, 4)}
F |= {(j, i) for i in range(3) for j in (3, 4)}


def graph(q, n):
    return {(i, j) for i in range(n) for j in range(n)
            if i != j and ((i // 2) % q != (j // 2) % q
                           or i // (2 * q) <= j // (2 * q))}


prefix_checks = 0
for q in range(1, 8):
    for n in range(1, 51):
        arcs = graph(q, n)
        degrees = [sum((i, j) in arcs for j in range(n)) for i in range(n)]
        assert degrees == [n - 1 - 2 * (i // (2 * q)) for i in range(n)]
        for k in range(1, n + 1):
            parts = [k // (2 * q) + (t < k % (2 * q)) for t in range(2 * q)]
            turan = k * k - sum(s * s for s in parts)
            assert sum(i < k and j < k for i, j in arcs) == turan
            assert sum(degrees[:k]) == turan + k * (n - k)
        prefix_checks += 1

embedding_checks = 0
for n in range(5, 11):
    arcs = graph(2, n)
    for p in permutations(range(n), 5):
        assert not all((p[u], p[v]) in arcs for u, v in F)
        embedding_checks += 1

for bits in product((0, 1), repeat=2):
    arcs = {(i, j) for i in range(5) for j in range(5) if i != j}
    for (u, v), bit in zip(((0, 1), (2, 3)), bits):
        arcs.remove((u, v) if bit else (v, u))
    assert any(all((p[u], p[v]) in arcs for u, v in F)
               for p in permutations(range(5)))

family_checks = 0
for q in range(1, 13):
    for s in range(2, 21, 2):
        n = q * s
        Q = sum((n - 1 - 2 * (i // (2 * q))) ** 2 for i in range(n))
        assert Q == (1 - Fraction(1, q) + Fraction(1, 3 * q * q)) * n**3 - Fraction(n, 3)
        assert Q - Fraction((2 * q - 1)**2, 4 * q * q) * n**3 == Fraction(n * (s * s - 4), 12)
        family_checks += 1

arcs = graph(2, 8)
degrees = [sum((i, j) in arcs for j in range(8)) for i in range(8)]
assert len(arcs) == 48 and sum(d * d for d in degrees) == 296
for n in range(1, 8):
    Q = sum((n - 1 - 2 * (i // 4))**2 for i in range(n))
    assert Q <= Fraction(9 * n**3, 16)

result = dict(PASS=True, n=8, arc_count=48, degrees=degrees,
              degree_square_sum=296, candidate_bound=288,
              all_n_prefix_construction_checks=prefix_checks,
              F5_injective_maps_checked=embedding_checks,
              full_matching_orientations_checked=4,
              even_size_formula_checks=family_checks)
Path(__file__).with_name('independent_verification.json').write_text(
    json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
