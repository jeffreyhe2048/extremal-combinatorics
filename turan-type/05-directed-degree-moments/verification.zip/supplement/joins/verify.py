#!/usr/bin/env python3
"""Exact checks for the odd-order forbidden family; Python standard library only.

The universal argument is in proof.txt.  These tests independently construct
adjacency matrices, inspect all prefixes, and check finite embeddings.
"""
from fractions import Fraction
from itertools import permutations, product
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent


def forbidden(q):
    """C3 bidirectionally joined to q-1 directed edges."""
    r = 2*q + 1
    blocks = [0, 0, 0] + [i for i in range(1, q) for _ in range(2)]
    F = [[int(u != v and blocks[u] != blocks[v]) for v in range(r)]
         for u in range(r)]
    for u, v in [(0, 1), (1, 2), (2, 0)]:
        F[u][v] = 1
    for u in range(3, r, 2):
        F[u][u+1] = 1
    assert sum(map(sum, F)) == 4*q*q + q - 2
    return F


def host(q, n):
    """Round-robin ordered digon chains, in nonincreasing outdegree order."""
    return [[int(u != v and
                 ((u//2) % q != (v//2) % q or u//2 == v//2 or u < v))
             for v in range(n)] for u in range(n)]


def twice_turan(n, m):
    a, b = divmod(n, m)
    return n*n - b*(a+1)**2 - (m-b)*a*a


def exact_degree(q, n):
    return [n-1-2*(j//(2*q)) for j in range(n)]


def embeds(F, A):
    """General injective subgraph backtracking; no construction lemmas used."""
    r, n = len(F), len(A)
    if r > n:
        return False
    order = sorted(range(r),
                   key=lambda u: sum(F[u])+sum(F[v][u] for v in range(r)),
                   reverse=True)
    image = {}

    def dfs(t, unused):
        if t == r:
            return True
        u = order[t]
        for v in unused:
            if all((not F[u][x] or A[v][y]) and
                   (not F[x][u] or A[y][v]) for x, y in image.items()):
                image[u] = v
                if dfs(t+1, unused-{v}):
                    return True
                del image[u]
        return False

    return dfs(0, set(range(n)))


def matchings(vertices):
    if not vertices:
        yield ()
        return
    v, rest = vertices[0], vertices[1:]
    yield from matchings(rest)
    for j, u in enumerate(rest):
        for M in matchings(rest[:j]+rest[j+1:]):
            yield ((v, u),)+M


# Full adjacency-matrix check of the smallest new witness.
D, F = host(2, 8), forbidden(2)
deg = list(map(sum, D))
indeg = [sum(row[j] for row in D) for j in range(8)]
assert deg == [7]*4+[5]*4
assert sum(deg) == 48 and sum(d*d for d in deg) == 296
assert sum(d*d for d in indeg) == 296
arcs = [(u, v) for u in range(5) for v in range(5) if F[u][v]]
num_injections = num_embeddings = 0
for p in permutations(range(8), 5):
    num_injections += 1
    num_embeddings += all(D[p[u]][p[v]] for u, v in arcs)
assert num_injections == 6720 and num_embeddings == 0
assert not embeds(F, D)

# Exact examination of all prefixes, not merely the full graph or Q formula.
prefix_checks = 0
matrix_checks = 0
for q in range(1, 9):
    for n in range(1, 81):
        A = host(q, n)
        d = list(map(sum, A))
        assert d == exact_degree(q, n)
        current_arcs = current_degrees = 0
        for k in range(1, n+1):
            j = k-1
            current_arcs += sum(A[j][i]+A[i][j] for i in range(j))
            current_degrees += d[j]
            assert current_arcs == twice_turan(k, 2*q)
            assert all(A[u][v] for u in range(k) for v in range(k, n))
            assert current_degrees == current_arcs+k*(n-k)
            prefix_checks += 1
        matrix_checks += 1
        if q == 1:
            assert sum(x*x for x in d) == n*(n*n-1)//3

# Independent embedding checks, including unequal and odd class sizes.
embedding_checks = []
for q, end in [(1, 10), (2, 12), (3, 10)]:
    for n in range(1, end+1):
        assert not embeds(forbidden(q), host(q, n))
        embedding_checks.append([q, n])

# Every labeled oriented anti-matching in the three smallest odd orders.
antimatching_checks = []
for q in range(1, 4):
    Fq = forbidden(q)
    r = len(Fq)
    matching_count = host_count = 0
    for M in matchings(tuple(range(r))):
        matching_count += 1
        for bits in product(range(2), repeat=len(M)):
            A = [[int(u != v) for v in range(r)] for u in range(r)]
            for (u, v), b in zip(M, bits):
                if b:
                    A[u][v] = 0
                else:
                    A[v][u] = 0
            assert embeds(Fq, A)
            host_count += 1
    antimatching_checks.append({'q': q, 'matchings': matching_count,
                                'oriented_hosts': host_count})
assert antimatching_checks[-1] == {'q': 3, 'matchings': 232,
                                  'oriented_hosts': 1303}

# Integer Turan difference in Norin's induction and the generic prefix sequence.
turan_checks = 0
for m in range(1, 26):
    for n in range(1, 151):
        for s in range(1, min(m, n)+1):
            assert twice_turan(n, m)-twice_turan(n-s, m) >= (s-1)*(2*n-s)
            turan_checks += 1
        if m >= 2:
            b = [n-1-2*(j//m) for j in range(n)]
            assert all(x >= 0 for x in b)
            total = 0
            for k in range(1, n+1):
                total += b[k-1]
                assert total == twice_turan(k, m)+k*(n-k)

# All-n formula proves minimality of n=8 for this fixed F_2.
small_n = []
for n in range(1, 9):
    Q = sum(x*x for x in exact_degree(2, n))
    gap = Fraction(Q)-Fraction(9, 16)*n**3
    assert (gap > 0) == (n == 8)
    small_n.append({'n': n, 'Q': Q, 'gap': str(gap)})

family_samples = []
for q in range(1, 21):
    n = 4*q
    A = host(q, n)
    Q = sum(d*d for d in map(sum, A))
    assert Q == 64*q**3-64*q*q+20*q
    assert sum(map(sum, A)) == twice_turan(n, 2*q)
    gap = Fraction(Q)-Fraction((2*q-1)**2, 4*q*q)*n**3
    assert gap == n
    family_samples.append({'q': q, 'r': 2*q+1, 'n': n,
                           'arcs': sum(map(sum, A)), 'Q': Q, 'gap': str(gap)})

# Palette cardinality and both auxiliary projections are directly reconstructed.
P = [(a, b, c) for a, b, c in product(range(8), repeat=3)
     if D[b][a] and D[b][c]]
assert len(P) == 296
assert set(P) == {(c, b, a) for a, b, c in P}
left = [[0]*8 for _ in range(8)]
right = [[0]*8 for _ in range(8)]
for a, b, c in P:
    left[a][b] = 1
    right[b][c] = 1
assert right == D and left == [list(col) for col in zip(*D)]
assert not embeds(F, left) and not embeds(F, right)

out = {
    'status': 'PASS',
    'main_theorem': 'All-n convex outdegree moments for C3 direct-sum (q-1)T2',
    'smallest_new_witness': {
        'q': 2, 'forbidden_vertices': 5, 'forbidden_arcs': 16,
        'host_vertices': 8, 'host_arcs': 48, 'host_adjacency': D,
        'forbidden_adjacency': F, 'outdegrees': deg, 'Q': 296,
        'baseline': 288, 'integer_gap_16Q_minus_9n3': 128,
        'normalized_Q': '37/64', 'injections_tested': num_injections,
        'embeddings_found': num_embeddings},
    'matrix_checks': matrix_checks,
    'prefix_checks': prefix_checks,
    'embedding_parameters': embedding_checks,
    'antimatching_checks': antimatching_checks,
    'turan_difference_checks': turan_checks,
    'F2_small_n_extrema': small_n,
    'family_samples': family_samples,
    'palette': {'colors': 8, 'admissible_triples': 296,
                'density': '37/64', 'left_right_F2_free': True},
    'scope': 'Finite checks supplement, and do not replace, the universal proof.'}
(ROOT/'verified.json').write_text(json.dumps(out, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({k: v for k, v in out.items()
                  if k not in ('family_samples', 'embedding_parameters',
                               'smallest_new_witness')},
                 ensure_ascii=False, indent=2))
