#!/usr/bin/env python3
"""Exhaust all prefix-compatible small candidates and test the classification.

No third-party packages.  Every surviving graph is tested directly for a copy
of F_q, then classified using components of the graph of single-arc pairs.
The universal proof is in 全部极图分类.txt.
"""
from collections import Counter
from itertools import combinations
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent


def forbidden(q):
    r = 2*q+1
    blocks = [0, 0, 0]+[i for i in range(1, q) for _ in range(2)]
    F = [[int(u != v and blocks[u] != blocks[v]) for v in range(r)]
         for u in range(r)]
    for u, v in [(0, 1), (1, 2), (2, 0)]+[(i, i+1) for i in range(3, r, 2)]:
        F[u][v] = 1
    return F


def contains_new_copy(A, F, new):
    """Test all embeddings using the new vertex; old induced graph is F-free."""
    r, n = len(F), len(A)
    if n < r:
        return False
    for u0 in range(r):
        order = sorted([u for u in range(r) if u != u0],
                       key=lambda u: F[u0][u]+F[u][u0], reverse=True)
        image = {u0: new}

        def dfs(k, unused):
            if k == r-1:
                return True
            u = order[k]
            for v in unused:
                if all((not F[u][x] or A[v][y]) and
                       (not F[x][u] or A[y][v]) for x, y in image.items()):
                    image[u] = v
                    if dfs(k+1, unused-{v}):
                        return True
                    del image[u]
            return False

        if dfs(0, set(range(n))-{new}):
            return True
    return False


def classify(A, q):
    """Recover chains from single-arc components, independently of the A(v) proof."""
    n = len(A)
    a, b = divmod(n, 2*q)
    unused = set(range(n))
    components = []
    while unused:
        component = {min(unused)}
        frontier = list(component)
        unused -= component
        while frontier:
            u = frontier.pop()
            neighbors = {v for v in unused if A[u][v]+A[v][u] == 1}
            component |= neighbors
            unused -= neighbors
            frontier.extend(neighbors)
        components.append(sorted(component))
    singles = sum(len(C) == 1 for C in components)
    chain_sizes = []
    for C in components:
        if len(C) == 1:
            continue
        s = len(C)
        assert s >= 3
        for i, u in enumerate(C):
            for j, v in enumerate(C):
                expected = int(i != j and (i < j or i//2 == j//2))
                assert A[u][v] == expected
        chain_sizes.append(s)
    if a == 0:
        assert singles == n and not chain_sizes
        return ('complete', n)
    assert singles % 2 == 0
    chain_sizes.extend([2]*(singles//2))
    assert len(chain_sizes) == q
    assert all(s in (2*a, 2*a+1, 2*a+2) for s in chain_sizes)
    assert sum(s-2*a for s in chain_sizes) == b
    return tuple(sorted(chain_sizes))


expected_counts = {
    1: [1]*10,
    2: [1, 1, 1, 1, 6, 12, 18, 18, 36, 72, 108, 108],
    3: [1, 1, 1, 1, 1, 1, 15, 105, 360, 810, 1350, 1350],
}
report = []
for q in (1, 2, 3):
    F = forbidden(q)
    states = [[]]
    for n in range(1, len(expected_counts[q])+1):
        j = n-1
        next_states = []
        tested = 0
        signatures = Counter()
        for A in states:
            # Any sorted extremal sequence has all forward arcs and exactly
            # 2 floor(j/(2q)) absent backward arcs at its new vertex.  We do
            # not impose the stronger same-layer digon condition here.
            for missing in combinations(range(j), 2*(j//(2*q))):
                B = [row+[1] for row in A]
                B.append([int(u not in missing) for u in range(j)]+[0])
                tested += 1
                if contains_new_copy(B, F, j):
                    continue
                assert list(map(sum, B)) == [n-1-2*(i//(2*q)) for i in range(n)]
                signature = classify(B, q)
                signatures[str(signature)] += 1
                next_states.append(B)
        states = next_states
        assert len(states) == expected_counts[q][n-1]
        if q == 2 and n == 6:
            assert signatures == {'(2, 4)': 6, '(3, 3)': 6}
        report.append({'q': q, 'n': n, 'candidates': tested,
                       'F_free_extremal_ordered_graphs': len(states),
                       'class_size_signatures': dict(sorted(signatures.items()))})
        print(f'q={q}, n={n}: {len(states)} graphs, {len(signatures)} structure(s)', flush=True)

out = {
    'status': 'PASS',
    'scope': 'Exhaustive inside the proved forward-arc/degree-sequence necessity; not all arbitrary digraphs.',
    'cases': report,
}
(ROOT/'extremal_classification_verified.json').write_text(
    json.dumps(out, ensure_ascii=False, indent=2)+'\n')
print('PASS: every allowed candidate has exactly the claimed chain-join structure.')
