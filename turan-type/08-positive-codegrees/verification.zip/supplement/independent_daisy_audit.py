"""Independent audit using complementary pair graphs and symmetrized root tables.
Reads only the integer certificate. No SDP or original coefficient arrays used.
"""
from pathlib import Path
from itertools import combinations,permutations
from fractions import Fraction as F
from math import factorial
import hashlib,json
D=Path(__file__).resolve().parent
cp=D/'daisy_6_11_certificate.json'; c=json.loads(cp.read_text())
assert c['delta']==[6,11]
num,den=c['delta'];s=c['gram_scale'];ls=c['lambda_scale']
assert isinstance(s,int) and s>0 and isinstance(ls,int) and ls>0 and s*s%ls==0
assert c['flags']==[i for i in range(32) if i&3]
assert len(c['lambda'])==24 and all(isinstance(x,int) and x>=0 for x in c['lambda'])
lam=[0]*32
for f,x in zip(c['flags'],c['lambda']):lam[f]=x
Q=[]
for name,size in [('R0',15),('R1',16)]:
 R=c[name];assert len(R)==size and all(len(row)==size and all(isinstance(x,int) for x in row) for row in R)
 Q.append([[sum(a*b for a,b in zip(x,y)) for y in R] for x in R])
M=F(max(Q[t][i][i] for t in (0,1) for i in range(len(Q[t]))),s*s)
# Sum all four-root orderings once. External x,y can be swapped because Q is symmetric.
perm4=list(permutations(range(4)))
def pm(f,p):return sum(((f>>p[j])&1)<<j for j in range(4))
SQ=[[[0]*16 for j in range(16)] for t in (0,1)]
for t in (0,1):
 for x in range(16):
  for y in range(16):
   if t==0 and (x==0 or y==0):continue
   SQ[t][x][y]=2*sum(Q[t][pm(x,p)-(1-t)][pm(y,p)-(1-t)] for p in perm4)
# Sum all three-root orderings and x,y swaps as a separate 32-entry table.
pat=[frozenset(t) for t in [(0,1,2,3),(0,1,2,4),(0,1,3,4),(0,2,3,4),(1,2,3,4)]]
pi={t:i for i,t in enumerate(pat)}
SL=[0]*32
for p in permutations(range(3)):
 for xy in [(3,4),(4,3)]:
  image=p+xy
  mapping=[pi[frozenset(image[v] for v in t)] for t in pat]
  for f in range(32):
   ff=sum(((f>>mapping[j])&1)<<j for j in range(5))
   SL[f]+=lam[ff]
assert all(SL[f]==0 for f in range(32) if not f&3)
# 4-edges on six points are encoded by the omitted pair.
V=frozenset(range(6));pairs=list(combinations(range(6),2));pairidx={frozenset(p):i for i,p in enumerate(pairs)}
quads=list(combinations(range(6),4));quadidx={frozenset(q):i for i,q in enumerate(quads)}
h_from_g=[quadidx[V-frozenset(p)] for p in pairs]
K4_masks=[sum(1<<pairidx[frozenset(p)] for p in combinations(q,2)) for q in quads]
perm6=list(permutations(range(6)))
actions=[[pairidx[frozenset(p[v] for v in e)] for e in pairs] for p in perm6]
def move(g,p):return sum(1<<p[i] for i in range(15) if g>>i&1)
def hmask(g):return sum(1<<h_from_g[i] for i in range(15) if g>>i&1)
def edge(g,q):return (g>>pairidx[V-frozenset(q)])&1

def score(g):
 ans=0
 for root in quads:
  x,y=sorted(V-frozenset(root));t=edge(g,root)
  fx=sum(edge(g,[v for v in root if v!=r]+[x])<<j for j,r in enumerate(root))
  fy=sum(edge(g,[v for v in root if v!=r]+[y])<<j for j,r in enumerate(root))
  ans+=den*SQ[t][fx][fy]
 for root in combinations(range(6),3):
  a,b,d=root
  rest=sorted(V-frozenset(root))
  for z in rest:
   x,y=[v for v in rest if v!=z]
   f=sum(edge(g,e)<<j for j,e in enumerate([(a,b,d,x),(a,b,d,y),(a,b,x,y),(a,d,x,y),(b,d,x,y)]))
   ans+=(s*s//ls)*SL[f]*(den*edge(g,root+(z,))-num)
 return ans

seen=set();rows=[];legal=0;maxratio=None
for g in range(1<<15):
 if g in seen:continue
 orb={move(g,p) for p in actions};seen.update(orb)
 if any(g&k==k for k in K4_masks):continue
 legal+=len(orb)
 val=score(g);h=min(hmask(z) for z in orb);ec=g.bit_count()
 if ec:
  assert val*15<=-720*den*s*s*ec
  ratio=F(val*15,720*den*s*s*ec)
  maxratio=ratio if maxratio is None else max(maxratio,ratio)
 else:assert val==0
 rows.append({'canonical_complement_graph':g,'canonical_hypergraph':h,'orbit_size':len(orb),'edges':ec,'integer_score':val})
assert len(seen)==32768 and len(rows)==120 and legal==27626
# A comparison is extra: the proof of negativity above does not rely on the old verifier.
ref=D/'daisy_6_11_verification.json';comparison='not requested'
if ref.exists():
 old={r['mask']:r for r in json.loads(ref.read_text())['coefficients']}
 assert len(old)==len(rows)
 for r in rows:
  z=old[r['canonical_hypergraph']]
  assert z['integer_score']==r['integer_score'] and z['orbit_size']==r['orbit_size']
 comparison='all 120 exact scores agree'
threshold=5+M/F(6,11)**4
out={'status':'PASS','certificate_sha256':hashlib.sha256(cp.read_bytes()).hexdigest(),
 'encoding':'4-edges represented by complementary graph pairs; D4 exactly K4 on petals',
 'all_graph_masks':len(seen),'D4_free_labelled_masks':legal,'isomorphism_classes':len(rows),
 'root_coefficient_method':'15 unordered four-roots and 60 unordered three-root/outer-pair configurations, then independent root symmetrization',
 'PSD':'exact integer Gram factors','max_gram_diagonal':str(M),
 'largest_coefficient_over_edge_density':str(maxratio),'old_verifier_comparison':comparison,
 'finite_threshold_strict_expression':str(threshold),'valid_for_all_n_at_least':threshold.numerator//threshold.denominator+1,
 'coefficients':rows}
(D/'independent_daisy_audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='coefficients'},indent=2))
