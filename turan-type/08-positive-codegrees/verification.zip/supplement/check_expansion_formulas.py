#!/usr/bin/env python3
"""Finite checks supplementary to, not replacing, proof.txt."""
from fractions import Fraction as Q
from itertools import combinations
import json

def f(m,n):
    q,r=divmod(n,m)
    return n-2*q-min(2,r)

checks=0
for m in range(3,101):
    a=Q(m-1,m-2); c=Q(m-2,m); h=Q(3*m-4,3*m-1)
    boundary=2*a*m*(3*m-1)
    N=boundary.numerator//boundary.denominator+1
    M=m+m*(m+1)//2-2
    for n in range(N,N+2*m+1):
        assert f(m,n)>=c*n-2
        assert c*n-2>M
        assert a*(c*n-2)>h*n
        assert a*(c*n-2)>c*n
        checks+=1
    for n in range(0,5*m):
        assert f(m,n+1)>=f(m,n)

def partitions(n,k,cap=None):
    if k==0:
        if n==0: yield ()
        return
    cap=min(n, n if cap is None else cap)
    for v in range(cap,-1,-1):
        if n-v>(k-1)*v: continue
        for rest in partitions(n-v,k-1,v):
            yield (v,)+rest

partition_checks=0
for m in range(3,9):
    for n in range(0,41):
        for b in partitions(n,m):
            assert n-b[0]-b[1]<=f(m,n)
            if n % m==0 and b[0]+b[1]==2*n//m:
                assert all(v==n//m for v in b)
            partition_checks+=1

graph_checks=0
for n in range(3,7):
    pairs=list(combinations(range(n),2))
    lookup={p:i for i,p in enumerate(pairs)}
    cliques={k:[sum(1<<lookup[e] for e in combinations(S,2))
                 for S in combinations(range(n),k)] for k in range(3,n+1)}
    for mask in range(1<<len(pairs)):
        e=mask.bit_count()
        if not e: continue
        triangles=sum((mask&s)==s for s in cliques[3])
        omega=2
        for k in range(3,n+1):
            if any((mask&s)==s for s in cliques[k]): omega=k
        assert 3*triangles*omega <= (omega-2)*n*e
        # Squared Fisher--Ryan bound, with no floating point.
        if omega>=3:
            assert 9*triangles**2*omega*(omega-1) <= 2*(omega-2)**2*e**3
        graph_checks+=1

sample=[]
for m in range(3,11):
    n=2*m
    E=[T for T in combinations(range(n),3) if len({v//2 for v in T})==3]
    degrees={p:0 for p in combinations(range(n),2)}
    for T in E:
        for p in combinations(T,2): degrees[p]+=1
    delta=min(d for d in degrees.values() if d)
    assert delta==f(m,n)
    sample.append({'m':m,'n':n,'edges':len(E),'delta_positive':delta,
                   'density':str(Q(delta,n))})

print(json.dumps({'status':'PASS','threshold_checks':checks,
                  'partition_checks':partition_checks,'labelled_graph_checks':graph_checks,
                  'balanced_finite_examples':sample},ensure_ascii=False,indent=2))
