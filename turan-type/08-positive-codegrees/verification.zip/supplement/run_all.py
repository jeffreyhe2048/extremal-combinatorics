#!/usr/bin/env python3
"""Run the self-contained exact certificate checks with the current Python."""
from pathlib import Path
import json
import subprocess
import sys

HERE = Path(__file__).resolve().parent
programs = (
    "verify_daisy_certificate.py",
    "independent_daisy_audit.py",
    "check_expansion_formulas.py",
)
summary = []
for program in programs:
    result = subprocess.run(
        [sys.executable, str(HERE / program)],
        cwd=HERE, text=True, capture_output=True, check=True,
    )
    data = json.loads(result.stdout)
    assert data["status"] == "PASS", (program, data)
    if program == "check_expansion_formulas.py":
        (HERE / "expansion_checks.json").write_text(result.stdout, encoding="utf-8")
    summary.append({"program": program, "status": data["status"]})
    print(program + ": PASS", flush=True)
(HERE / "verification_summary.json").write_text(
    json.dumps({"status": "PASS", "checks": summary}, indent=2) + "\n",
    encoding="utf-8",
)
print("All exact checks passed.")
