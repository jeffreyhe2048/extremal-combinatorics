Exact computational supplement
Positive Codegree Bounds for Daisies and Graph Expansions

Requirements: Python 3.10 or later, standard library only. No internet,
external research folder, optimization package, or stored coefficient table
is required. From any directory run

  python3 /path/to/supplement/run_all.py

The script stops with a nonzero exit status if a check fails. It runs:

1. verify_daisy_certificate.py
   Reads daisy_6_11_certificate.json and checks the local certificate lemma.
   All 32768 labelled four-graph masks on six vertices are covered by
   permutation orbits. A direct daisy containment test leaves 27626 legal
   masks in 120 orbits. Each coefficient is regenerated over all 720 orders,
   using exact integers and Fraction. The stronger bound by minus the edge
   density is checked, not merely negativity. The finite threshold is 3814.
   Output: daisy_6_11_verification.json.

2. independent_daisy_audit.py
   Uses the complementary-pair graph encoding and tests K4 containment.
   It computes the coefficients from unordered roots, separately symmetrizing
   the root orders. This independently proves every coefficient inequality.
   It then compares all 120 exact scores and orbit sizes with the first
   implementation. Output: independent_daisy_audit.json.

3. check_expansion_formulas.py
   Exact finite consistency checks for the analytic expansion proofs:
   threshold inequalities for 3 <= m <= 100; integer partition comparisons;
   clique-count inequalities for every labelled graph of order at most six;
   and finite balanced multipartite examples. These checks do not prove
   the universal expansion assertions: their proofs are in main.tex.
   Output: expansion_checks.json, written by run_all.py.

The wrapper also writes verification_summary.json. Outputs are regenerated
and are not trusted as inputs to the mathematical coefficient calculations.

Certificate format and normalization

The JSON fields R0 and R1 are integer matrices of dimensions 15 and 16.
gram_scale = lambda_scale = 1000000. Thus Q_t = R_t R_t^T / 10^12 and
lambda_f = lambda[f] / 10^6. The flags field lists the 24 integers f in
{0,...,31} whose lowest two bits are not both zero, in increasing order.
The arrays lambda and flags have corresponding entries. The delta field
is [6,11]. The file's historical status string records its discovery stage;
the exact verification, not that string, establishes the certificate.

Four-edges are indexed in lexicographic order on {0,1,...,5}. R0 rows use
the four-bit extension values 1,...,15, with extension zero represented
by the zero vector. R1 rows use values 0,...,15. The five-bit flags are
abcx, abcy, abxy, acxy, bcxy, from least to most significant bit.

The local coefficient has denominator 720 * 11 * 10^12. Its maximum ratio
to positive edge density is -2000931390921/2000000000000, strictly below -1.
The maximum Gram diagonal is 16856850131813/50000000000. These facts are
recomputed, as are the exact comparison 5+M/(6/11)^4 < 3814 and the legal
mask counts. Neither verifier invokes floating-point arithmetic.

Certificate SHA-256:
9ee628bede8d4d5c9f8426cdafb464c71ab0285ae83d5a541737ee0fa8bd93f9

The finite-to-global proof is in Section 2 of the manuscript. Its steps
are not delegated to code: support certification; conditioning on five
vertices; the PSD sampling error; the edge-density lower bound; and taking
links in higher uniformities. Do not interpret verification of finite masks
as a substitute for these arguments.
