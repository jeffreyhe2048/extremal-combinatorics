"""Standard-library exact verification, regenerating all local coefficients.

This file does not read numerical SDP data or rely on an SDP solver.
"""
from pathlib import Path
from itertools import combinations, permutations
from fractions import Fraction
import hashlib
import json

HERE=Path(__file__).resolve().parent
path=HERE/'daisy_6_11_certificate.json'
c=json.loads(path.read_text())
assert c['delta']==[6,11]
num,den=c['delta']; rs=c['gram_scale']; ls=c['lambda_scale']
assert rs==ls==10**6
assert all(isinstance(x,int) for key in ('R0','R1') for row in c[key] for x in row)
assert all(isinstance(x,int) and x>=0 for x in c['lambda'])
assert all(f&3 for f in c['flags'])
assert len(set(c['flags']))==len(c['flags'])==24
weights=dict(zip(c['flags'],c['lambda']))
def gram(R):
    return [[sum(a*b for a,b in zip(row,col)) for col in R] for row in R]
Q0=gram(c['R0']); Q1=gram(c['R1'])
assert len(Q0)==15 and len(Q1)==16
assert all(len(row)==15 for row in c['R0'])
assert all(len(row)==16 for row in c['R1'])
assert rs*rs%ls==0
edges=list(combinations(range(6),4))
index={frozenset(e):j for j,e in enumerate(edges)}
perms=list(permutations(range(6)))
actions=[[index[frozenset(p[x] for x in e)] for e in edges] for p in perms]
daisies=[]
for stem in combinations(range(6),2):
    petals=sorted(set(range(6))-set(stem))
    daisies.append(sum(1<<index[frozenset(stem+pair)] for pair in combinations(petals,2)))
def present(mask, e):
    return (mask>>index[frozenset(e)])&1
seen=set(); table=[]; legal_labelled=0; max_ratio=None
for mask in range(1<<15):
    if mask in seen:
        continue
    orbit={sum(1<<action[i] for i in range(15) if mask>>i&1) for action in actions}
    seen.update(orbit)
    if any(mask&d==d for d in daisies):
        continue
    legal_labelled+=len(orbit)
    score=0
    for p in perms:
        a,b,d,e,x,y=p
        root=(a,b,d,e)
        rootedge=present(mask,root)
        fx=sum(present(mask,root[:j]+root[j+1:]+(x,))<<j for j in range(4))
        fy=sum(present(mask,root[:j]+root[j+1:]+(y,))<<j for j in range(4))
        if rootedge:
            score+=den*Q1[fx][fy]
        elif fx and fy:
            score+=den*Q0[fx-1][fy-1]
        a,b,d,x,y,z=p
        f=sum(present(mask,t)<<j for j,t in enumerate(
            [(a,b,d,x),(a,b,d,y),(a,b,x,y),(a,d,x,y),(b,d,x,y)]))
        if f&3:
            score+=(rs*rs//ls)*weights[f]*(den*present(mask,(a,b,d,z))-num)
    if mask==0:
        assert score==0
    else:
        assert score<0,(mask,score)
        # score/(720*den*rs^2) is the coefficient; divide by edge density.
        ratio=Fraction(score*15,720*den*rs*rs*mask.bit_count())
        assert ratio<=-1,(mask,ratio)
        max_ratio=ratio if max_ratio is None else max(max_ratio,ratio)
    table.append({'mask':mask,'orbit_size':len(orbit),'edges':mask.bit_count(),'integer_score':score})
assert len(seen)==1<<15
assert len(table)==120
assert legal_labelled==27626
M=Fraction(max(Q0[i][i] for i in range(15)),rs*rs)
M=max(M,Fraction(max(Q1[i][i] for i in range(16)),rs*rs))
finite_threshold=5+M/Fraction(num,den)**4
finite_N=finite_threshold.numerator//finite_threshold.denominator+1
assert finite_N==3814
result={
 'status':'PASS','bound':'6/11','local_isomorphism_classes':len(table),
 'all_labelled_masks_covered':len(seen),'D4_free_labelled_masks':legal_labelled,
 'PSD_verification':'Both matrices are exact integer Gram matrices divided by gram_scale squared.',
 'nonnegative_positive_codegree_multipliers':len(weights),
 'max_coefficient_divided_by_edge_density':str(max_ratio),
 'max_Gram_diagonal_M':str(M),
 'finite_N_excluding_delta_at_least_6n_over_11':finite_N,
 'certificate_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
 'coefficients':table
}
(HERE/'daisy_6_11_verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='coefficients'},indent=2))
