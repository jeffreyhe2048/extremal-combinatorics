"""Run every verification from any working directory; no third-party Python packages."""
from pathlib import Path
import subprocess
import sys
BASE = Path(__file__).resolve().parent
if not __debug__:
    raise SystemExit('Do not run verification with Python -O: assertions must be enabled.')
for relative in ['verify_even7_exact.py', 'verify_matrix_support.py', 'independent_audit/run_audit.py']:
    print('\nRunning', relative, flush=True)
    subprocess.run([sys.executable, str(BASE / relative)], check=True)
print('\nAll exact certificate, support, and independent reconstruction checks PASS.')
