"""Independently enumerate the seven-point support of the matrix construction.
Python 3 standard library only. No flag counts or optimization are used.
The only certificate input is the list of zero-slack representatives, whose
orbits are rebuilt from their four-edges; all matrix constructions are then
formed directly from the edge rule in the manuscript.
"""
from pathlib import Path
from itertools import combinations, permutations
from collections import Counter
from fractions import Fraction
from math import comb
import json, gzip

BASE = Path(__file__).resolve().parent
certificate = json.loads((BASE / 'even7_exact_certificate.json').read_text())
with gzip.open(BASE / 'even7_flag_counts.json.gz', 'rt') as stream:
    data = json.load(stream)
vertices = tuple(range(7))
fours = list(combinations(vertices, 4))
index = {sum(1 << v for v in edge): i for i, edge in enumerate(fours)}
triples = list(combinations(range(6), 3)) + [(i, j, 6) for i, j in combinations(range(6), 2)]
zeros = [i for i, slack in enumerate(certificate['slacks']) if Fraction(slack) == 0]
assert len(zeros) == 10
owner = {}
for host_index in zeros:
    host = data['hosts'][host_index]
    complementary_mask = host['complement_triples_mask']
    edges = [tuple(v for v in vertices if v not in triple)
             for i, triple in enumerate(triples) if complementary_mask >> i & 1]
    orbit = set()
    for perm in permutations(vertices):
        bits = sum(1 << index[sum(1 << perm[v] for v in edge)] for edge in edges)
        assert bits not in owner or owner[bits] == host_index
        owner[bits] = host_index
        orbit.add(bits)
    assert len(orbit) == host['orbit_size']
counts = Counter()
raw_matrices = 0
for a in range(8):
    cross_pairs = [(i, j) for i in range(a) for j in range(a, 7)]
    cross_index = {pair: i for i, pair in enumerate(cross_pairs)}
    constant_edges = []
    rectangles = []
    for i, edge in enumerate(fours):
        left = [v for v in edge if v < a]
        right = [v for v in edge if v >= a]
        if len(left) in (1, 3):
            constant_edges.append(i)
        elif len(left) == 2:
            mask = sum(1 << cross_index[(x, y)] for x in left for y in right)
            rectangles.append((i, mask))
    constant = sum(1 << i for i in constant_edges)
    weight = comb(7, a) * (1 << (12 - len(cross_pairs)))
    for matrix in range(1 << len(cross_pairs)):
        bits = constant
        for i, rectangle in rectangles:
            if (matrix & rectangle).bit_count() % 2:
                bits |= 1 << i
        assert bits in owner, ('matrix construction has an unlisted type', a, matrix)
        counts[owner[bits]] += weight
        raw_matrices += 1
assert set(counts) == set(zeros)
assert sum(counts.values()) == 2**19
assert all(counts[i] == certificate['giraud_counts'][i] for i in range(423))
expected_objective = sum(Fraction(count * data['hosts'][i]['objective_numerator'], 2**19 * 420)
                         for i, count in counts.items())
assert expected_objective == Fraction(31, 64)
report = {
    'status': 'PASS',
    'canonical_part_matrices_examined': raw_matrices,
    'support_types': len(zeros),
    'labelled_support_size': len(owner),
    'common_probability_denominator': 2**19,
    'expected_q': str(expected_objective),
    'support': [{'host_index': i, 'probability': str(Fraction(counts[i], 2**19))}
                for i in zeros],
}
(BASE / 'matrix_support_verification.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
