"""Exact arithmetic verification; Python standard library, no SDP solver required.
Run beside even7_exact_certificate.json and even7_flag_counts.json.gz.
The latter is separately reconstructed and coverage-audited by
independent_audit/run_audit.py, directly from four-edges.
"""
from pathlib import Path
from fractions import Fraction as F
from math import lcm,ceil
from itertools import combinations
import gzip,json,time
BASE=Path(__file__).resolve().parent
C=json.loads((BASE/'even7_exact_certificate.json').read_text())
with gzip.open(BASE/'even7_flag_counts.json.gz','rt') as f:D=json.load(f)
assert C['bound']=='31/64' and C['normalization']==D['flag_denominator']==5040
assert D['objective_denominator']==420
hosts=D['hosts'];assert len(hosts)==423 and sum(h['orbit_size'] for h in hosts)==2**20
T=list(combinations(range(6),3))+[(i,j,6) for i in range(6) for j in range(i+1,6)]
assert len({h['seed'] for h in hosts})==423
for h in hosts:
 bits=h['complement_triples_mask'];assert h['seed']==bits%(2**20)
 degs=[sum((bits>>j)&1 for j,t in enumerate(T) if set(p)<=set(t)) for p in combinations(range(7),2)]
 assert all(d%2==0 for d in degs)
 assert sum(d*(d-1) for d in degs)==h['objective_numerator']
def positive_definite(B):
 B=[row[:] for row in B];prev=1
 for k in range(len(B)):
  p=B[k][k];assert p>0,('nonpositive Bareiss pivot',k,p)
  for i in range(k+1,len(B)):
   for j in range(i,len(B)):
    v=B[i][j]*p-B[i][k]*B[k][j];assert v%prev==0
    B[i][j]=B[j][i]=v//prev
  prev=p
 return True
full=[];bounds=[]
for b,(K,ss) in enumerate(zip(C['kernels'],C['matrices'])):
 S=[[F(x) for x in row] for row in ss];r=len(S);n=len(K)
 assert all(len(row)==r for row in S+K)
 assert all(S[i][j]==S[j][i] for i in range(r) for j in range(r))
 den=lcm(*(x.denominator for row in S for x in row));SI=[[int(x*den) for x in row] for row in S]
 assert positive_definite(SI)
 KS=[[sum(K[i][a]*SI[a][j] for a in range(r)) for j in range(r)] for i in range(n)]
 Q=[[sum(KS[i][a]*K[j][a] for a in range(r)) for j in range(n)] for i in range(n)]
 full.append((Q,den));bounds.append(max(F(Q[i][i],den) for i in range(n)))
 print('block',b,'PSD exact via positive-definite reduced matrix',r,flush=True)
slacks=[]
for h,host in enumerate(hosts):
 s=F(31,64)-F(host['objective_numerator'],420)
 for (Q,den),entries in zip(full,host['blocks']):
  total=sum(Q[i][j]*count*(1 if i==j else 2) for i,j,count in entries)
  s-=F(total,5040*den)
 assert s==F(C['slacks'][h]) and s>=0,(h,s)
 slacks.append(s)
counts=C['giraud_counts'];assert sum(counts)==C['giraud_denominator']==2**19
assert sum(F(c*h['objective_numerator'],2**19*420) for c,h in zip(counts,hosts))==F(31,64)
zeros=[i for i,s in enumerate(slacks) if s==0];assert zeros==[i for i,c in enumerate(counts) if c]
for b,K in enumerate(C['kernels']):
 n=len(K);r=len(K[0]);G=[[0]*n for _ in range(n)]
 for c,h in zip(counts,hosts):
  if c:
   for i,j,v in h['blocks'][b]:
    G[i][j]+=c*v
    if i!=j:G[j][i]+=c*v
 assert all(sum(G[i][j]*K[j][a] for j in range(n))==0 for i in range(n) for a in range(r))
minpos=min(s for s in slacks if s>0)
assert minpos > F(1,6000)
finite_constant=ceil(1+8*bounds[0]+2*sum(bounds[1:]))
report={'status':'PASS','hosts':423,'labelled_hosts':2**20,'bound':'31/64','positive_blocks':[len(s) for s in C['matrices']],'zero_slack_hosts':zeros,'minimum_positive_slack':str(minpos),'full_matrix_diagonal_bounds':[str(x) for x in bounds],'finite_error_constant':finite_constant,'finite_bound':'sigma_n <= 31/64 + C/(n-5) for n>=7; C=finite_error_constant'}
(BASE/'even7_exact_verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
