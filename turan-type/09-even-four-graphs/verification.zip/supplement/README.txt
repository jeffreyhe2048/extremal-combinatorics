Supplement to "Squared Codegrees of Even Four-Uniform Hypergraphs"

Run from any working directory:
  python3 /absolute/path/to/supplement/verify_all.py
Do not use Python -O. Verification uses assertions.

Requirements: Python 3.10 or later with its standard library; a C++17 compiler
(clang++ or g++ on PATH). No optimization solver or third-party package.
All inputs are included. Transient binary coefficient arrays and the C++
executable are created in a temporary directory and removed automatically.

Files and their mathematical roles
- even7_exact_certificate.json: rational bound, integer K_b matrices, rational
  S_b matrices, exact slacks, principal minors, and matrix-support probabilities.
- even7_flag_counts.json.gz: all 423 host representatives, orbit sizes,
  objective numerators, sparse upper-triangular integer flag count matrices.
  Off-diagonal entries must be counted twice in an inner product.
- even7_orbits.txt: complementary triple masks, seeds and orbit sizes used by
  independent reconstruction. The triple order is specified in the manuscript.
- verify_even7_exact.py: verifies evenness, objective, positive definiteness,
  every exact coefficient identity, slack margin, and finite error constant.
- independent_audit/audit.cpp: reconstructs hosts directly as four-edge sets;
  proves exhaustive coverage of all 2^20 anchored assignments by disjoint
  orbits; rebuilds every flag entry using all 5040 ordered permutations.
- independent_audit/run_audit.py: compiles and runs the reconstruction and
  passes its output to a second rational certificate checker.
- independent_audit/verify_exact.py: independent exact-arithmetic certificate
  evaluation using rebuilt coefficients.
- verify_matrix_support.py: rebuilds permutation orbits of the ten zero-slack
  representatives, constructs all 10370 binary matrices with a canonical
  part of each size 0,...,7, and verifies the exact ten-type distribution.
- verify_all.py: runs all checks in sequence and stops on the first failure.

Generated reports
- even7_exact_verification.json
- matrix_support_verification.json
- independent_audit/exact_audit.json
- independent_audit/audit.log and exact_audit.log
- verification_run.txt records the successful run shipped with this draft.

The base checker and the independent coefficient audit both prove the
certificate with exact arithmetic. Their use of the same rational matrices is
intentional: independence concerns the host representation, flag coefficient
construction and arithmetic verification, not independently discovered proofs.

Coefficient normalization
Flag matrices are unconditioned averages over 7! = 5040 ordered permutations.
The objective on seven vertices is sum_T d(T)(d(T)-1) / 420.
Five-root blocks use only the specified labelled root masks 0, 3, 15, and
permutations of other root types contribute zero. They are not renormalized
by the frequency of their root type.
