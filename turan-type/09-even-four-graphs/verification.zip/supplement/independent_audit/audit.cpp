#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <numeric>
#include <set>
#include <vector>
using namespace std;
int main(int argc,char**argv){
 const string src=argc>1?argv[1]:"../", out=argc>2?argv[2]:"./";
 vector<int> four,three,pairs7,anchorTriples;
 int i4[128];fill(i4,i4+128,-1);
 for(int a=0;a<7;a++)for(int b=a+1;b<7;b++)for(int c=b+1;c<7;c++)for(int d=c+1;d<7;d++){
  int S=(1<<a)|(1<<b)|(1<<c)|(1<<d);i4[S]=four.size();four.push_back(S);
 }
 for(int a=0;a<7;a++)for(int b=a+1;b<7;b++)for(int c=b+1;c<7;c++)three.push_back((1<<a)|(1<<b)|(1<<c));
 for(int a=0;a<6;a++)for(int b=a+1;b<6;b++)for(int c=b+1;c<6;c++)anchorTriples.push_back((1<<a)|(1<<b)|(1<<c));
 vector<int> inputTriples=anchorTriples;
 for(int a=0;a<6;a++)for(int b=a+1;b<6;b++)inputTriples.push_back((1<<a)|(1<<b)|(1<<6));
 vector<array<int,2>> pairs5;for(int a=0;a<5;a++)for(int b=a+1;b<5;b++)pairs5.push_back({a,b});
 array<int,7> p={0,1,2,3,4,5,6};vector<array<int,7>> perms;
 do{perms.push_back(p);}while(next_permutation(p.begin(),p.end()));
 vector<array<int,35>> permEdge(perms.size());
 for(int z=0;z<(int)perms.size();z++)for(int e=0;e<35;e++){
  int S=0;for(int v=0;v<7;v++)if(four[e]>>v&1)S|=1<<perms[z][v];permEdge[z][e]=i4[S];
 }
 auto iseven=[&](uint64_t H){for(int S=0;S<128;S++)if(__builtin_popcount((unsigned)S)==5){int z=0;for(int e=0;e<35;e++)if((four[e]&S)==four[e])z^=(H>>e)&1;if(z)return false;}return true;};
 int m3[32];fill(m3,m3+32,-1);vector<int> c3;
 for(int m=0;m<32;m++)if(__builtin_popcount((unsigned)m)%2==0){int sw=(m&7)|((m&8)<<1)|((m&16)>>1);if(m<=sw)c3.push_back(m);}
 assert(c3.size()==12);for(int m=0;m<32;m++)if(__builtin_popcount((unsigned)m)%2==0){int sw=(m&7)|((m&8)<<1)|((m&16)>>1);m3[m]=find(c3.begin(),c3.end(),min(m,sw))-c3.begin();}
 int m4[2][16];for(auto &a:m4)fill(a,a+16,-1);
 for(int t=0;t<2;t++){int count=0;for(int m=0;m<16;m++)if(__builtin_popcount((unsigned)m)%2==t)m4[t][m]=count++;assert(count==8);}
 int qs[]={0,3,15},m5[3][1024];for(auto&a:m5)fill(a,a+1024,-1);
 for(int t=0;t<3;t++){int count=0;for(int m=0;m<1024;m++){int odd=0;for(int e=0;e<10;e++)if(m>>e&1)odd^=(1<<pairs5[e][0])|(1<<pairs5[e][1]);if(odd==qs[t])m5[t][m]=count++;}assert(count==64);}
 vector<int> owner(1<<20,-1);ifstream hosts(src+"even7_orbits.txt"), expected(out+"expected.bin",ios::binary), expectedObj(out+"expected_objective.bin",ios::binary);
 ofstream independent(out+"independent.bin",ios::binary), independentObj(out+"independent_objective.bin",ios::binary);
 int seed,osize,count=0;uint64_t input;long long sumOrbits=0;long long entries=0;
 while(hosts>>seed>>input>>osize){
  uint64_t H=0;for(int i=0;i<35;i++)if(input>>i&1)H|=1ULL<<i4[127^inputTriples[i]];
  assert(iseven(H));set<int> orbit;
  for(int z=0;z<5040;z++){
   uint64_t im=0;for(int e=0;e<35;e++)if(H>>e&1)im|=1ULL<<permEdge[z][e];
   unsigned s=0;for(int j=0;j<20;j++)if(im>>i4[anchorTriples[j]|64]&1)s|=1<<j;
   assert(owner[s]==-1||owner[s]==count);owner[s]=count;orbit.insert(s);
   // Evenness uniquely determines edges not containing 6 from those containing 6.
   for(int j=0;j<35;j++)if(!(four[j]&64)){
    int parity=0;for(int v=0;v<6;v++)if(four[j]>>v&1)parity^=(im>>i4[(four[j]^(1<<v))|64])&1;
    assert(parity==int(im>>j&1));
   }
  }
  assert((int)orbit.size()==osize);sumOrbits+=orbit.size();
  vector<int32_t> M(12560,0),want(12560);auto E=[&](int S){return int(H>>i4[S]&1);};
  for(auto r:perms){
   int R3=(1<<r[0])|(1<<r[1])|(1<<r[2]);
   auto f3=[&](int a,int b){int val=0;for(int j=0;j<3;j++)val|=E((R3^(1<<r[j]))|(1<<a)|(1<<b))<<j;val|=E(R3|(1<<a))<<3;val|=E(R3|(1<<b))<<4;assert(m3[val]>=0);return m3[val];};
   M[12*f3(r[3],r[4])+f3(r[5],r[6])]++;
   int R4=R3|(1<<r[3]),type=E(R4),a4=0,b4=0;
   for(int j=0;j<4;j++){a4|=E((R4^(1<<r[j]))|(1<<r[4]))<<j;b4|=E((R4^(1<<r[j]))|(1<<r[5]))<<j;}
   assert(m4[type][a4]>=0&&m4[type][b4]>=0);M[144+64*type+8*m4[type][a4]+m4[type][b4]]++;
   int R5=R4|(1<<r[4]),q=0,a5=0,b5=0;
   for(int j=0;j<5;j++)q|=E(R5^(1<<r[j]))<<j;
   for(int j=0;j<10;j++){int base=R5^(1<<r[pairs5[j][0]])^(1<<r[pairs5[j][1]]);a5|=E(base|(1<<r[5]))<<j;b5|=E(base|(1<<r[6]))<<j;}
   for(int t=0;t<3;t++)if(q==qs[t]){assert(m5[t][a5]>=0&&m5[t][b5]>=0);M[272+4096*t+64*m5[t][a5]+m5[t][b5]]++;}
  }
  expected.read((char*)want.data(),4*want.size());assert(expected.gcount()==4*(int)want.size());
  for(int j=0;j<12560;j++)if(M[j]!=want[j]){cerr<<"COEFFICIENT FAIL "<<count<<" "<<j<<" "<<M[j]<<" "<<want[j]<<"\n";return 1;}
  independent.write((char*)M.data(),4*M.size());
  entries+=12560;
  int obj=0;for(int S:three){int d=0;for(int v=0;v<7;v++)if(!(S>>v&1))d+=E(S|(1<<v));obj+=d*(d-1);}
  int32_t wantObj;expectedObj.read((char*)&wantObj,4);assert(obj==wantObj);independentObj.write((char*)&obj,4);
  count++;
 }
 assert(count==423&&sumOrbits==(1<<20));assert(all_of(owner.begin(),owner.end(),[](int a){return a>=0;}));
 cout<<"PASS representatives "<<count<<" labeled_coverage "<<sumOrbits<<" flag_entries "<<entries<<" denominator 5040 objective_denominator 420\n";
}
