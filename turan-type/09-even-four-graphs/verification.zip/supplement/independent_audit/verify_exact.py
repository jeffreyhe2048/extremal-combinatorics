from pathlib import Path
from fractions import Fraction as F
from math import lcm
import json,struct,hashlib,time,sys
BASE=Path(__file__).resolve().parent.parent
P=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent
C=BASE/'even7_exact_certificate.json'
c=json.loads(C.read_text());start=time.time()
assert F(c['bound'])==F(31,64) and c['normalization']==5040
full=[];reports=[];dimensions=[]
for bi,(B,R) in enumerate(zip(c['kernels'],c['matrices'])):
    m=len(B);d=len(R);dimensions.append(m)
    assert d>0 and all(len(row)==d and all(type(x)is int for x in row) for row in B)
    A=[[F(x) for x in row] for row in R]
    assert len(A)==d and all(len(row)==d for row in A)
    assert all(A[i][j]==A[j][i] for i in range(d) for j in range(d))
    den=lcm(*(x.denominator for row in A for x in row))
    N=[[int(x*den) for x in row] for row in A]
    a=[r[:] for r in N];previous=1;pivots=[]
    for k in range(d):
        v=a[k][k];assert v>0,(bi,k,v);pivots.append(v)
        for i in range(k+1,d):
            for j in range(k+1,d):
                numerator=v*a[i][j]-a[i][k]*a[k][j]
                quot,rem=divmod(numerator,previous);assert rem==0
                a[i][j]=quot
        previous=v
    assert pivots==list(map(int,c['pd_checks'][bi]['leading_principal_minors']))
    BN=[[sum(B[i][z]*N[z][j] for z in range(d)) for j in range(d)] for i in range(m)]
    Q=[[sum(BN[i][z]*B[j][z] for z in range(d)) for j in range(m)] for i in range(m)]
    assert all(Q[i][j]==Q[j][i] for i in range(m) for j in range(m))
    full.append((den,Q))
    reports.append({'block':bi,'dimension':m,'reduced_dimension':d,'positive_principal_minors':len(pivots),'matrix_denominator':den,'largest_diagonal':str(F(max(Q[i][i] for i in range(m)),den))})
    print('PSD PASS',bi,m,d,flush=True)
assert dimensions==[12,8,8,64,64,64]
D=lcm(*(d for d,Q in full),64)
q=[x*(D//d) for d,Q in full for row in Q for x in row]
assert len(q)==12560
M=struct.iter_unpack('<12560i',(P/'independent.bin').read_bytes())
y=list(struct.iter_unpack('<i',(P/'independent_objective.bin').read_bytes()))
hosts=[list(map(int,l.split())) for l in (BASE/'even7_orbits.txt').read_text().splitlines()]
slacks=[];zeros=[]
for i,row in enumerate(M):
    z=F(31,64)-F(y[i][0],420)-F(sum(a*b for a,b in zip(row,q)),5040*D)
    assert z>=0,(i,z)
    assert z==F(c['slacks'][i])
    slacks.append(z)
    if z==0:zeros.append({'index':i,'input_complement_mask':hosts[i][1],'orbit_size':hosts[i][2]})
assert len(slacks)==423 and len(zeros)==10
minimum=min(z for z in slacks if z>0)
assert minimum==F(443483747641429,2627633925000000000)
assert sum(c['giraud_counts'])==c['giraud_denominator']==524288
assert set(i for i,x in enumerate(c['giraud_counts']) if x)>={z['index'] for z in zeros}
assert all(not w or slacks[i]==0 for i,w in enumerate(c['giraud_counts']))
assert sum(F(w*y[i][0],420*524288) for i,w in enumerate(c['giraud_counts']))==F(31,64)
r={'status':'PASS','certificate_sha256':hashlib.sha256(C.read_bytes()).hexdigest(),'normalization':5040,'host_count':len(slacks),'matrix_checks':reports,'minimum_positive_slack':str(minimum),'zero_hosts':zeros,'seconds':time.time()-start}
(P/'exact_audit.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
