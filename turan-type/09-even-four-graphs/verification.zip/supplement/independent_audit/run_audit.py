"""Rebuild all coefficients and check exact certificate, without NumPy or SDP.
Requires Python3 and a C++17 compiler (clang++ or g++).
Transient 40 MiB integer data and executable are kept in a temporary directory.
"""
from pathlib import Path
import gzip,json,struct,subprocess,tempfile,shutil,sys
P=Path(__file__).resolve().parent;B=P.parent
compiler=shutil.which('clang++') or shutil.which('g++')
if compiler is None:raise SystemExit('A C++17 compiler is required for independent reconstruction.')
with gzip.open(B/'even7_flag_counts.json.gz','rt') as f:data=json.load(f)
with tempfile.TemporaryDirectory(prefix='even7-audit-') as tmp:
 t=Path(tmp)
 with (t/'expected.bin').open('wb') as out,(t/'expected_objective.bin').open('wb') as obj:
  for h in data['hosts']:
   row=[]
   for size,entries in zip(data['sizes'],h['blocks']):
    M=[[0]*size for _ in range(size)]
    for i,j,c in entries:M[i][j]=M[j][i]=c
    row.extend(x for r in M for x in r)
   assert len(row)==12560
   out.write(struct.pack('<12560i',*row));obj.write(struct.pack('<i',h['objective_numerator']))
 subprocess.run([compiler,'-O3','-std=c++17',str(P/'audit.cpp'),'-o',str(t/'audit')],check=True)
 r=subprocess.run([str(t/'audit'),str(B)+'/',str(t)+'/'],check=True,text=True,capture_output=True)
 print(r.stdout,end='');(P/'audit.log').write_text(r.stdout+r.stderr)
 r=subprocess.run([sys.executable,str(P/'verify_exact.py'),str(t)],check=True,text=True,capture_output=True)
 print(r.stdout,end='');(P/'exact_audit.log').write_text(r.stdout+r.stderr)
 shutil.copy2(t/'exact_audit.json',P/'exact_audit.json')
