from itertools import permutations,combinations,product
from pathlib import Path
import json
P=Path(__file__).resolve().parent
pairs=list(combinations(range(5),2));ix={p:i for i,p in enumerate(pairs)};maps=[];dims=[]
for d in range(6):
 aut=[a+b for a in permutations(range(d)) for b in permutations(range(d,5))];reps=[];mp=[-1]*1024
 for g in range(1024):
  if mp[g]>=0:continue
  bad=False
  for r in range(d):
   vs=[v for v in range(5) if v!=r]
   for b in vs[1:]:
    u,v=[v for v in vs[1:] if v!=b]
    if g>>ix[tuple(sorted((vs[0],b)))]&1 and g>>ix[tuple(sorted((u,v)))]&1:bad=True
  if bad:continue
  j=len(reps);reps.append(g)
  for p in aut:
   h=sum(((g>>ix[tuple(sorted((p[a],p[b])))])&1)<<z for z,(a,b) in enumerate(pairs));mp[h]=j
 maps.append(mp);dims.append(len(reps));print(d,len(reps))
(P/'root5_orbits.json').write_text(json.dumps({'dims':dims,'maps':maps},indent=2)+'\n')
with (P/'root5_orbits.inc').open('w') as f:
 f.write('int dims[6]={'+','.join(map(str,dims))+'};\nint orbit[6][1024]={\n')
 for row in maps:f.write('{'+','.join(map(str,row))+'},\n')
 f.write('};\n')
