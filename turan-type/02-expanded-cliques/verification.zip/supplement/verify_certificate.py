#!/usr/bin/env python3
"""Exact integer certificate verification. No numerical packages are imported."""
import hashlib,json,struct,sys,time
from pathlib import Path
from itertools import combinations,permutations
from fractions import Fraction
P=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent
start=time.time();C=json.loads((P/'certificate.json').read_text());den=C['denominator'];D=5040*den;U=Fraction(*C['bound']);assert U==Fraction(9,32) and D%32==0

def positive_definite(A):
    """Symmetric Bareiss elimination: pivots are leading principal minors."""
    n=len(A);a=[row[:] for row in A];last=1;digits=[]
    assert all(len(row)==n and all(type(x) is int for x in row) for row in a)
    assert all(a[i][j]==a[j][i] for i in range(n) for j in range(n))
    for k in range(n):
        pivot=a[k][k];assert pivot>0,(k,pivot);digits.append(len(str(pivot)))
        for i in range(k+1,n):
            for j in range(i,n):
                numerator=pivot*a[i][j]-a[i][k]*a[k][j]
                assert numerator%last==0
                a[i][j]=a[j][i]=numerator//last
        last=pivot
    return {'dimension':n,'positive_leading_principal_minors':n,'determinant_digits':digits[-1]}

Q=[];pd=[]
for dim,block in zip(C['dimensions'],C['blocks']):
    B=block['basis'];A=block['matrix'];pd.append(positive_definite(A));k=len(A)
    assert len(B)==dim and all(len(row)==k and all(type(x) is int for x in row) for row in B)
    BA=[[sum(x*y for x,y in zip(row,col)) for col in zip(*A)] for row in B]
    Q.append([[sum(x*y for x,y in zip(row,col)) for col in B] for row in BA])
assert len(Q)==10
reps=[int(x) for x in (P/'six_reps.txt').read_text().split()];assert len(reps)==55
pairs=list(combinations(range(6),2));perms=list(permutations(range(6)));old=[];wedges=[]
for g in reps:
    adj=[[0]*6 for _ in range(6)]
    for z,(a,b) in enumerate(pairs):adj[a][b]=adj[b][a]=(g>>z)&1
    val=0
    for p in perms:
        a,b=p[:2];i=sum(adj[b][v]<<z for z,v in enumerate(p[2:]));j=sum(adj[a][v]<<z for z,v in enumerate(p[2:]))
        val+=Q[adj[a][b]][i][j]
    old.append(val);wedges.append(sum(sum(row)*(sum(row)-1)//2 for row in adj))
q3=[x for row in Q[2] for x in row];q5=[x for A in Q[3:9] for row in A for x in row];qs=[x for row in Q[9] for x in row]
record=struct.Struct('<Q7B618H144h');assert record.size==1539
b=(P/'seven_flag_rows.bin').read_bytes();assert len(b)%record.size==0
minimum=None;arg=None;zeros=[];nrows=0
for R in record.iter_unpack(b):
    H=R[0];deck=R[1:8];counts=R[8:584];r5=R[584:626];signed=R[626:]
    assert sum(counts)==1260 and len(r5)==42 and len(signed)==144
    assert all(counts[24*i+j]==counts[24*j+i] for i in range(24) for j in range(24))
    assert all(signed[12*i+j]==signed[12*j+i] for i in range(12) for j in range(12))
    value=9*(D//32)-(D//420)*sum(wedges[j] for j in deck)-sum(old[j] for j in deck)-4*sum(a*b for a,b in zip(q3,counts))-120*sum(q5[j] for j in r5)-120*sum(a*b for a,b in zip(qs,signed))
    assert value>=0,(H,str(Fraction(value,D)))
    if value==0:zeros.append(H)
    elif minimum is None or value<minimum:minimum,arg=value,H
    nrows+=1
assert nrows==19894
assert set(zeros)=={0,34359705600,7465221528,26894515608}
K=[max(A[i][i] for i in range(len(A))) for A in Q]
assert max(K[:2])<den and K[2]<4*den and max(K[3:])<den
assert minimum==272609568 and Fraction(minimum,D)==Fraction(135223,250000000)
with (P/'full_matrices.txt').open('w') as file:
    print(den,9,32,file=file)
    for A in Q:
        print(len(A),file=file)
        for row in A:print(*row,file=file)
report={'status':'PASS','bound':'9/32','rows':nrows,'matrix_dimensions':C['dimensions'],'reduced_positive_definite_checks':pd,'common_denominator':D,'zero_hosts':zeros,'minimum_positive_slack':str(Fraction(minimum,D)),'minimum_positive_numerator':minimum,'minimum_positive_host':arg,'max_diagonals':[str(Fraction(x,den)) for x in K],'certificate_sha256':hashlib.sha256((P/'certificate.json').read_bytes()).hexdigest(),'arithmetic':'Integer Bareiss principal minors and integer host inequalities; no SDP or floating point','seconds':time.time()-start}
(P/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
