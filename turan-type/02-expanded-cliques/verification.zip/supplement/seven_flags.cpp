#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <unordered_set>
#include <vector>
using namespace std;
#include "root5_orbits.inc"
#include "signed_orbits.inc"
int main(int argc,char**argv){
 string dir=argc>1?argv[1]:".";
 int qix[128];fill(qix,qix+128,-1);int nq=0;for(int m=0;m<128;m++)if(__builtin_popcount((unsigned)m)==4)qix[m]=nq++;
 struct Sampling{array<array<int,5>,6> f;};vector<Sampling>sample;
 for(int a=0;a<7;a++)for(int b=0;b<7;b++)if(b!=a)for(int c=0;c<7;c++)if(c!=a&&c!=b){
 vector<int>v;for(int i=0;i<7;i++)if(i!=a&&i!=b&&i!=c)v.push_back(i);Sampling s;int z=0,root=(1<<a)|(1<<b)|(1<<c);
 for(int i=0;i<4;i++)for(int j=i+1;j<4;j++){int all=root|(1<<v[i])|(1<<v[j]);s.f[z++]={qix[all^(1<<a)],qix[all^(1<<b)],qix[all^(1<<c)],qix[root|(1<<v[i])],qix[root|(1<<v[j])]};}sample.push_back(s);}
 ifstream in(dir+"/seven_rooted_hosts.tsv");ofstream out(dir+"/seven_flag_rows.bin",ios::binary);
 unordered_set<string>seen;uint64_t H,total=0;array<uint8_t,7>d;
 while(in>>H){for(int i=0,x;i<7;i++){in>>x;d[i]=x;}total++;array<uint16_t,576>counts{};
 for(auto&s:sample){int f[6];for(int z=0;z<6;z++){auto a=s.f[z];f[z]=int((H>>a[0])&1)+2*int((H>>a[1])&1)+4*int((H>>a[2])&1)+8*(int((H>>a[3])&1)+int((H>>a[4])&1));}for(int z=0;z<6;z++)counts[24*f[z]+f[5-z]]++;}
 string key(reinterpret_cast<char*>(d.data()),7);key.append(reinterpret_cast<char*>(counts.data()),1152);
 array<int16_t,144> signedCounts{};array<uint16_t,42> root5{};int zz=0;int offset[6]={0};for(int t=1;t<6;t++)offset[t]=offset[t-1]+dims[t-1]*dims[t-1];
 for(int a=0;a<7;a++)for(int b=a+1;b<7;b++){
  int rm=127^((1<<a)|(1<<b));vector<int>ones,zeros;
  for(int v=0;v<7;v++)if(rm&(1<<v)){if((H>>qix[rm^(1<<v)])&1)ones.push_back(v);else zeros.push_back(v);}
  int t=ones.size();vector<int>root=ones;root.insert(root.end(),zeros.begin(),zeros.end());int ga=0,gb=0,z=0;
  for(int i=0;i<5;i++)for(int j=i+1;j<5;j++){int sm=rm^(1<<root[i])^(1<<root[j]);ga|=int((H>>qix[sm|(1<<a)])&1)<<z;gb|=int((H>>qix[sm|(1<<b)])&1)<<z;z++;}
  if(t==2){int i=signedIndex[ga],j=signedIndex[gb];if(i>=0&&j>=0){int sg=signedSign[ga]*signedSign[gb];signedCounts[12*i+j]+=sg;signedCounts[12*j+i]+=sg;}}
  int fa=orbit[t][ga],fb=orbit[t][gb];if(fa<0||fb<0){cerr<<"BAD root5"<<endl;return 3;}
  root5[zz++]=offset[t]+dims[t]*fa+fb;root5[zz++]=offset[t]+dims[t]*fb+fa;
 }
 sort(root5.begin(),root5.end());key.append(reinterpret_cast<char*>(root5.data()),84);key.append(reinterpret_cast<char*>(signedCounts.data()),288);
 if(!seen.insert(key).second)continue;
 out.write(reinterpret_cast<char*>(&H),8);out.write(key.data(),key.size());
 }
 cerr<<"rooted "<<total<<" distinct_moment_rows "<<seen.size()<<" record_bytes "<<1539<<endl;
}
