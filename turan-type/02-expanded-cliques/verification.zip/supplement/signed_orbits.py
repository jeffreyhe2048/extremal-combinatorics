"""The double-sign isotypic flags; Python standard library only."""
from pathlib import Path
from itertools import combinations, permutations
import json
P=Path(__file__).resolve().parent
ordinary=json.loads((P/'root5_orbits.json').read_text())
pairs=list(combinations(range(5),2)); index={p:i for i,p in enumerate(pairs)}
def sign(p):
    return (-1)**sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))
group=[(a+b,sign(a)*sign(b)) for a in permutations(range(2)) for b in permutations(range(2,5))]
lookup=[[-1,0] for _ in range(1024)];reps=[]
for g in range(1024):
    old=ordinary['maps'][2][g]
    if old<0 or g!=ordinary['maps'][2].index(old):continue
    orbit={};ambiguous=False
    for p,chi in group:
        h=sum(((g>>index[tuple(sorted((p[a],p[b])))])&1)<<z for z,(a,b) in enumerate(pairs))
        if h in orbit and orbit[h]!=chi:ambiguous=True
        orbit[h]=chi
    if ambiguous:continue
    label=len(reps);reps.append(g)
    for h,chi in orbit.items():lookup[h]=[label,chi]
assert len(reps)==12
cert=json.loads((P/'certificate.json').read_text())
assert reps==cert['signed_block']['orbit_representatives']
(P/'signed_orbits.json').write_text(json.dumps({'reps':reps,'map':lookup},indent=2)+'\n')
(P/'signed_orbits.inc').write_text('int signedIndex[1024]={'+','.join(str(x[0]) for x in lookup)+'};\nint signedSign[1024]={'+','.join(str(x[1]) for x in lookup)+'};\n')
print('double-sign flags:',len(reps),'representatives:',reps)
