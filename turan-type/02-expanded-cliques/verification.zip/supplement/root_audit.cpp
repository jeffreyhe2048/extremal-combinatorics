#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <set>
#include <sstream>
#include <unordered_set>
#include <vector>
using namespace std;
using I=__int128_t;
string dec(I x){if(x==0)return "0";string s;bool neg=x<0;if(neg)x=-x;while(x){s+=char('0'+x%10);x/=10;}if(neg)s+='-';reverse(s.begin(),s.end());return s;}
vector<uint64_t> triangles(int n,vector<int> const& qs){
 int qi[128];fill(qi,qi+128,-1);for(int i=0;i<(int)qs.size();i++)qi[qs[i]]=i;
 set<uint64_t> out;
 for(int a=0;a<(1<<n);a++)if(__builtin_popcount((unsigned)a)==2)
 for(int b=0;b<(1<<n);b++)if(__builtin_popcount((unsigned)b)==2 && !(a&b))
 for(int c=0;c<(1<<n);c++)if(__builtin_popcount((unsigned)c)==2 && !((a|b)&c))
 out.insert((1ULL<<qi[a|b])|(1ULL<<qi[a|c])|(1ULL<<qi[b|c]));
 return vector<uint64_t>(out.begin(),out.end());
}
int main(int argc,char**argv){
 string dir=argc>1?argv[1]:"."; string hostdir=argc>2?argv[2]:dir;
 ifstream cf(dir+"/root_q.txt");long long den,un,ud;cf>>den>>un>>ud;vector<vector<I>>Q(10);
 int qdims[10]={16,16,24,34,42,48,31,19,6,12};
 for(int t=0;t<10;t++){int d=qdims[t];Q[t].resize(d*d);for(auto&x:Q[t]){string token;cf>>token;bool neg=token[0]=='-';x=0;for(int j=neg;j<(int)token.size();j++)x=10*x+(token[j]-'0');if(neg)x=-x;}}if(!cf)return 3;
 vector<int>q6,q7;int ix6[64],ix7[128];fill(ix6,ix6+64,-1);fill(ix7,ix7+128,-1);
 for(int m=0;m<128;m++)if(__builtin_popcount((unsigned)m)==4){ix7[m]=q7.size();q7.push_back(m);if(m<64){ix6[m]=q6.size();q6.push_back(m);}}
 auto bad6=triangles(6,q6),bad7=triangles(7,q7);
 set<uint64_t> oddmasks;for(int color=0;color<128;color++){uint64_t h=0;for(int j=0;j<35;j++)if(__builtin_popcount((unsigned)(q7[j]&color))%2)h|=1ULL<<j;oddmasks.insert(h);}if(oddmasks.size()!=64)return 22;
 vector<array<int,6>>p6;array<int,6>p={0,1,2,3,4,5};do{p6.push_back(p);}while(next_permutation(p.begin(),p.end()));
 struct Old{int type,ob1,ob2;array<int,4>a,b;};vector<Old>old;
 for(auto p:p6){int r=0;for(int i=0;i<4;i++)r|=1<<p[i];Old s;s.type=ix6[r];for(int i=0;i<4;i++){s.a[i]=ix6[(r^(1<<p[i]))|(1<<p[4])];s.b[i]=ix6[(r^(1<<p[i]))|(1<<p[5])];}int root=(1<<p[0])|(1<<p[1])|(1<<p[2]);s.ob1=ix6[root|(1<<p[3])];s.ob2=ix6[root|(1<<p[4])];old.push_back(s);}
 vector<I>score6(1<<15);vector<bool>ok6(1<<15);int sixcount=0;I dd=I(den);
 for(unsigned h=0;h<(1<<15);h++){
  bool ok=true;for(auto t:bad6)if((h&t)==t){ok=false;break;}if(!ok)continue;ok6[h]=true;sixcount++;
  I sc=0;for(auto&s:old){int a=0,b=0;for(int i=0;i<4;i++){a|=((h>>s.a[i])&1)<<i;b|=((h>>s.b[i])&1)<<i;}sc+=Q[(h>>s.type)&1][16*a+b];if((h>>s.ob1&1)&&(h>>s.ob2&1))sc+=dd;}score6[h]=sc;
 }
 // Independently derive root-five orbit flags using direct six-point T4 tests.
 vector<array<int,2>>p5pairs;for(int i=0;i<5;i++)for(int j=i+1;j<5;j++)p5pairs.push_back({i,j});
 array<array<int,1024>,6>flag5;int flagsizes[6]={};
 for(int d=0;d<=5;d++){
  vector<array<int,5>>aut5;array<int,5>perm={0,1,2,3,4};do{bool keep=true;for(int i=0;i<5;i++)if((i<d)!=(perm[i]<d))keep=false;if(keep)aut5.push_back(perm);}while(next_permutation(perm.begin(),perm.end()));
  array<int,1024>can;can.fill(-1);set<int>rep;
  for(int g=0;g<1024;g++){
   int hh=0;for(int r=0;r<d;r++)hh|=1<<ix6[31^(1<<r)];
   for(int z=0;z<10;z++)if(g>>z&1)hh|=1<<ix6[(31^(1<<p5pairs[z][0])^(1<<p5pairs[z][1]))|32];
   if(!ok6[hh])continue;int smallest=g;
   for(auto perm:aut5){int gg=0;for(int z=0;z<10;z++)if(g>>z&1){int a=perm[p5pairs[z][0]],b=perm[p5pairs[z][1]];if(a>b)swap(a,b);int j=find(p5pairs.begin(),p5pairs.end(),array<int,2>{a,b})-p5pairs.begin();gg|=1<<j;}smallest=min(smallest,gg);}
   can[g]=smallest;rep.insert(smallest);
  }
  vector<int>reps5(rep.begin(),rep.end());flagsizes[d]=reps5.size();if(flagsizes[d]!=qdims[d+3])return 11;
  for(int g=0;g<1024;g++)flag5[d][g]=can[g]<0?-1:lower_bound(reps5.begin(),reps5.end(),can[g])-reps5.begin();
 }

 // Reconstruct the entire double-sign block without importing any orbit table.
 vector<pair<array<int,5>,int>> signedaut;
 array<int,5> pa={0,1,2,3,4};do{
  if(pa[0]>1 || pa[1]>1)continue;int inv=0;
  for(int i=0;i<5;i++)for(int j=i+1;j<5;j++)inv+=(pa[i]>pa[j]);
  signedaut.push_back({pa,inv%2?-1:1});
 }while(next_permutation(pa.begin(),pa.end()));
 auto act=[&](int g,array<int,5> p){int h=0;
  for(int z=0;z<10;z++)if(g>>z&1){int a=p[p5pairs[z][0]],b=p[p5pairs[z][1]];if(a>b)swap(a,b);int j=find(p5pairs.begin(),p5pairs.end(),array<int,2>{a,b})-p5pairs.begin();h|=1<<j;}
  return h;
 };
 array<int,1024> charidx,charsgn,charcan;charidx.fill(-1);charsgn.fill(0);charcan.fill(-1);
 set<int> charreps;int allowedchar=0,zeroorbits=0;set<int> zerochar;
 for(int g=0;g<1024;g++){
  int hh=(1<<ix6[31^1])|(1<<ix6[31^2]);
  for(int z=0;z<10;z++)if(g>>z&1)hh|=1<<ix6[(31^(1<<p5pairs[z][0])^(1<<p5pairs[z][1]))|32];
  if(!ok6[hh])continue;allowedchar++;int mn=g;bool bad=false;
  for(auto ps:signedaut){int h=act(g,ps.first);mn=min(mn,h);if(h==g && ps.second<0)bad=true;}
  if(bad){zerochar.insert(mn);continue;}
  charcan[g]=mn;charreps.insert(mn);
  for(auto ps:signedaut)if(act(g,ps.first)==mn){charsgn[g]=ps.second;break;}
 }
 vector<int> crep(charreps.begin(),charreps.end());
 if(crep.size()!=12 || signedaut.size()!=12 || allowedchar!=250 || zerochar.size()!=36)return 20;
 for(int g=0;g<1024;g++)if(charcan[g]>=0)charidx[g]=lower_bound(crep.begin(),crep.end(),charcan[g])-crep.begin();
 int equiv=0;
 for(int g=0;g<1024;g++)if(flag5[2][g]>=0)for(auto ps:signedaut){int h=act(g,ps.first);if(charidx[h]!=charidx[g] || charsgn[h]!=ps.second*charsgn[g])return 21;equiv++;}
 cout<<"signed_flag_audit allowed "<<allowedchar<<" nonzero_orbits "<<crep.size()<<" zero_orbits "<<zerochar.size()<<" equivariance "<<equiv<<" representatives";for(auto g:crep)cout<<" "<<g;cout<<endl;
 struct New{array<int,5>a,b;};vector<New>news;
 array<int,7>p7={0,1,2,3,4,5,6};do{
  if(p7[3]>p7[4]||p7[5]>p7[6])continue;
  int r=(1<<p7[0])|(1<<p7[1])|(1<<p7[2]);New s;
  for(int j=0;j<3;j++){s.a[j]=ix7[(r^(1<<p7[j]))|(1<<p7[3])|(1<<p7[4])];s.b[j]=ix7[(r^(1<<p7[j]))|(1<<p7[5])|(1<<p7[6])];}
  s.a[3]=ix7[r|(1<<p7[3])];s.a[4]=ix7[r|(1<<p7[4])];s.b[3]=ix7[r|(1<<p7[5])];s.b[4]=ix7[r|(1<<p7[6])];news.push_back(s);
 }while(next_permutation(p7.begin(),p7.end()));
 array<array<int,15>,7>dele;
 for(int v=0;v<7;v++){vector<int>z;for(int i=0;i<7;i++)if(i!=v)z.push_back(i);for(int j=0;j<15;j++){int m=0;for(int i=0;i<6;i++)if(q6[j]>>i&1)m|=1<<z[i];dele[v][j]=ix7[m];}}
 ifstream in(hostdir+"/seven_rooted_hosts.tsv");string line;I bound=I(un)*(5040*dd/ud),mn=bound,minpos=bound;uint64_t arg=0,argpos=0;int nh=0,zeros=0,charused=0;unordered_set<uint64_t>hosts;
 while(getline(in,line)){
  istringstream st(line);uint64_t h;st>>h;hosts.insert(h);nh++;
  for(auto t:bad7)if((h&t)==t){cerr<<"NONFREE HOST"<<endl;return 4;}
  I sc=0;for(auto&v:dele){unsigned z=0;for(int j=0;j<15;j++)z|=((h>>v[j])&1)<<j;if(!ok6[z])return 5;sc+=score6[z];}
  for(auto&s:news){int a=0,b=0;for(int j=0;j<3;j++){a+=((h>>s.a[j])&1)<<j;b+=((h>>s.b[j])&1)<<j;}a+=8*((h>>s.a[3]&1)+(h>>s.a[4]&1));b+=8*((h>>s.b[3]&1)+(h>>s.b[4]&1));sc+=4*I(Q[2][24*a+b]);}
  for(int a=0;a<7;a++)for(int b=a+1;b<7;b++){
   int rm=127^((1<<a)|(1<<b));vector<int>root,other;
   for(int v=0;v<7;v++)if(rm>>v&1){if(h>>ix7[rm^(1<<v)]&1)root.push_back(v);else other.push_back(v);}
   int d=root.size();root.insert(root.end(),other.begin(),other.end());int ga=0,gb=0;
   for(int j=0;j<10;j++){int sm=rm^(1<<root[p5pairs[j][0]])^(1<<root[p5pairs[j][1]]);ga|=((h>>ix7[sm|(1<<a)])&1)<<j;gb|=((h>>ix7[sm|(1<<b)])&1)<<j;}
   int fa=flag5[d][ga],fb=flag5[d][gb];if(fa<0||fb<0)return 12;
   sc+=120*(I(Q[d+3][flagsizes[d]*fa+fb])+I(Q[d+3][flagsizes[d]*fb+fa]));
   if(d==2){int ca=charidx[ga],cb=charidx[gb];if(ca>=0 && cb>=0){sc+=120*charsgn[ga]*charsgn[gb]*(Q[9][12*ca+cb]+Q[9][12*cb+ca]);charused++;}}

  }
  I gap=bound-sc;if((gap==0)!=(oddmasks.count(h)>0)){cerr<<"ZERO/ODD MISMATCH "<<h<<endl;return 23;}if(gap<0){cerr<<"NEGATIVE GAP "<<h<<" "<<dec(gap)<<endl;return 6;}if(gap<mn){mn=gap;arg=h;}if(gap==0){zeros++;cout<<"ZERO "<<h<<endl;}if(gap>0 && gap<minpos){minpos=gap;argpos=h;}
 }
 cout<<"root5_orbit_dimensions";for(int d:flagsizes)cout<<" "<<d;cout<<endl;
 cout<<"direct_inequality_hosts "<<nh<<" distinct "<<hosts.size()<<" six_labeled "<<sixcount<<" forbidden_patterns "<<bad6.size()<<" "<<bad7.size()<<" min_numerator "<<dec(mn)<<" denominator "<<dec(5040*dd)<<" min_host "<<arg<<endl;
 // Cover every legal extension using forbidden triples constructed directly above.
 vector<int>reps;ifstream rf(hostdir+"/six_reps.txt");int gr;while(rf>>gr)reps.push_back(gr);
 vector<array<int,2>>pairs;for(int i=0;i<6;i++)for(int j=i+1;j<6;j++)pairs.push_back({i,j});
 vector<int>tr;for(int m=0;m<64;m++)if(__builtin_popcount((unsigned)m)==3)tr.push_back(m);
 vector<bool>sixcovered(1<<15);long long extensions=0,orbits=0;
 for(int g:reps){
  unsigned h6=0;uint64_t base=0;for(int i=0;i<15;i++)if(g>>i&1){int m=63^((1<<pairs[i][0])|(1<<pairs[i][1]));h6|=1u<<ix6[m];base|=1ULL<<ix7[m];}
  vector<array<int,20>>aut;
  for(auto p:p6){unsigned trans=0;for(int i=0;i<15;i++)if(h6>>i&1){int m=0;for(int j=0;j<6;j++)if(q6[i]>>j&1)m|=1<<p[j];trans|=1u<<ix6[m];}sixcovered[trans]=true;
   if(trans==h6){array<int,20>a;for(int i=0;i<20;i++){int m=0;for(int j=0;j<6;j++)if(tr[i]>>j&1)m|=1<<p[j];a[i]=find(tr.begin(),tr.end(),m)-tr.begin();}aut.push_back(a);}}
  uint32_t conflict[20]={};
  for(auto t:bad7){uint64_t oldpart=0;uint32_t newpart=0;for(int i=0;i<35;i++)if(t>>i&1){if(q7[i]&64){int j=find(tr.begin(),tr.end(),q7[i]^64)-tr.begin();newpart|=1u<<j;}else oldpart|=1ULL<<i;}
   if((oldpart&base)==oldpart && newpart){if(__builtin_popcount(newpart)!=2)return 7;int a=__builtin_ctz(newpart),b=__builtin_ctz(newpart&(newpart-1));conflict[a]|=1u<<b;conflict[b]|=1u<<a;}}
  vector<unsigned char>legal(1<<20),covered(1<<20);legal[0]=1;
  for(uint32_t m=0;m<(1u<<20);m++){
   if(m){int j=__builtin_ctz(m);uint32_t rest=m&(m-1);legal[m]=legal[rest]&&!(rest&conflict[j]);}if(!legal[m])continue;extensions++;if(covered[m])continue;orbits++;
   bool found=false;for(auto a:aut){uint32_t z=0;for(int j=0;j<20;j++)if(m>>j&1)z|=1u<<a[j];covered[z]=1;uint64_t h=base;for(int j=0;j<20;j++)if(z>>j&1)h|=1ULL<<ix7[tr[j]|64];if(hosts.count(h))found=true;}if(!found){cerr<<"MISSING ORBIT"<<endl;return 8;}
  }
 }
 for(int h=0;h<(1<<15);h++)if(ok6[h]!=sixcovered[h])return 9;
 if(orbits!=nh)return 10;
 if(minpos!=I(272609568) || zeros!=7)return 24;
 cout<<"zero_iff_odd PASS odd_labeled_masks "<<oddmasks.size()<<endl;
 cout<<"additional_stats zero_hosts "<<zeros<<" min_positive_numerator "<<dec(minpos)<<" denominator "<<dec(5040*dd)<<" arg_positive "<<argpos<<" signed_terms "<<charused<<endl;
 cout<<"coverage PASS six_types "<<reps.size()<<" legal_extensions "<<extensions<<" rooted_orbits "<<orbits<<endl;
}
