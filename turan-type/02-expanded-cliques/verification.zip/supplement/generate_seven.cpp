#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <set>
#include <unordered_map>
#include <vector>
using namespace std;
int main(int argc,char**argv){
 string dir=argc>1?argv[1]:".";
 vector<array<int,2>> pairs;vector<int> tri,quad;int ix[6][6];
 for(int a=0;a<6;a++)for(int b=a+1;b<6;b++){ix[a][b]=ix[b][a]=pairs.size();pairs.push_back({a,b});}
 for(int m=0;m<64;m++){if(__builtin_popcount((unsigned)m)==3)tri.push_back(m);if(__builtin_popcount((unsigned)m)==4)quad.push_back(m);}
 vector<array<int,6>> ps;array<int,6>p={0,1,2,3,4,5};do{ps.push_back(p);}while(next_permutation(p.begin(),p.end()));
 vector<int> pm;for(int a=0;a<15;a++)for(int b=a+1;b<15;b++)for(int c=b+1;c<15;c++){int z=0;for(int j:{a,b,c})z|=(1<<pairs[j][0])|(1<<pairs[j][1]);if(z==63)pm.push_back((1<<a)|(1<<b)|(1<<c));}
 vector<int>cls(32768,-1),reps;vector<vector<array<int,20>>>aut;
 for(int g=0;g<32768;g++){if(cls[g]>=0)continue;bool ok=true;for(int f:pm)if((g&f)==f)ok=false;if(!ok)continue;
 int id=reps.size();reps.push_back(g);vector<array<int,20>>aa;
 for(auto &p:ps){int h=0;for(int z=0;z<15;z++)if(g&(1<<ix[p[pairs[z][0]]][p[pairs[z][1]]]))h|=1<<z;cls[h]=id;if(h==g){array<int,20>a;for(int z=0;z<20;z++){int mask=0;for(int i=0;i<6;i++)if(tri[z]&(1<<i))mask|=1<<p[i];a[z]=find(tri.begin(),tri.end(),mask)-tri.begin();}aa.push_back(a);}}
 aut.push_back(aa);}
 cerr<<"reps "<<reps.size()<<endl;
 vector<int>quad7;for(int m=0;m<128;m++)if(__builtin_popcount((unsigned)m)==4)quad7.push_back(m);
 int qix[128];fill(qix,qix+128,-1);for(int i=0;i<35;i++)qix[quad7[i]]=i;
 ofstream out(dir+"/seven_rooted_hosts.tsv");
 uint64_t total=0,orbtotal=0;set<array<int,7>>decks;
 for(int id=0;id<(int)reps.size();id++){
 int g=reps[id];uint64_t base=0;bool edge[64]={};for(int j=0;j<15;j++)if(g&(1<<j)){int m=63^((1<<pairs[j][0])|(1<<pairs[j][1]));edge[m]=true;base|=1ULL<<qix[m];}
 uint32_t adj[20]={};for(int i=0;i<20;i++)for(int j=i+1;j<20;j++)if(__builtin_popcount((unsigned)(tri[i]&tri[j]))==1 && edge[tri[i]^tri[j]]){adj[i]|=1u<<j;adj[j]|=1u<<i;}
 vector<unsigned char>valid(1<<20,0),seen(1<<20,0);valid[0]=1;uint64_t count=0,orbs=0;
 for(int m=0;m<(1<<20);m++){
 if(m){int j=__builtin_ctz((unsigned)m),rest=m&(m-1);valid[m]=valid[rest]&&!(adj[j]&rest);}if(!valid[m])continue;count++;if(seen[m])continue;orbs++;
 for(auto &a:aut[id]){int h=0;for(int z=0;z<20;z++)if(m&(1<<z))h|=1<<a[z];seen[h]=1;}
 uint64_t H=base;for(int z=0;z<20;z++)if(m&(1<<z))H|=1ULL<<qix[tri[z]|64];
 array<int,7>deck;for(int v=0;v<7;v++){vector<int>vs;for(int z=0;z<7;z++)if(z!=v)vs.push_back(z);int h=0;for(int z=0;z<15;z++){int qm=0;for(int a=0;a<6;a++)if(a!=pairs[z][0]&&a!=pairs[z][1])qm|=1<<vs[a];if(H&(1ULL<<qix[qm]))h|=1<<z;}if(cls[h]<0){cerr<<"BAD"<<endl;return 2;}deck[v]=cls[h];}sort(deck.begin(),deck.end());decks.insert(deck);
 out<<H;for(int x:deck)out<<'\t'<<x;out<<'\n';
 }
 total+=count;orbtotal+=orbs;cerr<<id<<" ext "<<count<<" rooted "<<orbs<<" decks "<<decks.size()<<endl;
 }
 cerr<<"TOTAL extensions "<<total<<" rooted "<<orbtotal<<" decks "<<decks.size()<<endl;
 ofstream d(dir+"/seven_decks.tsv");for(auto a:decks){for(int i=0;i<7;i++)d<<a[i]<<(i==6?'\n':'\t');}
 ofstream r(dir+"/six_reps.txt");for(int x:reps)r<<x<<'\n';
}
