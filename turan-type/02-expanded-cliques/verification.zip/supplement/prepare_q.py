import json,argparse
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('certificate');p.add_argument('output');a=p.parse_args()
c=json.loads(Path(a.certificate).read_text());out=Path(a.output);out.mkdir(exist_ok=True,parents=True)
Q=[]
for d,b in zip(c['dimensions'],c['blocks']):
 B=b['basis'];R=b['matrix'];k=len(R)
 assert len(B)==d and all(len(r)==k for r in B+R)
 assert all(isinstance(x,int)for row in B+R for x in row)
 assert all(R[i][j]==R[j][i]for i in range(k)for j in range(k))
 BR=[[sum(B[i][a]*R[a][j]for a in range(k))for j in range(k)]for i in range(d)]
 q=[[sum(BR[i][a]*B[j][a]for a in range(k))for j in range(d)]for i in range(d)]
 Q.append(q)
with (out/'root_q.txt').open('w')as f:
 f.write(' '.join(map(str,[c['denominator']]+c['bound']))+'\n')
 for q in Q:
  for row in q:f.write(' '.join(map(str,row))+'\n')
print('exact lifted blocks',c['dimensions'],'denominator',c['denominator'],'largest absolute numerator',max(abs(z)for q in Q for row in q for z in row))
