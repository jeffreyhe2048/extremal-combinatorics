import json,argparse,hashlib,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('certificate');p.add_argument('output');v=p.parse_args();raw=Path(v.certificate).read_bytes();c=json.loads(raw);start=time.time();report=[]
for bi,b in enumerate(c['blocks']):
 A=[list(r)for r in b['matrix']];n=len(A);assert all(len(r)==n for r in A);assert all(A[i][j]==A[j][i]for i in range(n)for j in range(n));prev=1;digits=[]
 for k in range(n):
  pivot=A[k][k];assert pivot>0,(bi,k,pivot);digits.append(len(str(pivot)))
  if k==n-1:break
  for i in range(k+1,n):
   for j in range(i,n):
    val=pivot*A[i][j]-A[i][k]*A[k][j];q,r=divmod(val,prev);assert r==0
    A[i][j]=q;A[j][i]=q
  prev=pivot
 report.append({'block':bi,'reduced_dimension':n,'positive_leading_minors':n,'determinant_digits':digits[-1]})
 print('PD block',bi,n,flush=True)
out={'status':'PASS','certificate_sha256':hashlib.sha256(raw).hexdigest(),'blocks':report,'seconds':time.time()-start};Path(v.output).write_text(json.dumps(out,indent=2)+'\n');print(out['certificate_sha256'])
