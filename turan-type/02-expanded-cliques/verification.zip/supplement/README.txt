Exact supplementary certificate for
Squared Codegrees of Expanded Cliques, by Jialin He

Purpose
This directory is self-contained. It verifies the rational-certificate
lemma in Section 3 of main.tex. The forbidden 4-graph has edge set
{1234,1256,3456}. The bound is exactly 9/32, and every nonodd seven-vertex
host has slack at least 135223/250000000. No optimization solver, floating
point package, graph database, or path outside this directory is needed.
The analytic moment and stability arguments are proved in the paper.

Run
From the paper directory, execute
    python3 supplement/verify_all.py
To save a fresh report, execute
    python3 supplement/verify_all.py supplement/verification.json
Python 3 and a C++17 compiler named clang++, g++, or c++ must be on PATH.
The C++ code uses the widely available __int128 integer extension;
Clang and GCC are supported. Intermediate tables and executables are
created in a temporary directory and removed on completion. A full run
took about 11 seconds on the machine used to prepare the manuscript;
this timing is not an input to the verification.
Do not invoke Python with -O, which would disable the assertions.

Files and checks
certificate.json
    Contains the common denominator 100000000, the bound [9,32], the
    dimensions, and ten integer pairs (basis B, matrix R). The full
    rational matrix is Q=B R B^T/100000000. It also records the signed
    block orbit representatives. The file SHA-256 is
    e182640fde2c1396663675bb3f50ad20180f861012f194fb31871c7afda5de43.

generate_seven.cpp
    Enumerates all 7945 labeled six-vertex T-free 4-graphs via their
    two-element complement graphs. It finds 55 isomorphism types, then
    generates their 1801387 legal extensions and 125940 orbits with a
    distinguished seventh vertex. The conflict condition for two new
    edges is proved in the paper.

root5_orbits.py and signed_orbits.py
    Reconstruct the six ordinary five-root flag orbit maps and the
    12-dimensional signed map. Graph pairs are in lexicographic order;
    bit zero is the first pair. The character is the product of the
    signs on the root parts {0,1} and {2,3,4}.

seven_flags.cpp
    Computes seven-vertex targets and flag products; it combines hosts
    only when their full coefficient data agree. There are 19894 rows.
    The four-root, three-root, and five-root matrix denominators are
    5040, 1260, and 42. The target denominator is 420. Matrix inner
    products use all ordered entries, including both off-diagonal entries.

verify_certificate.py
    Reconstructs Q exactly from B and R. Integer Bareiss elimination
    checks positivity of every leading principal minor of R. It checks
    all host inequalities, the exact zero types, the minimum positive
    slack, and the diagonal bounds used for the finite sampling error.
    This manuscript copy adds explicit assertions of the diagonal and
    slack constants to the earlier verified implementation; the matrices
    and their certificate file are unchanged.

prepare_q.py, psd_audit.py, and root_audit.cpp
    Supply an independently implemented check. The C++ audit does not
    read the generated signed orbit map or the merged flag coefficient
    rows. It reconstructs the 4-graph forbidden triples and the signed
    group action directly, and checks every one of the 125940 hosts.
    It also checks coverage of all 1801387 legal extensions and verifies
    that zero slack occurs if and only if the host is an odd graph.
    The separate Python audit checks all positive leading principal minors.

verify_all.py
    Runs the preceding stages in a temporary directory and prints a JSON
    report. It never modifies the certificate or the paper. The optional
    positional argument is the output report path.

verification.json
    Records the successful run used for this manuscript, including the
    exact minimum slack, all dimensions, diagonal maxima, independent
    audit output, and source hashes. The executable checks, rather than
    this saved report, are the reproducible evidence.

Expected checks
    status: PASS
    allowed labeled six-vertex hosts: 7945
    six-vertex isomorphism types: 55
    legal extensions: 1801387
    seven-vertex pointed representatives: 125940
    distinct coefficient rows: 19894
    full matrix dimensions: 16,16,24,34,42,48,31,19,6,12
    positive definite reduced dimensions: 8,8,16,32,42,46,31,17,6,12
    minimum positive slack: 272609568/(5040*100000000)
                          = 135223/250000000
    zero slack iff odd: PASS
Seven pointed representatives have zero slack. They represent four
unpointed odd types; this does not conflict with the four zero coefficient
rows. The signed feature matrices of individual hosts are not asserted
to be positive semidefinite. Only their independent-extension average,
conditional on common roots, has the nonnegativity used in the proof.
