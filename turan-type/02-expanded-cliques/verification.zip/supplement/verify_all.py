#!/usr/bin/env python3
"""Rebuild all finite data and verify the exact 9/32 certificate.
Python standard library and a C++17 compiler suffice. Intermediate tables are temporary.
"""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,tempfile,time
P=Path(__file__).resolve().parent
compiler=next((shutil.which(x) for x in ('clang++','g++','c++') if shutil.which(x)),None)
if compiler is None:raise SystemExit('A C++17 compiler is required.')
start=time.time()
names=['certificate.json','generate_seven.cpp','seven_flags.cpp','root5_orbits.py','signed_orbits.py','verify_certificate.py','root_audit.cpp','prepare_q.py','psd_audit.py']
with tempfile.TemporaryDirectory(prefix='t4-exact-nine-thirtyseconds-') as name:
    work=Path(name)
    for source in names:shutil.copy2(P/source,work/source)
    stages=[]
    for source in ['root5_orbits.py','signed_orbits.py']:
        run=subprocess.run([sys.executable,str(work/source)],check=True,capture_output=True,text=True)
        stages.append({'stage':source,'output':run.stdout})
    for source in ['generate_seven','seven_flags']:
        subprocess.run([compiler,'-O3','-std=c++17',str(work/(source+'.cpp')),'-o',str(work/source)],check=True,capture_output=True,text=True)
        run=subprocess.run([str(work/source),str(work)],check=True,capture_output=True,text=True)
        stages.append({'stage':source,'output':run.stdout+run.stderr});print(source+': completed',flush=True)
    run=subprocess.run([sys.executable,str(work/'verify_certificate.py'),str(work)],check=True,capture_output=True,text=True)
    subprocess.run([sys.executable,str(work/'prepare_q.py'),str(work/'certificate.json'),str(work)],check=True,capture_output=True,text=True)
    subprocess.run([sys.executable,str(work/'psd_audit.py'),str(work/'certificate.json'),str(work/'psd_audit.json')],check=True,capture_output=True,text=True)
    subprocess.run([compiler,'-O3','-std=c++17',str(work/'root_audit.cpp'),'-o',str(work/'root_audit')],check=True,capture_output=True,text=True)
    audit=subprocess.run([str(work/'root_audit'),str(work)],check=True,capture_output=True,text=True)
    assert 'coverage PASS six_types 55 legal_extensions 1801387 rooted_orbits 125940' in audit.stdout
    assert 'zero_iff_odd PASS' in audit.stdout
    print('independent audit: completed',flush=True)
    report={'status':'PASS','independent_audit':audit.stdout,'independent_psd':json.loads((work/'psd_audit.json').read_text()),'certificate':json.loads((work/'verification.json').read_text()),'generation':stages,'source_sha256':{name:hashlib.sha256((P/name).read_bytes()).hexdigest() for name in names},'seconds':time.time()-start}
    print(json.dumps(report,ensure_ascii=False,indent=2))
    if len(sys.argv)>1:Path(sys.argv[1]).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
