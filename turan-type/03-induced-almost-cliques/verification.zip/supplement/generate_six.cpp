#include <algorithm>
#include <array>
#include <fstream>
#include <iostream>
#include <map>
#include <numeric>
#include <vector>
using namespace std;
int ti[6][6][6], pi[4][4];
vector<array<int,3>> triples;
int main(int argc,char**argv){
 if(argc!=2)return 1;string base=argv[1];
 for(int i=0;i<6;i++)for(int j=i+1;j<6;j++)for(int k=j+1;k<6;k++){
  array<int,3> t={i,j,k};int id=triples.size();triples.push_back(t);
  do{ti[t[0]][t[1]][t[2]]=id;}while(next_permutation(t.begin(),t.end()));
 }
 int pc=0;for(int i=0;i<4;i++)for(int j=i+1;j<4;j++)pi[i][j]=pi[j][i]=pc++;
 vector<array<int,6>> perms;array<int,6> p={0,1,2,3,4,5};
 do{perms.push_back(p);}while(next_permutation(p.begin(),p.end()));
 vector<array<int,20>> shifts;
 for(auto p:perms){array<int,20>s{};for(int k=0;k<20;k++)s[k]=ti[p[triples[k][0]]][p[triples[k][1]]][p[triples[k][2]]];shifts.push_back(s);}
 vector<bool> visited(1<<20);vector<int> graphs;
 for(int g=0;g<(1<<20);g++)if(!visited[g]){
  graphs.push_back(g);
  for(auto s:shifts){int z=0;for(int k=0;k<20;k++)if(g>>k&1)z|=1<<s[k];visited[z]=true;}
 }
 vector<vector<int>> flags(7);flags[0]={0,1};
 for(int b=0;b<16;b++)if(b<=((b&12)|((b&1)<<1)|((b&2)>>1)))flags[1].push_back(b);
 for(int j=2;j<7;j++)for(int b=0;b<64;b++)flags[j].push_back(b);
 vector<map<int,int>> fi(7);for(int j=0;j<7;j++)for(int k=0;k<(int)flags[j].size();k++)fi[j][flags[j][k]]=k;
 ofstream data(base+"/flag_matrix.tsv"),meta(base+"/flag_meta.txt"),obj(base+"/graphs.tsv");
 for(auto f:flags){for(int b:f)meta<<b<<' ';meta<<'\n';}
 for(int id=0;id<(int)graphs.size();id++){
  int g=graphs[id],nine=0;bool good=false;
  for(int omit=0;omit<6;omit++){int ec=0;for(int k=0;k<20;k++)if(find(triples[k].begin(),triples[k].end(),omit)==triples[k].end())ec+=(g>>k)&1;nine+=ec==9;}
  for(int cut=0;cut<64;cut++){int z=0;for(int k=0;k<20;k++){int x=0;for(int v:triples[k])x+=(cut>>v)&1;if(x==1||x==2)z|=1<<k;}if(z==g)good=true;}
  obj<<g<<' '<<nine<<' '<<good<<'\n';
  map<array<int,3>,int> counts;
  for(auto p:perms){auto E=[&](int a,int b,int c){return(g>>ti[p[a]][p[b]][p[c]])&1;};
   counts[{0,E(0,1,2),E(3,4,5)}]++;
   auto f2=[&](int a,int b){int z=E(0,1,a)+2*E(0,1,b)+4*E(0,a,b)+8*E(1,a,b);return min(z,(z&12)|((z&1)<<1)|((z&2)>>1));};
   counts[{1,fi[1][f2(2,3)],fi[1][f2(4,5)]}]++;
   int root=E(0,1,2)+2*E(0,1,3)+4*E(0,2,3)+8*E(1,2,3),e=__builtin_popcount((unsigned)root);
   if(root==((1<<e)-1)){
    int a=0,b=0;for(int i=0;i<4;i++)for(int j=i+1;j<4;j++){a|=E(i,j,4)<<pi[i][j];b|=E(i,j,5)<<pi[i][j];}
    counts[{e+2,a,b}]++;
   }
  }
  for(auto [key,v]:counts)data<<key[0]<<' '<<key[1]<<' '<<key[2]<<' '<<id<<' '<<v<<'\n';
 }
 cerr<<"graphs "<<graphs.size()<<"\n";
}
