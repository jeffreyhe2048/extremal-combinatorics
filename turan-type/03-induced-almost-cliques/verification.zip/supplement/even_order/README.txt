Even-order reweighting checks for Theorem 1.3
Python 3, standard library only. Run from this directory:
  python3 verify.py
  python3 independent_verify.py
Both were run successfully on 27 October 2026. The original research-date metadata
in an output file is not an execution timestamp. Counts use integers and Fraction.
The programs check the two 60-vertex counts, legal class occupancies, small explicit
subsets and rational densities. The all-even-order proof is in main.tex.
