"""Root audit: direct vertex sets, type words, and finite class occupancies."""
from fractions import Fraction as F
from itertools import combinations, product
from math import comb, factorial
from pathlib import Path
import json

def missing(a):
    return sum(comb(v, 3) for v in a) + sum(comb(a[i], 2)*a[(i+1)%3] for i in range(3))

def compositions(n, length):
    if length == 1:
        yield (n,)
    else:
        for j in range(n+1):
            for rest in compositions(n-j, length-1):
                yield (j,)+rest

def finite(sizes, order):
    hist = {}
    for a in compositions(order, len(sizes)):
        ways = 1
        for size, count in zip(sizes, a):
            ways *= comb(size, count) if count <= size else 0
        if ways:
            q = missing(a)
            hist[q] = hist.get(q, 0)+ways
    assert sum(hist.values()) == comb(sum(sizes), order)
    return hist

def density(t, b):
    s = (t-4)//2
    masses = [b/3]*3 + [(1-b)/s]*s
    ans = F(0)
    for a in compositions(t, len(masses)):
        q = missing(a)
        assert q >= 1
        if q == 1:
            term = F(factorial(t))
            for x, count in zip(masses, a):
                term *= x**count / factorial(count)
            ans += term
    return ans

def claimed(t, b):
    s = (t-4)//2
    return F(factorial(t), 162*2**s*s**(2*s))*b**3*(5-b)*(1-b)**(2*s)

rows = []
for sizes in ((12,12,12,24),(11,12,12,25)):
    hist = finite(sizes, 6)
    assert hist.get(0, 0) == 0
    rows.append({'sizes':sizes, 'edges_G':comb(60,3)-missing(sizes), 'induced':hist[1]})
assert rows[0]['induced'] == 18361728
assert rows[1]['induced'] == 18367800
assert rows[1]['induced'] - rows[0]['induced'] == 6072

# Directly enumerate actual vertices and actual triples in a small graph.
sizes = (2,3,2,4)
labels = [j for j,s in enumerate(sizes) for _ in range(s)]
edges = []
for tri in combinations(range(len(labels)),3):
    a = tuple(sum(labels[v] == j for v in tri) for j in range(4))
    if missing(a):
        edges.append(frozenset(tri))
hist = {}
for sub in combinations(range(len(labels)),6):
    S = frozenset(sub)
    q = sum(e <= S for e in edges)
    hist[q] = hist.get(q,0)+1
assert hist == finite(sizes,6)

# Independently sum all ordered six-type words, without multinomial factors.
weights = [F(10,51)]*3+[F(7,17)]
word_sum = F(0)
for word in product(range(4),repeat=6):
    a = tuple(word.count(i) for i in range(4))
    if missing(a) == 1:
        w = F(1)
        for i in word:
            w *= weights[i]
        word_sum += w
assert word_sum == F(24500000,72412707)

general = []
for t in (6,8,10,12,14):
    b0 = F(3,t-1)
    for b in (F(1,3), F(10,17), b0, b0-F(1,100*t)):
        assert density(t,b) == claimed(t,b)
    assert claimed(t,b0-F(1,100*t)) > claimed(t,b0)
    derivative = 3/b0-1/(5-b0)-F(t-4)/(1-b0)
    assert derivative == -1/(5-b0) < 0
    general.append(t)
result = {'status':'PASS', 'finite_witnesses':rows,
          'direct_small_subsets':comb(11,6), 'ordered_type_words':4**6,
          'rational_density':str(word_sum), 'general_even_orders_checked':general,
          'scope':'Finite checks supplement, but do not prove, the all-even-order theorem.'}
Path(__file__).with_name('independent_verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
