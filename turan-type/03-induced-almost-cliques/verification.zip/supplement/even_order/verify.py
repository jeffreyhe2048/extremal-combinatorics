#!/usr/bin/env python3
"""Exact checks for the even-order reweighting of the FRV Conjecture 5 template."""
from fractions import Fraction as F
from itertools import combinations, product
from math import comb, factorial, prod
from pathlib import Path
import json


def C(n,k):
    return comb(n,k) if 0<=k<=n else 0


def compositions(n,k):
    if k==1:
        yield (n,)
    else:
        for x in range(n+1):
            for rest in compositions(n-x,k-1):
                yield (x,)+rest


def complement_edges(counts):
    """For the 3 special parts followed by any number of complete blocks."""
    a=counts[:3]
    return sum(C(x,3) for x in counts)+sum(C(a[i],2)*a[(i+1)%3] for i in range(3))


def occupancy_counts(sizes,t):
    out={}
    for c in compositions(t,len(sizes)):
        multiplicity=prod(C(n,k) for n,k in zip(sizes,c))
        if multiplicity:
            e=complement_edges(c)
            out[e]=out.get(e,0)+multiplicity
    assert sum(out.values())==C(sum(sizes),t)
    return out


def special_counts(a):
    i3=prod(a)+sum(C(a[i],2)*a[(i-1)%3] for i in range(3))
    i4=sum(C(a[i],2)*a[(i-1)%3]*a[(i+1)%3]+C(a[i],3)*a[(i-1)%3] for i in range(3))
    return i3,i4


def t6_formula(sizes):
    i3,i4=special_counts(sizes[:3]);h=sizes[3]
    return i4*C(h,2)+i3*C(h,3)


# Independent direct labelled-vertex enumeration on small representatives.
explicit=0
for sizes in [(2,2,2,3),(1,2,3,4),(3,2,2,2),(2,3,2,3)]:
    labels=[i for i,n in enumerate(sizes) for _ in range(n)]
    edges={e for e in combinations(range(len(labels)),3)
           if complement_edges(tuple(sum(labels[v]==j for v in e) for j in range(4)))==1}
    counts={}
    for S in combinations(range(len(labels)),6):
        e=sum(T in edges for T in combinations(S,3))
        counts[e]=counts.get(e,0)+1
        explicit+=1
    assert counts==occupancy_counts(sizes,6)
    assert counts.get(0,0)==0
    assert counts.get(1,0)==t6_formula(sizes)

finite=[]
for sizes in [(12,12,12,24),(11,12,12,25),(60,60,60,120),(59,59,59,123)]:
    counts=occupancy_counts(sizes,6)
    assert counts.get(0,0)==0
    assert counts[1]==t6_formula(sizes)
    finite.append({'sizes':sizes,'n':sum(sizes),'edges':C(sum(sizes),3)-complement_edges(sizes),
                   'induced_K6minus':counts[1], 'complement_6set_distribution':counts})
assert finite[0]['edges']==29160 and finite[1]['edges']==29137
assert finite[0]['induced_K6minus']==18361728
assert finite[1]['induced_K6minus']==18367800
assert finite[1]['induced_K6minus']-finite[0]['induced_K6minus']==6072

# IID limit probabilities by every possible part occupancy, including repeated parts.
def limit_density(t,b):
    s=(t-4)//2
    w=[b/3]*3+[(1-b)/s]*s
    p=F(0)
    for c in compositions(t,len(w)):
        if complement_edges(c)==1:
            p+=F(factorial(t),prod(factorial(x) for x in c))*prod(x**k for x,k in zip(w,c))
        assert complement_edges(c)>0
    return p


def p_formula(t,b):
    s=(t-4)//2
    return F(factorial(t),162*2**s*s**(2*s))*b**3*(5-b)*(1-b)**(t-4)

samples=[]
for t in [6,8,10,12,14]:
    b0=F(3,t-1)
    for b in [F(1,3),F(3,5),F(10,17),b0]:
        assert limit_density(t,b)==p_formula(t,b)
    old=F(factorial(t)*(5*t-8)*2**((t-6)//2),3*(t-1)**t)
    assert p_formula(t,b0)==old
    deriv_log=3/b0-1/(5-b0)-F(t-4,1-b0)
    assert deriv_log==-1/(5-b0)<0
    # A rational left-neighbour with sufficiently small displacement.
    eps=F(1,10000*t*t)
    assert p_formula(t,b0-eps)>old
    samples.append({'t':t,'balanced_density':str(old),'test_b':str(b0-eps),
                    'positive_gap':str(p_formula(t,b0-eps)-old)})

rational=p_formula(6,F(10,17));old=p_formula(6,F(3,5))
assert rational==F(24500000,72412707) and old==F(1056,3125)
assert rational-old==F(94681408,226289709375)>0
assert p_formula(6,F(59,100))==F(16916862851,50000000000)

record={'status':'PASS','explicit_small_vertex_subsets':explicit,'finite_examples':finite,
        'all_occupancy_formula_checks':20,'even_t_samples':samples,
        'rational_t6_density':str(rational),'balanced_t6_density':str(old),'gap':str(rational-old),
        'scope':'Finite exact checks complement the all-even-t elementary proof; no global extremal upper bound is claimed.'}
Path(__file__).with_name('verification.json').write_text(json.dumps(record,indent=2)+'\n')
print('PASS:',explicit,'labelled six-subsets; all occupancy and rational formula checks.')
print('60 vertices: 18367800 > 18361728, gap 6072.')
print('Asymptotic:',rational,'>',old)
