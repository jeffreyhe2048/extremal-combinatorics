import itertools as it,json
from math import comb
from pathlib import Path

def target(Q,E):return sum(frozenset(t) in E for t in it.combinations(Q,3))==9
pair_checks=0;single_checks=0
for a,b in [(3,3),(3,4),(4,4),(4,5)]:
 n=a+b;A=set(range(a));B=set(range(a,n))
 ideal={frozenset(t) for t in it.combinations(range(n),3) if set(t)&A and set(t)&B}
 for uv in [(0,1),(0,a)]:
  others=[w for w in range(n) if w not in uv];pair=frozenset(uv)
  for mask in range(1<<len(others)):
   E={e for e in ideal if not pair<=e}
   E.update(pair|{w} for i,w in enumerate(others) if mask>>i&1)
   actual=sum(target(pair|set(T),E) for T in it.combinations(others,3))
   if uv[1]<a:
    aa=a-2;bb=b;x=sum(not(pair|{w} in E) for w in B);y=sum(pair|{w} in E for w in A-pair)
    expected=(aa-y)*comb(bb-x,2)+y*x*(bb-x)+comb(bb-x,3)
   else:
    aa=a-1;bb=b-1;x=sum(not(pair|{w} in E) for w in A-pair);y=sum(not(pair|{w} in E) for w in B-pair)
    expected=comb(aa-x,2)*(bb-y)+(aa-x)*comb(bb-y,2)
   assert actual==expected
   pair_checks+=1
 for e in map(frozenset,it.combinations(range(n),3)):
  E=ideal^{e}
  total=0
  for extra in it.combinations(set(range(n))-e,2):
   Q=e|set(extra);delta=int(target(Q,ideal))-int(target(Q,E));assert delta>=0;total+=delta
  if e<=A:expected=comb(b,2)
  elif e<=B:expected=comb(a,2)
  elif len(e&A)==2:expected=(a-2)*(b-1)+comb(b-1,2)
  else:expected=(b-2)*(a-1)+comb(a-1,2)
  assert total==expected;single_checks+=1
out=dict(status='PASS',pair_assignment_checks=pair_checks,single_defect_checks=single_checks,
         scope='Exact pair formulas and all single-defect ideal gains; analytic audit separate')
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
