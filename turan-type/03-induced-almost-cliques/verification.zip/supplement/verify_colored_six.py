from itertools import combinations
import json
from pathlib import Path

pairs = list(combinations(range(6), 2))
index = {p: i for i, p in enumerate(pairs)}
within_a = sum(1 << index[p] for p in combinations(range(3), 2))
within_b = sum(1 << index[p] for p in combinations(range(3, 6), 2))
cross = ((1 << 15) - 1) ^ within_a ^ within_b
patterns = []
for vertices in combinations(range(6), 4):
    a = sum(v < 3 for v in vertices)
    mask = sum(1 << index[p] for p in combinations(vertices, 2))
    patterns.append((mask, 5 if a == 2 else 6, 1 if a == 2 else 2))

maxima = [[-1] * 4 for _ in range(4)]
hist = {}
equal = []
for g in range(1 << 15):
    score = sum(weight for mask, count, weight in patterns
                if (g & mask).bit_count() == count)
    assert score <= 15, (g, score)
    p, q = (g & within_a).bit_count(), (g & within_b).bit_count()
    maxima[p][q] = max(maxima[p][q], score)
    hist[score] = hist.get(score, 0) + 1
    if score == 15:
        equal.append(g)
assert set(equal) == {cross | within_a, cross | within_b}
result = dict(status='PASS', checked=1 << 15, upper=15,
              equality_masks=equal, maxima_by_internal_edges=maxima,
              score_histogram=hist)
Path(__file__).with_name('colored_six_verification.json').write_text(
    json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))
