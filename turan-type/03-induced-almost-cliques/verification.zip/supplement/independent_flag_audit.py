#!/usr/bin/env python3
"""Independent subset/embedding reconstruction of every flag coefficient.
No import of original generator/verifier and no optimization dependency.
"""
from pathlib import Path
from itertools import combinations, permutations, product
from collections import Counter, deque
from hashlib import sha256
from math import factorial, comb
import json,time
BASE=Path(__file__).resolve().parent
start=time.time()
V=tuple(range(6)); triples=list(combinations(V,3)); tid={t:i for i,t in enumerate(triples)}
triset={frozenset(t):i for i,t in enumerate(triples)}
rows=[tuple(map(int,s.split())) for s in (BASE/'graphs.tsv').read_text().splitlines()]
assert len(rows)==2136 and len({g for g,_,_ in rows})==2136
meta=[list(map(int,s.split())) for s in (BASE/'flag_meta.txt').read_text().splitlines()]
expected=[list(range(2)),[k+4*a+8*b for b in range(2) for a in range(2) for k in (0,1,3)]]+[list(range(64)) for _ in range(5)]
assert meta==expected,(meta,expected)
# A two-root flag is determined by the NUMBER of edges containing both
# roots, together with the two root-plus-unlabelled-pair edge indicators.
f2index={((m&3).bit_count(),(m>>2)&1,(m>>3)&1):i for i,m in enumerate(meta[1])}
original=[{} for _ in rows]
for line in (BASE/'flag_matrix.tsv').read_text().splitlines():
 b,i,j,g,num=map(int,line.split())
 assert 0<=b<7 and 0<=i<len(meta[b]) and 0<=j<len(meta[b])
 assert 0<num<=720 and (b,i,j) not in original[g]
 original[g][b,i,j]=num

tripart=[(tuple(A),tuple(x for x in V if x not in A)) for A in combinations(V,3)]
rootpairs=[]
for a in V:
 for b in V:
  if a==b:continue
  rem=tuple(x for x in V if x!=a and x!=b)
  rootpairs.append((a,b,[(C,tuple(x for x in rem if x not in C)) for C in combinations(rem,2)]))
roots4=[(U,tuple(x for x in V if x not in U)) for U in combinations(V,4)]
five=[sum(1<<triset[frozenset(t)] for t in combinations(U,3)) for U in combinations(V,5)]
reconstructed_nonzero=0; block_totals=[0]*7
for rowindex,(mask,nine,good) in enumerate(rows):
 E=lambda *verts:(mask>>triset[frozenset(verts)])&1
 count=Counter()
 # Empty type: 20 choices of the FIRST three-set, each corresponds to
 # 3! orders in each of the two flags, i.e. 36 ordered six-tuples.
 for A,B in tripart:count[0,E(*A),E(*B)]+=36
 # Ordered two-root embedding (30 choices), two unordered two-sets
 # (6 choices), and 2!*2!=4 orders suppressed inside the pair of flags.
 for a,b,splits in rootpairs:
  for C,D in splits:
   key=lambda X:(E(a,b,X[0])+E(a,b,X[1]),E(a,*X),E(b,*X))
   count[1,f2index[key(C)],f2index[key(D)]]+=4
 # Four-root type: classify a root vertex by its OPPOSITE triple.
 # Canonical sigma_e has opposite-edge=0 at labels 0,...,3-e, and 1
 # at labels 4-e,...,3. Thus label roots by separately permuting these
 # two groups. This avoids looping over/filtering all six-permutations.
 four_counts=[0]*5
 for U,ext in roots4:
  no=[]; yes=[]
  for u in U:(yes if E(*(x for x in U if x!=u)) else no).append(u)
  e=len(yes);four_counts[e]+=1
  for aa in permutations(no):
   for bb in permutations(yes):
    root=aa+bb
    codes=[]
    for x in ext:
     code=sum(E(root[i],root[j],x)<<k for k,(i,j) in enumerate(combinations(range(4),2)))
     codes.append(code)
    count[e+2,codes[0],codes[1]]+=1
    count[e+2,codes[1],codes[0]]+=1
 assert sum(v for (b,i,j),v in count.items() if b==0)==720
 assert sum(v for (b,i,j),v in count.items() if b==1)==720
 for e in range(5):
  assert sum(v for (b,i,j),v in count.items() if b==e+2)==2*factorial(e)*factorial(4-e)*four_counts[e]
 for (b,i,j),v in count.items():assert count[b,j,i]==v
 if dict(count)!=original[rowindex]:
  keys=set(count)|set(original[rowindex])
  differences=[(k,count[k],original[rowindex].get(k,0)) for k in keys if count[k]!=original[rowindex].get(k,0)]
  raise AssertionError(('flag mismatch',rowindex,mask,differences[:20]))
 assert nine==sum((mask&m).bit_count()==9 for m in five)
 # Independent complete-bipartite check, using nonedges = monochromatic
 # triples. Includes the two trivial cuts, which give the empty graph.
 good_actual=any(all(E(*t)==int(0<len(set(t)&set(A))<3) for t in triples) for k in range(7) for A in combinations(V,k))
 assert bool(good)==good_actual
 reconstructed_nonzero+=len(count)
 for (b,i,j),v in count.items():block_totals[b]+=v
 if (rowindex+1)%500==0:print('reconstructed',rowindex+1,flush=True)
print('ALL 2136 coefficient rows PASS',flush=True)

# Independent completeness check: adjacent transpositions generate S6.
# BFS each listed representative under these FIVE generators; the
# disjoint orbits must partition all 2^20 labelled hypergraphs.
tables=[]
for a in range(5):
 def swap(v):return a+1 if v==a else a if v==a+1 else v
 images=[tid[tuple(sorted(swap(v) for v in t))] for t in triples]
 halves=[]
 for offset in (0,10):
  table=[0]*1024
  for z in range(1,1024):
   low=z&-z; bit=low.bit_length()-1
   table[z]=table[z^low]|(1<<images[offset+bit])
  halves.append(table)
 tables.append(halves)
seen=bytearray(1<<20); orbit_sizes=[]
for mask,_,_ in rows:
 assert not seen[mask],('duplicate isomorphism class',mask)
 q=deque([mask]);seen[mask]=1;size=0;minimum=mask
 while q:
  g=q.popleft();size+=1;minimum=min(minimum,g)
  lo=g&1023;hi=g>>10
  for A,B in tables:
   h=A[lo]|B[hi]
   if not seen[h]:seen[h]=1;q.append(h)
 assert minimum==mask
 orbit_sizes.append(size)
assert sum(seen)==1<<20 and sum(orbit_sizes)==1<<20
assert all(720%s==0 for s in orbit_sizes)
print('ALL 1048576 labelled hosts covered in disjoint orbits PASS',flush=True)
report={
 'status':'PASS','host_classes':len(rows),'labelled_host_coverage':sum(seen),
 'flag_dimensions':[len(x) for x in meta],
 'matrix_nonzero_entries_verified':reconstructed_nonzero,
 'denominator':720,'coefficient_comparison':'every entry including implicit zero entries',
 'sampling':'independent subset partitions and opposite-edge root labellings',
 'ordered_offdiagonal_entries':'both (i,j) and (j,i) present and equal; no extra factor two',
 'coverage_method':'BFS under five adjacent vertex transpositions',
 'block_numerator_sums_over_all_hosts':block_totals,
 'input_sha256':{n:sha256((BASE/n).read_bytes()).hexdigest() for n in ('graphs.tsv','flag_meta.txt','flag_matrix.tsv','certificate.json','generate_six.cpp')},
 'elapsed_seconds':round(time.time()-start,3)}
(BASE/'independent_flag_audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
