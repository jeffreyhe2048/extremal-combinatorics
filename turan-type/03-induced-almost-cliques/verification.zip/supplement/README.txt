Supplement to Induced Almost-Cliques and Edge Extremality in Triple Systems
Jialin He. Local manuscript package, 2026-10-25.

The full analytic proof is in main.tex. This directory contains its finite
rational certificate and reproducible checks; it is not a numerical-search
claim. Python 3.10 or later with only the standard library suffices.

Run all checks from any directory:
    python3 /path/to/supplement/run_all.py

The final phrase should be "All certificate and supporting checks passed."
Individual scripts may also be run. They write their JSON reports beside the
inputs, so run a copy if retaining the original reports is important.

Essential certificate files
- certificate.json: integer R_i and symmetric integer T_i; Q_i=R_i T_i R_i^T/D,
  D=900000000. Its SHA256 is
  975f66ad35cc9a00fbbcff2898edbd13788aab49073b20f7faf2a2538fa94bcf.
- graphs.tsv: the 2136 canonical six-vertex 3-graph masks, target-five-set
  counts, and membership in the four complete bipartite six-types.
- flag_meta.txt: ordered canonical flag codes for each block.
- flag_matrix.tsv: sparse integer flag coefficients, denominator 720.
  Each line is block,row,column,host_index,numerator. Both off-diagonal
  entries are included; there is no additional factor of two.
- verify_certificate.py: reconstruct Q_i, verify positive leading minors
  using Bareiss integer elimination, and check every rational row inequality.
- independent_flag_audit.py: reconstruct every matrix coefficient by a
  different subset/embedding enumeration, including implicit zeros, and
  independently cover all 2^20 labeled hosts by disjoint permutation orbits.
- root_psd_audit.py: separate exact Fraction Schur-complement PSD check.
- generate_six.cpp: optional original C++17 coefficient generator. Compile
  with a C++17 compiler and give the output directory as its argument.
  Regeneration is unnecessary for running the independent Python audit.

Finite checks supporting the written analytic arguments
- verify_colored_six.py: all 32768 graphs on a specified 3+3 partition.
- verify_pair_counts.py and local_exactification_independent_check.py:
  independent finite checks of the exact pair-replacement formulas and
  single-defect changes. These checks do not replace the general proof.
- six_support_classification_verify.py: finite checks of the root-based
  reconstruction and bipartition counting formulas.

Expected central results
All 2136 rows pass; seven reduced blocks of orders 1,10,63,64,64,63,61
are positive definite. There are precisely four zero-slack masks,
0,1023,65535,524286. Minimum other slack is 278519687/4500000000>1/20.
The independent audit verifies 428486 nonzero entries and covers 1048576
labeled hosts, checking every coefficient including all implicit zeros.
No semidefinite solver, optimization library, or external service is used
in these verification steps.
