#!/usr/bin/env python3
"""Run all exact and independent checks using only Python's standard library."""
from pathlib import Path
import subprocess
import sys
base=Path(__file__).resolve().parent
for name in ('verify_certificate.py','independent_flag_audit.py','root_psd_audit.py',
             'verify_colored_six.py','verify_pair_counts.py',
             'local_exactification_independent_check.py',
             'six_support_classification_verify.py'):
    print('\nRunning '+name,flush=True)
    subprocess.run([sys.executable,str(base/name)],check=True,cwd=base)
print('\nAll certificate and supporting checks passed.')
