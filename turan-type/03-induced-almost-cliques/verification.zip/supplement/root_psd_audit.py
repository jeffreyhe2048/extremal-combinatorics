"""Independent rational Schur-complement audit (not Bareiss elimination)."""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json,time
base=Path(__file__).resolve().parent
start=time.time()
raw=(base/'certificate.json').read_bytes(); c=json.loads(raw)
assert c['denominator']==900000000
records=[]
for b,(R,T) in enumerate(zip(c['R'],c['T'])):
    assert all(type(z) is int for row in R+T for z in row)
    n=len(T)
    assert n>0 and all(len(row)==n for row in T+R)
    assert all(T[i][j]==T[j][i] for i in range(n) for j in range(n))
    A=[[F(z) for z in row] for row in T]
    smallest=None
    for k in range(n):
        pivot=A[k][k]
        assert pivot>0,(b,k,pivot)
        smallest=pivot if smallest is None else min(smallest,pivot)
        for i in range(k+1,n):
            ratio=A[i][k]/pivot
            for j in range(i,n):
                A[i][j]-=ratio*A[k][j]
                A[j][i]=A[i][j]
    records.append({'block':b,'dimension':n,'all_rational_Schur_pivots_positive':True})
    print('rational Schur block',b,'PASS',flush=True)
out={'status':'PASS','certificate_sha256':hashlib.sha256(raw).hexdigest(),
     'method':'independent Fraction Schur complements; no float and no Bareiss',
     'blocks':records,'elapsed_seconds':round(time.time()-start,3)}
(base/'root_psd_verification.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out),flush=True)
