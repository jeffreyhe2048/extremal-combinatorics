"""Directly construct all pair-incidence choices; count actual five-sets."""
from itertools import combinations
from math import comb
from pathlib import Path
import json

def binom(x, k):
    return comb(x, k) if x >= k else 0

checked = 0
for na, nb in [(3, 3), (4, 4), (4, 5), (5, 4), (5, 5)]:
    n = na + nb
    part_a = set(range(na))
    vertices = set(range(n))
    template = {frozenset(t) for t in combinations(range(n), 3)
                if 0 < len(set(t) & part_a) < 3}
    for pair in [frozenset((0, 1)), frozenset((na, na + 1)),
                 frozenset((0, na))]:
        others = sorted(vertices - pair)
        fixed = {e for e in template if not pair <= e}
        five_sets = [pair | frozenset(s) for s in combinations(others, 3)]
        for mask in range(1 << len(others)):
            neighbors = {v for j, v in enumerate(others) if mask >> j & 1}
            graph = fixed | {pair | {v} for v in neighbors}
            actual = sum(sum(frozenset(t) in graph for t in combinations(s, 3)) == 9
                         for s in five_sets)
            side = len(pair & part_a)
            if side in (0, 2):
                own = part_a if side == 2 else vertices - part_a
                opposite = vertices - own
                a, b = len(own) - 2, len(opposite)
                x = len(opposite - neighbors)
                y = len(neighbors & own)
                formula = ((a-y)*binom(b-x, 2) + y*x*(b-x)
                           + binom(b-x, 3))
            else:
                a, b = na - 1, nb - 1
                x = len((part_a - pair) - neighbors)
                y = len(((vertices-part_a)-pair) - neighbors)
                formula = binom(a-x, 2)*(b-y) + (a-x)*binom(b-y, 2)
            assert actual == formula, (na, nb, tuple(pair), mask, actual, formula)
            checked += 1
result = {'status': 'PASS', 'pair_incidence_states': checked,
          'class_sizes': [[3,3],[4,4],[4,5],[5,4],[5,5]],
          'method': 'explicit triples and five-set counts; both same-side orientations and cross pairs'}
Path(__file__).with_name('pair_counts_verification.json').write_text(
    json.dumps(result, indent=2)+'\n', encoding='utf-8')
print(json.dumps(result))
