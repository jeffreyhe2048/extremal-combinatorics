#!/usr/bin/env python3
"""Small exact checks of the elementary six-support reconstruction.
This tests the finite root transitions independently of the general proof.
"""
from itertools import combinations,product
from pathlib import Path
import json

def edges(n,colors):
    return frozenset(t for t in combinations(range(n),3) if len({colors[v] for v in t})==2)

def allowed_on(vertices,E):
    vertices=tuple(vertices)
    induced=frozenset(t for t in combinations(vertices,3) if t in E)
    return any(induced==frozenset(t for t in combinations(vertices,3) if len({c[v] for v in t})==2)
               for bit in product(range(2),repeat=len(vertices)-1)
               for c in [dict(zip(vertices,(0,)+bit))])

B6={edges(6,(0,)+bits) for bits in product(range(2),repeat=5)}
R=frozenset(range(4));root_edges=frozenset(combinations(range(4),3))
rooted=[E for E in B6 if root_edges<=E]
assert len(B6)==32 and len(rooted)==12
for E in rooted:
    P=[]
    for v in (4,5):
        missing=[t for t in combinations((*range(4),v),3) if t not in E]
        assert len(missing)==1 and v in missing[0]
        P.append(frozenset(missing[0])-{v})
    assert P[0]==P[1] or P[0]==R-P[1]

# Complete independent labelled B6 lookup; now test all completions of root-incident
# triples to either of the two possible values on each all-outside triple.
reports=[]
for n in (7,8):
    Bn={edges(n,(0,)+bits) for bits in product(range(2),repeat=n-1)}
    root_models={E for E in Bn if root_edges<=E}
    cells=list(combinations(range(4,n),3));tested=passed=0
    templates=set()
    for model in root_models:
        fixed=frozenset(e for e in model if set(e)&R)
        templates.add(fixed)
    assert len(templates)==3*2**(n-4)
    for fixed in templates:
        for bit in product(range(2),repeat=len(cells)):
            E=fixed|frozenset(t for t,b in zip(cells,bit) if b)
            tested+=1
            good=True
            for S in combinations(range(n),6):
                relabel={v:i for i,v in enumerate(S)}
                sub=frozenset(tuple(relabel[v] for v in e) for e in E if set(e)<=set(S))
                if sub not in B6:
                    good=False;break
            if good:
                passed+=1
                assert E in Bn
    assert passed==len(root_models)==3*2**(n-4)
    reports.append({'n':n,'root_incident_templates':len(templates),'outside_completions_tested':tested,
                    'six_locally_B_completions':passed,'all_globally_B':True})

# Exact target-count and balance formulas on all moderate bipartitions.
from math import comb
count_checks=0
for n in range(6,31):
    best=-1;arg=[]
    for a in range(n+1):
        b=n-a
        value=comb(a,3)*comb(b,2)+comb(a,2)*comb(b,3)
        assert 12*value==(n-4)*a*b*(a*b-n+1)
        count_checks+=1
        if value>best:best=value;arg=[a]
        elif value==best:arg.append(a)
    assert set(arg)=={n//2,(n+1)//2}
report={'status':'PASS','labelled_B6_patterns':len(B6),'root_K4_patterns':len(rooted),
        'root_completion_checks':reports,'bipartition_formula_checks':count_checks,
        'scope':'Finite checks support the separate all-n elementary proof; no SDP coefficients checked here.'}
(Path(__file__).parent/'six_support_classification_verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
